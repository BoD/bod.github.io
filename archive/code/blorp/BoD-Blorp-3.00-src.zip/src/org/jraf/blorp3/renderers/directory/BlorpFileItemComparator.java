/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: BlorpFileItemComparator.java 204 2008-05-16 14:38:37Z bod $
*/
package org.jraf.blorp3.renderers.directory;

import java.util.Comparator;

import org.jraf.blorp3.renderers.common.BlorpFileItem;

public class BlorpFileItemComparator implements Comparator<BlorpFileItem> {
    private String sorting;

    public BlorpFileItemComparator(String sorting) {
        this.sorting = sorting;
    }

    public int compare(BlorpFileItem bf1, BlorpFileItem bf2) {
        if (sorting.equals("na") || bf1.isDirectory() && sorting.equals("sa") || sorting.equals("sd")) {
            return bf1.getName().toLowerCase().compareTo(bf2.getName().toLowerCase());
        }
        if (sorting.equals("nd")) {
            return bf2.getName().toLowerCase().compareTo(bf1.getName().toLowerCase());
        }

        if (sorting.equals("sa")) {
            return new Long(bf1.getSize()).compareTo(bf2.getSize());
        }
        if (sorting.equals("sd")) {
            return new Long(bf2.getSize()).compareTo(bf1.getSize());
        }

        if (sorting.equals("ta")) {
            return bf1.getFileType().compareTo(bf2.getFileType());
        }
        if (sorting.equals("td")) {
            return bf2.getFileType().compareTo(bf1.getFileType());
        }

        if (sorting.equals("da")) {
            return bf1.getDateModified().compareTo(bf2.getDateModified());
        }
        if (sorting.equals("dd")) {
            return bf2.getDateModified().compareTo(bf1.getDateModified());
        }

        if (sorting.equals("ia")) {
            if (bf1.getTitle() == null && bf2.getTitle() == null) {
                return 0;
            }
            if (bf1.getTitle() == null) {
                return 1;
            }
            if (bf2.getTitle() == null) {
                return -1;
            }
            return bf1.getTitle().compareTo(bf2.getTitle());
        }
        if (sorting.equals("id")) {
            if (bf1.getTitle() == null && bf2.getTitle() == null) {
                return 0;
            }
            if (bf1.getTitle() == null) {
                return 1;
            }
            if (bf2.getTitle() == null) {
                return -1;
            }
            return bf2.getTitle().compareTo(bf1.getTitle());
        }
        return 0;
    }
}
