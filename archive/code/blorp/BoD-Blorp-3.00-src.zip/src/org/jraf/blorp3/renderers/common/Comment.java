/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.blorp3.renderers.common;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

public class Comment {
    private String name;
    private Date date;
    private String comment;

    public Comment(String line) {
        String[] split = StringUtils.split(line, '\t');
        name = split[0];
        date = new Date(Long.parseLong(split[1]));
        comment = split[3];
    }

    public String getName() {
        return name;
    }

    public Date getDate() {
        return date;
    }

    public String getComment() {
        return comment;
    }
}
