/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: Conf.java 215 2008-05-23 23:54:22Z bod $
*/
package org.jraf.blorp3;

import java.io.File;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

public class Conf {
    private File sharedRootFile;
    private String sharedRootUrl;
    private String generatedRootUrl;
    private Set<String> availableIcons;
    private Map<String, String> fileTypes;
    private Set<String> imageFileTypes;
    private Set<String> videoFileTypes;
    private File pathToFfmpegExecutable;
    private File pathToImageMagickExecutable;
    private Set<String> hiddenFiles;
    private String urlEncodingCharset;
    private String[] renderers;
    private Configuration configuration;

    public Conf() throws ConfException {
        try {
            configuration = new PropertiesConfiguration(getClass().getResource("/conf/blorp.properties"));
        } catch (ConfigurationException e) {
            throw new ConfException(e);
        }
        sharedRootFile = new File(configuration.getString("folder.shared"));
        sharedRootUrl = configuration.getString("url.shared");
        generatedRootUrl = configuration.getString("url.generated");
        loadFileTypes(configuration.subset("fileType"));

        imageFileTypes = new HashSet<String>();
        imageFileTypes.addAll(Arrays.asList(configuration.getStringArray("imageFileTypes")));

        videoFileTypes = new HashSet<String>();
        videoFileTypes.addAll(Arrays.asList(configuration.getStringArray("videoFileTypes")));

        pathToFfmpegExecutable = new File(configuration.getString("pathToFfmpegExecutable"));
        pathToImageMagickExecutable = new File(configuration.getString("pathToImageMagickExecutable"));

        hiddenFiles = new HashSet<String>();
        for (String fileName : configuration.getStringArray("hiddenFiles")) {
            hiddenFiles.add(fileName.toLowerCase());
        }

        urlEncodingCharset = configuration.getString("urlEncodingCharset");
        renderers = configuration.getStringArray("renderers");
    }

    private void loadFileTypes(Configuration configuration) {
        availableIcons = new HashSet<String>();
        fileTypes = new TreeMap<String, String>();
        for (Iterator i = configuration.getKeys(); i.hasNext();) {
            String keyString = (String) i.next();
            availableIcons.add(keyString);
            fileTypes.put(keyString, configuration.getString(keyString));
        }
    }

    public File getSharedRootFile() {
        return sharedRootFile;
    }

    public String getSharedRootUrl() {
        return sharedRootUrl;
    }

    public String getGeneratedRootUrl() {
        return generatedRootUrl;
    }

    public Set<String> getAvailableIcons() {
        return availableIcons;
    }

    public String getFileType(String extension) {
        return fileTypes.get(extension);
    }

    public Set<String> getImageFileTypes() {
        return imageFileTypes;
    }

    public Set<String> getVideoFileTypes() {
        return videoFileTypes;
    }

    public File getPathToFfmpegExecutable() {
        return pathToFfmpegExecutable;
    }

    public Set<String> getHiddenFiles() {
        return hiddenFiles;
    }

    public String getUrlEncodingCharset() {
        return urlEncodingCharset;
    }

    public String[] getRenderers() {
        return renderers;
    }

    public Configuration getRendererConf(String rendererClassName) {
        return configuration.subset("renderer."+rendererClassName);
    }

    public File getPathToImageMagickExecutable() {
        return pathToImageMagickExecutable;
    }
}
