/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: ThumbnailServiceImpl.java 216 2008-05-24 12:58:35Z bod $
*/
package org.jraf.blorp3.thumbnails;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.Locale;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.plugins.jpeg.JPEGImageWriteParam;
import javax.imageio.stream.ImageOutputStream;

import com.google.inject.Inject;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;

import org.jraf.blorp3.BlorpContext;
import org.jraf.blorp3.BlorpUtils;
import org.jraf.blorp3.thumbnails.ffmpeg.FfmpegService;
import org.jraf.blorp3.thumbnails.ffmpeg.VideoInfo;
import org.jraf.blorp3.thumbnails.imagemagick.ImageMagickService;

public class ThumbnailServiceImpl implements ThumbnailService {
    public static final Object SYNC = new Object();

    private BlorpContext blorpContext;
    private FfmpegService ffmpegService;
    private ImageMagickService imageMagickService;
    private BufferedImage imageVideoMask;
    private BufferedImage imageShadowTop;
    private BufferedImage imageShadowLeft;
    private BufferedImage imageShadowRight;
    private BufferedImage imageShadowBottom;
    private BufferedImage imageShadowTopLeft;
    private BufferedImage imageShadowTopRight;
    private BufferedImage imageShadowBottomLeft;
    private BufferedImage imageShadowBottomRight;


    @Inject
    private ThumbnailServiceImpl(BlorpContext blorpContext, FfmpegService ffmpegService, ImageMagickService imageMagickService) throws IOException {
        this.blorpContext = blorpContext;
        this.ffmpegService = ffmpegService;
        this.imageMagickService = imageMagickService;
        imageVideoMask = ImageIO.read(getClass().getResourceAsStream("/res/video_thumbnail_mask.png"));
        imageShadowTop = ImageIO.read(getClass().getResourceAsStream("/res/thumbnail_shadow_top.png"));
        imageShadowLeft = ImageIO.read(getClass().getResourceAsStream("/res/thumbnail_shadow_left.png"));
        imageShadowRight = ImageIO.read(getClass().getResourceAsStream("/res/thumbnail_shadow_right.png"));
        imageShadowBottom = ImageIO.read(getClass().getResourceAsStream("/res/thumbnail_shadow_bottom.png"));
        imageShadowTopLeft = ImageIO.read(getClass().getResourceAsStream("/res/thumbnail_shadow_top_left.png"));
        imageShadowTopRight = ImageIO.read(getClass().getResourceAsStream("/res/thumbnail_shadow_top_right.png"));
        imageShadowBottomLeft = ImageIO.read(getClass().getResourceAsStream("/res/thumbnail_shadow_bottom_left.png"));
        imageShadowBottomRight = ImageIO.read(getClass().getResourceAsStream("/res/thumbnail_shadow_bottom_right.png"));
    }

    public boolean isImage(File file) {
        return blorpContext.getConf().getImageFileTypes().contains(FilenameUtils.getExtension(file.getName()).toLowerCase());
    }

    public boolean isVideo(File file) {
        return blorpContext.getConf().getVideoFileTypes().contains(FilenameUtils.getExtension(file.getName()).toLowerCase());
    }


    public void createPictureThumbnails(File file) throws ThumbnailException {
        synchronized (SYNC) {
            File thumbnailFile;
            File resample640File;
            File resample800File;
            File resample1024File;
            try {
                thumbnailFile = BlorpUtils.getEquivalentBlorpFile(blorpContext, file, "resized", ".thumb.png");
                resample640File = BlorpUtils.getEquivalentBlorpFile(blorpContext, file, "resized", ".640.jpg");
                resample800File = BlorpUtils.getEquivalentBlorpFile(blorpContext, file, "resized", ".800.jpg");
                resample1024File = BlorpUtils.getEquivalentBlorpFile(blorpContext, file, "resized", ".1024.jpg");
            } catch (IOException e) {
                throw new ThumbnailException(e);
            }
            if (!thumbnailFile.exists()) {
                Dimension currentDimension;
                try {
                    currentDimension = getImageDimension(file);
                } catch (FileNotFoundException e) {
                    throw new ThumbnailException(e);
                }
//                BufferedImage img;
//                try {
//                    img = ImageIO.read(file); // this reads the content of the file (highly time consuming)
//                } catch (IOException e) {
//                    throw new ThumbnailException(e);
//                }
                try {
//                    resizePicture(img, currentDimension, 160, 160, thumbnailFile, Format.PNG);
//                    addThumbnailShadow(thumbnailFile);
//                    resizePicture(img, currentDimension, 640, 480, resample640File, Format.JPEG);
//                    resizePicture(img, currentDimension, 800, 600, resample800File, Format.JPEG);
//                    resizePicture(img, currentDimension, 1024, 768, resample1024File, Format.JPEG);
                    resizePictureImageMagick(file, currentDimension, 160, 160, thumbnailFile);
                    addThumbnailShadow(thumbnailFile);
                    resizePictureImageMagick(file, currentDimension, 640, 480, resample640File);
                    resizePictureImageMagick(file, currentDimension, 800, 600, resample800File);
                    resizePictureImageMagick(file, currentDimension, 1024, 768, resample1024File);

                } catch (IOException e) {
                    throw new ThumbnailException(e);
                }
            }
        }
    }

    public void createVideoThumbnail(File file) throws ThumbnailException {
        synchronized (SYNC) {
            File thumbnailFileFfmpeg;
            try {
                thumbnailFileFfmpeg = BlorpUtils.getEquivalentBlorpFile(blorpContext, file, "resized", ".thumb.png");
            } catch (IOException e) {
                throw new ThumbnailException(e);
            }
            if (!thumbnailFileFfmpeg.exists()) {
                VideoInfo videoInfo;
                try {
                    videoInfo = ffmpegService.getInfo(file);
                } catch (IOException e) {
                    throw new ThumbnailException(e);
                }
                try {
                    ffmpegService.generatePngFromVideo(file, videoInfo.getDimension(), 160, 160, videoInfo.getDuration() / 2, thumbnailFileFfmpeg);
                    File thumbnailFile;
                    try {
                        thumbnailFile = BlorpUtils.getEquivalentBlorpFile(blorpContext, file, "resized", ".thumb.png");
                    } catch (IOException e) {
                        throw new ThumbnailException(e);
                    }
                    addVideoMask(thumbnailFileFfmpeg, thumbnailFile, 160);
                } catch (IOException e) {
                    throw new ThumbnailException(e);
                }
            }
        }
    }

    private void addThumbnailShadow(File thumbnailFile) throws IOException {
        BufferedImage thumbnailImage = ImageIO.read(thumbnailFile);

        BufferedImage combination = new BufferedImage(thumbnailImage.getWidth(), thumbnailImage.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g = combination.createGraphics();
        g.drawImage(thumbnailImage, 0, 0, null);

        g.drawImage(imageShadowTop, 0, 0, null);
        g.drawImage(imageShadowLeft, 0, 0, null);
        g.drawImage(imageShadowRight, thumbnailImage.getWidth() - 7, 0, null);
        g.drawImage(imageShadowBottom, 0, thumbnailImage.getHeight() - 7, null);

        g.drawImage(imageShadowTopLeft, 0, 0, null);
        g.drawImage(imageShadowTopRight, thumbnailImage.getWidth() - 7, 0, null);
        g.drawImage(imageShadowBottomLeft, 0, thumbnailImage.getHeight() - 7, null);
        g.drawImage(imageShadowBottomRight, thumbnailImage.getWidth() - 7, thumbnailImage.getHeight() - 7, null);

        writePng(combination, thumbnailFile);
    }

    private void addVideoMask(File thumbnailFfmpeg, File thumbnailFile, int width) throws IOException {
        BufferedImage combinationImage = new BufferedImage(width, width, BufferedImage.TYPE_INT_RGB);
        BufferedImage thumbnailImage = ImageIO.read(thumbnailFfmpeg);
        if (thumbnailImage == null) { // ffmpeg made a 0 length thumbnail (probably unknown codec)
            return;
        }
        Graphics2D g = combinationImage.createGraphics();
        Color plainColor = new Color(198, 204, 219);
        Color semiColor = new Color(198, 204, 219, 128);

        g.setColor(plainColor);
        g.fillRect(0, 0, width, width);
        int x = (width - thumbnailImage.getWidth()) / 2;
        int y = (width - thumbnailImage.getHeight()) / 2;
        g.drawImage(thumbnailImage, x, y, null);

        int maskLeft = 19;
        int maskRight = width - maskLeft - 1;
        drawCorners(thumbnailImage, g, maskLeft, maskRight, y, plainColor, semiColor);

        if (thumbnailImage.getHeight() < width) { // draw 'before' and 'after' pictures
            g.drawImage(thumbnailImage, (width - thumbnailImage.getWidth()) / 2, (width - thumbnailImage.getHeight()) / 2 + thumbnailImage.getHeight() + 5, null);
            g.setColor(new Color(0, 0, 0, 100));
            g.fillRect((width - thumbnailImage.getWidth()) / 2, (width - thumbnailImage.getHeight()) / 2 + thumbnailImage.getHeight() + 5, thumbnailImage.getWidth(), thumbnailImage.getHeight());
            drawCorners(thumbnailImage, g, maskLeft, maskRight, (width - thumbnailImage.getHeight()) / 2 + thumbnailImage.getHeight() + 5, plainColor, semiColor);

            g.drawImage(thumbnailImage, (width - thumbnailImage.getWidth()) / 2, (width - thumbnailImage.getHeight()) / 2 - thumbnailImage.getHeight() - 5, null);
            g.setColor(new Color(0, 0, 0, 100));
            g.fillRect((width - thumbnailImage.getWidth()) / 2, (width - thumbnailImage.getHeight()) / 2 - thumbnailImage.getHeight() - 5, thumbnailImage.getWidth(), thumbnailImage.getHeight());
            drawCorners(thumbnailImage, g, maskLeft, maskRight, (width - thumbnailImage.getHeight()) / 2 - thumbnailImage.getHeight() - 5, plainColor, semiColor);
        }
        g.drawImage(imageVideoMask, 0, 0, null);

        writePng(combinationImage, thumbnailFile);
    }

    private static void drawCorners(BufferedImage thumbnailImage, Graphics2D g, int maskLeft, int maskRight, int y, Color plainColor, Color semiColor) {
        drawTopLeftCorner(g, maskLeft, y, plainColor, semiColor);
        drawTopRightCorner(g, maskRight, y, plainColor, semiColor);
        drawBottomRightCorner(thumbnailImage, g, maskLeft, y, plainColor, semiColor);
        drawBottomLeftCorner(thumbnailImage, g, maskRight, y, plainColor, semiColor);
    }

    private static void drawBottomLeftCorner(BufferedImage thumbnailImage, Graphics2D g, int x, int y, Color plainColor, Color semiColor) {
        g.setColor(plainColor);
        g.drawLine(x, y + thumbnailImage.getHeight() - 1, x, y + thumbnailImage.getHeight() - 1);
        g.drawLine(x - 1, y + thumbnailImage.getHeight() - 1, x - 1, y + thumbnailImage.getHeight() - 1);
        g.drawLine(x, y + thumbnailImage.getHeight() - 2, x, y + thumbnailImage.getHeight() - 2);
        g.setColor(semiColor);
        g.drawLine(x - 2, y + thumbnailImage.getHeight() - 1, x - 2, y + thumbnailImage.getHeight() - 1);
        g.drawLine(x, y + thumbnailImage.getHeight() - 3, x, y + thumbnailImage.getHeight() - 3);
    }

    private static void drawBottomRightCorner(BufferedImage thumbnailImage, Graphics2D g, int x, int y, Color plainColor, Color semiColor) {
        g.setColor(plainColor);
        g.drawLine(x, y + thumbnailImage.getHeight() - 1, x, y + thumbnailImage.getHeight() - 1);
        g.drawLine(x, y + thumbnailImage.getHeight() - 2, x, y + thumbnailImage.getHeight() - 2);
        g.drawLine(x + 1, y + thumbnailImage.getHeight() - 1, x + 1, y + thumbnailImage.getHeight() - 1);
        g.setColor(semiColor);
        g.drawLine(x, y + thumbnailImage.getHeight() - 3, x, y + thumbnailImage.getHeight() - 3);
        g.drawLine(x + 2, y + thumbnailImage.getHeight() - 1, x + 2, y + thumbnailImage.getHeight() - 1);
    }

    private static void drawTopRightCorner(Graphics2D g, int x, int y, Color plainColor, Color semiColor) {
        g.setColor(plainColor);
        g.drawLine(x, y, x, y);
        g.drawLine(x - 1, y, x - 1, y);
        g.drawLine(x, y + 1, x, y + 1);
        g.setColor(semiColor);
        g.drawLine(x - 2, y, x - 2, y);
        g.drawLine(x, y + 2, x, y + 2);
    }

    private static void drawTopLeftCorner(Graphics2D g, int x, int y, Color plainColor, Color semiColor) {
        g.setColor(plainColor);
        g.drawLine(x, y, x, y);
        g.drawLine(x + 1, y, x + 1, y);
        g.drawLine(x, y + 1, x, y + 1);
        g.setColor(semiColor);
        g.drawLine(x + 2, y, x + 2, y);
        g.drawLine(x, y + 2, x, y + 2);
    }


    private void resizePicture(BufferedImage img, Dimension currentDimension, int resizeWidth, int resizeHeight, File out, Format format) throws IOException {
        int scaledWidth;
        int scaledHeight;
        if (currentDimension.width >= currentDimension.height) {
            scaledWidth = resizeWidth;
            scaledHeight = (int) (((double) currentDimension.height / (double) currentDimension.width) * (double) resizeWidth);
        } else {
            scaledHeight = resizeHeight;
            scaledWidth = (int) (((double) currentDimension.width / (double) currentDimension.height) * (double) resizeHeight);
        }
        Image scaledImage = img.getScaledInstance(scaledWidth, scaledHeight, Image.SCALE_SMOOTH);
        BufferedImage processedImage = new BufferedImage(scaledWidth, scaledHeight, BufferedImage.TYPE_INT_RGB);
        processedImage.getGraphics().drawImage(scaledImage, 0, 0, Color.black, null);
        out.getParentFile().mkdirs();
        if (format == Format.JPEG) {
            writeJpeg(processedImage, out);
        } else {
            writePng(processedImage, out);
        }
    }

    private void resizePictureImageMagick(File from, Dimension currentDimension, int resizeWidth, int resizeHeight, File out) throws IOException {
        int scaledWidth;
        int scaledHeight;
        if (currentDimension.width >= currentDimension.height) {
            scaledWidth = resizeWidth;
            scaledHeight = (int) (((double) currentDimension.height / (double) currentDimension.width) * (double) resizeWidth);
        } else {
            scaledHeight = resizeHeight;
            scaledWidth = (int) (((double) currentDimension.width / (double) currentDimension.height) * (double) resizeHeight);
        }
        out.getParentFile().mkdirs();
        imageMagickService.resizeImage(from, out, scaledWidth, scaledHeight);
    }


    public Dimension getImageDimension(File file) throws ThumbnailException, FileNotFoundException {
        ImageInfo imageInfo = new ImageInfo();
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
            imageInfo.setInput(fis);
            if (!imageInfo.check()) {
                throw new ThumbnailException("imageInfo.check() returned false - " + file);
            }
            return new Dimension(imageInfo.getWidth(), imageInfo.getHeight());
        } finally {
            IOUtils.closeQuietly(fis);
        }
    }

    private void writeJpeg(BufferedImage image, File outFile) throws IOException {
        ImageWriter imageWriter = null;
        Iterator iter = ImageIO.getImageWritersByFormatName("jpg");
        if (iter.hasNext()) {
            imageWriter = (ImageWriter) iter.next();
            ImageOutputStream fos = ImageIO.createImageOutputStream(outFile);
            imageWriter.setOutput(fos);

            ImageWriteParam imageWriteParam = new JPEGImageWriteParam(Locale.getDefault());
            imageWriteParam.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
            imageWriteParam.setCompressionQuality(.95f);

            imageWriter.write(null, new IIOImage(image, null, null), imageWriteParam);

            fos.flush();
            imageWriter.dispose();
            fos.close();
        }
    }

    private void writePng(BufferedImage image, File outFile) throws IOException {
        ImageWriter imageWriter = null;
        Iterator iter = ImageIO.getImageWritersByFormatName("png");
        if (iter.hasNext()) {
            imageWriter = (ImageWriter) iter.next();
            ImageOutputStream fos = ImageIO.createImageOutputStream(outFile);
            imageWriter.setOutput(fos);

            imageWriter.write(null, new IIOImage(image, null, null), null);

            fos.flush();
            imageWriter.dispose();
            fos.close();
        }
    }
}