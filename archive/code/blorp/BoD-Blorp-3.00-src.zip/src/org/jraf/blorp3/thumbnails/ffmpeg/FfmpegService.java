/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.blorp3.thumbnails.ffmpeg;

import java.io.File;
import java.io.IOException;
import java.awt.Dimension;

public interface FfmpegService {
    VideoInfo getInfo(File videoFile) throws IOException;

    void generatePngFromVideo(File videoFile, Dimension currentDimension, int resizeWidth, int resizeHeight, long thumbnailSecond, File out) throws IOException;
}
