/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: BlorpFileItem.java 204 2008-05-16 14:38:37Z bod $
*/

package org.jraf.blorp3.renderers.common;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;

import org.jraf.blorp3.BlorpContext;
import org.jraf.blorp3.BlorpUtils;

public class BlorpFileItem {
    private File file;
    private boolean isDirectory;
    private String name;
    private String extension;
    private String icon;
    private Date dateModified;
    private long size;
    private String title;
    private String[] subTitle;
    private String nameNicePath;
    private String fileType;
    private String fullPathUrlEncoded;
    private boolean isImage;
    private boolean isVideo;

    public BlorpFileItem(BlorpContext blorpContext, File file) throws IOException {
        this.file = file;
        isDirectory = file.isDirectory();
        isImage = blorpContext.getThumbnailService().isImage(file);
        isVideo = blorpContext.getThumbnailService().isVideo(file);
        name = file.getName();
        nameNicePath = BlorpUtils.nicePath(name, false);
        extension = FilenameUtils.getExtension(name).toLowerCase();
        if (blorpContext.getConf().getAvailableIcons().contains(extension)) {
            icon = extension;
        } else {
            icon = "unknown";
        }
        dateModified = new Date(file.lastModified());
        size = file.length();

        Object[] titleSubTitle = BlorpUtils.loadTitleAndSubTitle(blorpContext, file);
        title = (String) titleSubTitle[0];
        subTitle = (String[]) titleSubTitle[1];

        if (isDirectory) {
            fileType = "Directory";
        } else {
            fileType = blorpContext.getConf().getFileType(extension);
        }
        if (fileType == null) {
            fileType = StringUtils.capitalize(extension) + " file";
        }

        fullPathUrlEncoded = file.getCanonicalPath().substring(blorpContext.getConf().getSharedRootFile().getCanonicalPath().length() + 1);
        fullPathUrlEncoded = fullPathUrlEncoded.replace('\\', '/'); // handles Windows
        fullPathUrlEncoded = BlorpUtils.urlEncodePath(fullPathUrlEncoded, blorpContext.getConf().getUrlEncodingCharset()); // url encoding
    }

    public boolean isDirectory() {
        return isDirectory;
    }

    public String getName() {
        return name;
    }

    public String getExtension() {
        return extension;
    }

    public String getIcon() {
        return icon;
    }

    public Date getDateModified() {
        return dateModified;
    }

    public long getSize() {
        return size;
    }

    public String getTitle() {
        return title;
    }

    public String getTitleOrName() {
        if (!StringUtils.isBlank(title)) {
            return title;
        } else {
            return name;
        }
    }

    public String[] getSubTitle() {
        return subTitle;
    }

    public String getNameNicePath() {
        return nameNicePath;
    }

    public String getFileType() {
        return fileType;
    }

    public String getFullPathUrlEncoded() {
        return fullPathUrlEncoded;
    }

    public boolean isImage() {
        return isImage;
    }

    public boolean isVideo() {
        return isVideo;
    }

    public File getFile() {
        return file;
    }
}
