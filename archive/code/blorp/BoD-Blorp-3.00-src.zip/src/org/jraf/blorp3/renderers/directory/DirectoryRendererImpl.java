/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: DirectoryRendererImpl.java 211 2008-05-22 16:37:38Z bod $
*/
package org.jraf.blorp3.renderers.directory;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.inject.Inject;
import freemarker.template.TemplateException;

import org.jraf.blorp3.BlorpContext;
import org.jraf.blorp3.Conf;
import org.jraf.blorp3.RenderException;
import org.jraf.blorp3.renderers.common.BlorpFile;
import org.jraf.blorp3.renderers.common.BlorpFileItem;
import org.jraf.blorp3.renderers.common.Meta;
import org.jraf.blorp3.renderers.common.Methods;
import org.jraf.blorp3.thumbnails.ThumbnailException;
import org.jraf.blorp3.thumbnails.ThumbnailService;

public class DirectoryRendererImpl implements DirectoryRenderer {
    private BlorpContext blorpContext;
    private ThumbnailService thumbnailService;
    private Conf conf;

    @Inject
    public DirectoryRendererImpl(BlorpContext blorpContext) {
        this.blorpContext = blorpContext;
        this.thumbnailService = blorpContext.getThumbnailService();
        this.conf = blorpContext.getConf();
    }

    public void render(File dir, HttpServletRequest request, HttpServletResponse res) throws RenderException {

        BlorpFile blorpFile;
        try {
            blorpFile = new BlorpFile(blorpContext, dir);
        } catch (IOException e) {
            throw new RenderException(e);
        }

        File[] files = dir.listFiles(new FileFilter() {
            public boolean accept(File pathname) {
                return !pathname.getName().startsWith(".")
                    && !conf.getHiddenFiles().contains(pathname.getName().toLowerCase());
            }
        });

        Meta meta = new Meta(blorpContext, request);
        meta.setDefaultParameter("directory_view", guessDefaultView(files));
        meta.setDefaultParameter("directory_view_sorting", "na");

        List<BlorpFileItem> fileItems = new ArrayList<BlorpFileItem>();
        List<BlorpFileItem> directoryItems = new ArrayList<BlorpFileItem>();
        for (File file : files) {
            try {
                if (file.isDirectory()) {
                    directoryItems.add(new BlorpFileItem(blorpContext, file));
                } else {
                    if (thumbnailService.isImage(file)) {
                        try {
                            thumbnailService.createPictureThumbnails(file);
                        } catch (ThumbnailException e) {
                            throw new RenderException(e);
                        }
                    } else if (thumbnailService.isVideo(file)) {
                        try {
                            thumbnailService.createVideoThumbnail(file);
                        } catch (ThumbnailException e) {
                            throw new RenderException(e);
                        }
                    }
                    fileItems.add(new BlorpFileItem(blorpContext, file));
                }
            } catch (IOException e) {
                throw new RenderException(e);
            }
        }

        BlorpFileItemComparator comparator = new BlorpFileItemComparator(meta.getParameters().get("directory_view_sorting"));
        Collections.sort(directoryItems, comparator);
        Collections.sort(fileItems, comparator);

        Map<String, Object> root = new HashMap<String, Object>();

        root.put("methods", new Methods());
        root.put("meta", meta);
        root.put("file", blorpFile);
        root.put("directories", directoryItems);
        root.put("files", fileItems);
        try {
            blorpContext.getTemplate("directory/directory.ftl").process(root, res.getWriter());
        } catch (TemplateException e) {
            throw new RenderException(e);
        } catch (IOException e) {
            throw new RenderException(e);
        }
    }

    private String guessDefaultView(File[] files) {
        int nbImageOrVideo = 0;
        for (File f : files) {
            if (thumbnailService.isImage(f) || thumbnailService.isVideo(f)) {
                nbImageOrVideo++;
            }
        }
        if (nbImageOrVideo > files.length / 2) {
            return "thumbnails";
        }
        return "tiles";
    }
}