/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.blorp3.renderers.text;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

import org.jraf.blorp3.BlorpContext;
import org.jraf.blorp3.RenderException;
import org.jraf.blorp3.renderers.common.Meta;
import org.jraf.blorp3.renderers.common.Renderer;

public class TextRenderer implements Renderer {
    private BlorpContext blorpContext;
    private String[] handledExtensions;

    public void init(BlorpContext blorpContext, Configuration conf) {
        this.blorpContext = blorpContext;
        handledExtensions = conf.getStringArray("handledExtensions");
    }

    public boolean isHandled(File file) {
        String fileExt = FilenameUtils.getExtension(file.getName());
        for (String ext : handledExtensions) {
            if (ext.equalsIgnoreCase(fileExt)) {
                return true;
            }
        }
        return false;
    }

    public void prepareRendering(File file, Map<String, Object> root, Meta meta) throws RenderException {
        try {
            root.put("lines", FileUtils.readLines(file));
        } catch (IOException e) {
            throw new RenderException(e);
        }
    }

    public String getTemplatePath() {
        return "text/text.ftl";
    }
}