/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: BlorpUtils.java 215 2008-05-23 23:54:22Z bod $
*/

package org.jraf.blorp3;

import java.awt.Font;
import java.awt.FontMetrics;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.JComponent;
import javax.swing.JPanel;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;

public class BlorpUtils {
    private static final Font CAPTION_FONT = new Font("Tahoma", Font.PLAIN, 11);
    private static final JComponent FONT_METRICS_COMPONENT = new JPanel();
    private static DecimalFormat FILESIZE_FORMAT = new DecimalFormat("#.##", new DecimalFormatSymbols(Locale.ENGLISH));

    public static int sizeOfString(String s) {
        FontMetrics fm = FONT_METRICS_COMPONENT.getFontMetrics(CAPTION_FONT);
        return fm.stringWidth(s);
    }

    public static String abbreviatePixels(String s, int pixels) {
        if (sizeOfString(s) < pixels) {
            return s;
        }
        while (sizeOfString(s + "...") > pixels) {
            s = s.substring(0, s.length() - 1);
        }
        return s + "...";
    }

    public static String abbreviatePixels(String s, int pixels, int maxLines) {
        if (sizeOfString(s) < pixels) {
            return s;
        }
        List<String> split = splitKeepSeparator(s, " \t.");
        String line = "";
        List<String> res = new ArrayList<String>();
        for (String word : split) {
            String candidate = line;

            if (sizeOfString(candidate) < pixels) {
                line += word;
            } else {
                res.add(line);
                line = word;
            }
        }
        res.add(line);
        String resString = "";
        int i = 0;
        for (String l : res) {
            if (i < maxLines) {
                if (resString.length() > 0) {
                    resString += "<br/>";
                }
                resString += l;
            }
            i++;
        }
        if (res.size() > maxLines) {
            // abbreviate last line
            resString = StringUtils.chop(resString) + "...";
        }
        return resString;
    }

    private static List<String> splitKeepSeparator(String s, String sep) {
        List<String> res = new ArrayList<String>();
        int len = s.length();
        String word = "";
        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            if (sep.indexOf(c) != -1) {
                word += c;
                res.add(word);
                word = "";
            } else {
                word += c;
            }
        }
        if (!"".equals(word)) {
            res.add(word);
        }
        return res;
    }


    public static String removeAccents(String s) {
        return StringUtils.replaceChars(s, "��������������������������������������������������", "cnCNaaaaaaeeeeiiiiooooouuuuAAAAAAEEEEIIIIOOOOOUUUU");
    }

    public static String nicePath(String path, boolean keepSlashes) {
        path = removeAccents(path);
        path = path.replace(" - ", "-"); // special case, we don't want to have " - " in urls, "-" is nicer
        path = path.replace(" ", "_");
        StringBuffer res = new StringBuffer();
        int len = path.length();
        for (int i = 0; i < len; i++) {
            char c = path.charAt(i);
            if ('0' <= c && c <= '9' || 'a' <= c && c <= 'z' || 'A' <= c && c <= 'Z' || c == '.' || c == '-' || keepSlashes && c == '/') {
                res.append(c);
            } else {
                res.append("_");
            }
        }
        return WordUtils.capitalize(res.toString());
    }

    public static boolean nicePathEquals(String path1, String path2) {
        return nicePath(path1, false).equalsIgnoreCase(nicePath(path2, false));
    }

    public static File findFileFromNicePath(File root, String nicePath) {
        String[] pathElements = StringUtils.split(nicePath, '/');
        for (String pathElem : pathElements) {
            boolean found = false;
            for (String file : root.list()) {
                if (nicePathEquals(file, pathElem)) {
                    root = new File(root, file);
                    found = true;
                    break;
                }
            }
            if (!found) { // at this point, we didn't find it: return a non-existing file
                return null;
            }
        }
        return root;
    }

    public static Object[] loadTitleAndSubTitle(BlorpContext blorpContext, File file) throws IOException {
        String[] subTitle;
        String title = null;
        File blorpDescriptionFile = getEquivalentBlorpFile(blorpContext, file, "titles", ".txt");
        if (!blorpDescriptionFile.exists()) {
            blorpDescriptionFile.getParentFile().mkdirs();
            FileOutputStream fos = null;
            try {
                fos = new FileOutputStream(blorpDescriptionFile);
            } finally {
                IOUtils.closeQuietly(fos);
            }
        }
        FileInputStream fis = null;
        List lines = null;
        try {
            fis = new FileInputStream(blorpDescriptionFile);
            lines = IOUtils.readLines(fis, "ISO_8859-1");
        } finally {
            IOUtils.closeQuietly(fis);
        }
        if (lines.size() > 0) {
            subTitle = new String[lines.size() - 1];
        } else {
            subTitle = new String[0];
        }
        int lineNumber = 0;
        for (Object line1 : lines) {
            String line = (String) line1;
            if (lineNumber == 0) {
                title = line;
            } else {
                subTitle[lineNumber - 1] = line;
            }
            lineNumber++;
        }

        return new Object[]{title, subTitle};
    }

    /**
     * Get a file equivalent to the {@code file} parameter, but inside the special .blorp directory and the
     * {@code subdirectoryName} sub directory. A suffix {@code fileNameSuffix} will be appended.
     *
     * @param blorpContext     the BlorpContext.
     * @param file             the file from which to get the equivalent blorp file.
     * @param subdirectoryName the subdirectory to use (if {@code null}, will be in the root directory).
     * @param fileNameSuffix   the suffix to append.
     * @return the equivalent file.
     * @throws IOException if the .blorp directory cannot be found.
     */
    public static File getEquivalentBlorpFile(BlorpContext blorpContext, File file, String subdirectoryName, String fileNameSuffix) throws IOException {
        String sharedRootPath = blorpContext.getConf().getSharedRootFile().getCanonicalPath();
        String relativeFilePath = file.getCanonicalPath().substring(sharedRootPath.length());
        if (relativeFilePath.length() == 0) {
            relativeFilePath = "(root folder)";
        }
        if (subdirectoryName != null) {
            relativeFilePath = subdirectoryName + "/" + relativeFilePath;
        }
        String blorpDescriptionFilePath = sharedRootPath + "/.blorp/" + relativeFilePath + fileNameSuffix;
        return new File(blorpDescriptionFilePath);
    }


    public static String formatFileSize(long size) {
        if (size == 0) {
            return "0 bytes";
        }
        if (size == 1) {
            return "1 byte";
        }
        if (size < 1024) {
            return "" + size + " bytes";
        }
        if (size < 1024 * 1024) {
            if (size % 1024 == 0) {
                return "" + size / 1024 + " KiB";
            } else {
                return FILESIZE_FORMAT.format(size / 1024.0) + " KiB";
            }
        }
        if (size < 1024 * 1024 * 1024) {
            if (size % 1024 == 0) {
                return "" + size / 1024 / 1024 + " MiB";
            } else {
                return FILESIZE_FORMAT.format(size / 1024.0 / 1024.0) + " MiB";
            }
        }
        if (size % 1024 == 0) {
            return "" + size / 1024 / 1024 + " GiB";
        } else {
            return FILESIZE_FORMAT.format(size / 1024.0 / 1024.0 / 1024.0) + " GiB";
        }
    }

    public static String urlEncodePath(String url, String encoding) throws UnsupportedEncodingException {
        String res = URLEncoder.encode(url, encoding);
        res = res.replaceAll("%2F", "/"); // keep slashes in url!
        res = res.replaceAll("\\+", "%20"); // we are escaping an url path, not a parameter
        return res;
    }

    public static String decodeUtf8(String s) {
        try {
            return new String(s.getBytes(), "utf-8");
        } catch (UnsupportedEncodingException e) {
            // this cannot happen
            throw new AssertionError(e);
        }
    }

    /**
     * Tries to exec the command, waits for it to finish.
     *
     * @param command the command to exec.
     */
    public static boolean exec(String... command) {
        ProcessBuilder processBuilder = new ProcessBuilder(command);
        processBuilder.redirectErrorStream(true);
        Process process = null;
        try {
            process = processBuilder.start();
        } catch (IOException e) {
            // todo: log
            return false;
        }
        InputStream is = process.getInputStream();
        byte[] buffer = new byte[1024];
        int read;
        do {
            try {
                read = is.read(buffer);
            } catch (IOException e) {
                // todo: log
                return false;
            }
        } while (read != -1);
        try {
            process.waitFor();
        } catch (InterruptedException e) {
            // todo: log
            return false;
        }
        try {
            return process.exitValue() == 0;
        } finally {
            process.destroy(); // just in case
        }
    }

    public static void main(String[] args) {
        System.out.println(abbreviatePixels("le directory test une tr�s longue description ceci est la phrase num�ro 42 et voici une nouvelle phrase bonjour aurevoir toto mais comme la reine et le roi ne le veulent pas �a ne sera pas toi bijour aurevoir quarente deux", 175, 13));
    }
}
