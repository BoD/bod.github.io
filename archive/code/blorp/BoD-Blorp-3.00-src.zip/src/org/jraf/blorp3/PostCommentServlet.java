/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.blorp3;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;

public class PostCommentServlet extends HttpServlet {

    public static final Object WRITE_SYNC = new Object();

    protected void doPost(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
        String fileParam = request.getParameter("file");
        String nameParam = request.getParameter("name");
        String spamParam = request.getParameter("spam");
        String commentParam = request.getParameter("comment");
        String backUrl = request.getHeader("referer");
        if (StringUtils.isEmpty(fileParam)
            || StringUtils.isEmpty(commentParam)
            || "Your comment".equalsIgnoreCase(commentParam)
            || StringUtils.isEmpty(spamParam)
            || !"no".equals(spamParam.toLowerCase())) {
            if (StringUtils.isNotEmpty(backUrl)) {
                resp.sendRedirect(backUrl);
            } else {
                String requestURI = request.getRequestURL().toString();
                String blorpRootUrl = requestURI.substring(0, requestURI.indexOf(request.getServletPath()));
                resp.sendRedirect(blorpRootUrl);
            }
            return;
        }

        fileParam = BlorpUtils.decodeUtf8(fileParam);
        commentParam = BlorpUtils.decodeUtf8(commentParam);
        nameParam = nameParam.replaceAll("\t", " ");
        if (StringUtils.isEmpty(nameParam) || "Your name".equalsIgnoreCase(nameParam)) {
            nameParam = "Anonymous Coward";
        } else {
            nameParam = BlorpUtils.decodeUtf8(nameParam);
            nameParam = nameParam.replaceAll("\t", " ");
        }

        BlorpContext blorpContext = BlorpContext.getBlorpContext();

        File file = new File(blorpContext.getConf().getSharedRootFile(), fileParam);

        File commentFile = BlorpUtils.getEquivalentBlorpFile(BlorpContext.getBlorpContext(), file, "comments", ".txt");

        synchronized (WRITE_SYNC) {
            commentFile.getParentFile().mkdirs();
            OutputStreamWriter fileWriter = new OutputStreamWriter(new FileOutputStream(commentFile, true), "utf-8");
            try {
                fileWriter. append(nameParam);
                fileWriter.append("\t");
                fileWriter.append(""+new Date().getTime());
                fileWriter.append("\t");
                fileWriter.append(request.getRemoteAddr());
                fileWriter.append("\t");
                fileWriter.append(commentParam);
                fileWriter.append("\n");
                fileWriter.flush();
            } finally {
                IOUtils.closeQuietly(fileWriter);
            }
        }

        resp.sendRedirect(backUrl);
    }
}
