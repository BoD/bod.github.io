/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.blorp3.renderers.picture;

import java.awt.Dimension;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.drew.imaging.jpeg.JpegMetadataReader;
import com.drew.imaging.jpeg.JpegProcessingException;
import com.drew.metadata.Directory;
import com.drew.metadata.Metadata;
import com.drew.metadata.Tag;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.io.FilenameUtils;

import org.jraf.blorp3.BlorpContext;
import org.jraf.blorp3.RenderException;
import org.jraf.blorp3.renderers.common.Meta;
import org.jraf.blorp3.renderers.common.Renderer;
import org.jraf.blorp3.thumbnails.ThumbnailException;

public class PictureRenderer implements Renderer {
    public static class TagAdapter {
        private Tag tag;

        public TagAdapter(Tag tag) {
            this.tag = tag;
        }

        public String getDescription() {
            try {
                return tag.getDescription();
            } catch (Exception e) {
                return "";
            }
        }

        public String getTagName() {
            try {
                return tag.getTagName();
            } catch (Exception e) {
                return "";
            }
        }
    }

    private BlorpContext blorpContext;
    private String[] handledExtensions;

    public void init(BlorpContext blorpContext, Configuration conf) {
        this.blorpContext = blorpContext;
        handledExtensions = conf.getStringArray("handledExtensions");
    }

    public boolean isHandled(File file) {
        String fileExt = FilenameUtils.getExtension(file.getName());
        for (String ext : handledExtensions) {
            if (ext.equalsIgnoreCase(fileExt)) {
                return true;
            }
        }
        return false;
    }

    public void prepareRendering(File file, Map<String, Object> root, Meta meta) throws RenderException {
        meta.setDefaultParameter("resolution", "1024x768");
        meta.setDefaultParameter("display", "normal");

        try {
            Dimension imageDimension = blorpContext.getThumbnailService().getImageDimension(file);
            root.put("width", ""+imageDimension.width);
            root.put("height", ""+imageDimension.height);
        } catch (ThumbnailException e) {
            throw new RenderException(e);
        } catch (FileNotFoundException e) {
            throw new RenderException(e);
        }

        addExifMetadata(file, root);
    }

    private void addExifMetadata(File file, Map<String, Object> root) {
        List<TagAdapter> exifTags = new ArrayList<TagAdapter>();
        try {
            Metadata metadata = JpegMetadataReader.readMetadata(file);
            for (Iterator directories = metadata.getDirectoryIterator(); directories.hasNext(); ) {
                Directory directory = (Directory)directories.next();
                Iterator tags = directory.getTagIterator();
                while (tags.hasNext()) {
                    Tag tag = (Tag)tags.next();
                    exifTags.add(new TagAdapter(tag));
                }
            }

        } catch (JpegProcessingException e) {
            // ignore problem
            // todo: log
        }
        root.put("exifTags", exifTags);
    }

    public String getTemplatePath() {
        return "picture/picture.ftl";
    }
}
