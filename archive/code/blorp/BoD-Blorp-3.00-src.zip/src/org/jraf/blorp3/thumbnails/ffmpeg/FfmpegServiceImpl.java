/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: FfmpegServiceImpl.java 215 2008-05-23 23:54:22Z bod $
*/
package org.jraf.blorp3.thumbnails.ffmpeg;

import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

import com.google.inject.Inject;
import org.apache.commons.lang.StringUtils;

import org.jraf.blorp3.BlorpUtils;
import org.jraf.blorp3.Conf;

public class FfmpegServiceImpl implements FfmpegService {
    public static final Object SYNC = new Object();

    private File pathToFfmpegExecutable;

    @Inject
    public FfmpegServiceImpl(Conf conf) {
        pathToFfmpegExecutable = conf.getPathToFfmpegExecutable();
    }

    public VideoInfo getInfo(File videoFile) throws IOException {
        synchronized (SYNC) {
            ProcessBuilder processBuilder = new ProcessBuilder(pathToFfmpegExecutable.getAbsolutePath(), "-i", videoFile.getAbsolutePath());
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            VideoInfo res = new VideoInfo();
            while ((line = reader.readLine()) != null) {
                if (line.contains("Duration:")) {
                    String[] elements = StringUtils.split(line, " ,\t");
                    String durationStr = elements[1];
                    String[] durationElements = StringUtils.split(durationStr, ":.");
                    res.setDuration(Integer.parseInt(durationElements[0]) * 60 * 60 + Integer.parseInt(durationElements[1]) * 60 + Integer.parseInt(durationElements[2]));
                    continue;
                }

                if (line.contains("Video:")) {
                    process.destroy();
                    String[] elements = StringUtils.split(line, " ,\t");
                    String resolution = elements[5];
                    String[] dimensions = resolution.split("x");
                    res.setDimension(new Dimension(Integer.parseInt(dimensions[0]), Integer.parseInt(dimensions[1])));

                    return res;
                }
            }
            return null;
        }
    }

    public void generatePngFromVideo(File videoFile, Dimension currentDimension, int resizeWidth, int resizeHeight, long thumbnailSecond, File out) throws IOException {
        synchronized (SYNC) {
            int scaledWidth;
            int scaledHeight;
            if (currentDimension.width >= currentDimension.height) {
                scaledWidth = resizeWidth;
                scaledHeight = (int) (((double) currentDimension.height / (double) currentDimension.width) * (double) resizeWidth);
                scaledHeight = (scaledHeight / 2) * 2; // must be a multiple of 2
            } else {
                scaledHeight = resizeHeight;
                scaledWidth = (int) (((double) currentDimension.width / (double) currentDimension.height) * (double) resizeHeight);
                scaledWidth = (scaledWidth / 2) * 2; // must be a multiple of 2
            }
            out.getParentFile().mkdirs();
            BlorpUtils.exec(pathToFfmpegExecutable.getAbsolutePath(), "-y", "-i", videoFile.getAbsolutePath(), "-f", "mjpeg", "-ss", "" + thumbnailSecond, "-vframes", "1", "-s", "" + scaledWidth + "x" + scaledHeight, "-an", out.getAbsolutePath());
        }
    }

}
