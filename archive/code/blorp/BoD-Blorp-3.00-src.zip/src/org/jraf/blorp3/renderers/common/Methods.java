/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: Methods.java 204 2008-05-16 14:38:37Z bod $
*/
package org.jraf.blorp3.renderers.common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import freemarker.template.SimpleScalar;
import freemarker.template.TemplateMethodModel;
import freemarker.template.TemplateModel;
import freemarker.template.TemplateModelException;
import org.apache.commons.lang.StringUtils;

import org.jraf.blorp3.BlorpUtils;

public class Methods {
    private Map<String, TemplateMethodModel> methods;

    public Methods() {
        methods = new HashMap<String, TemplateMethodModel>();

        methods.put("abbreviate", new TemplateMethodModel() {
            public TemplateModel exec(List args) throws TemplateModelException {
                if (args.size() == 2) {
                    return new SimpleScalar(StringUtils.abbreviate((String) args.get(0), new Integer((String) args.get(1))));
                }
                throw new TemplateModelException("Wrong arguments");
            }
        });

        methods.put("abbreviatePixels", new TemplateMethodModel() {
            public TemplateModel exec(List args) throws TemplateModelException {
                if (args.size() == 2) {
                    return new SimpleScalar(BlorpUtils.abbreviatePixels((String) args.get(0), new Integer((String) args.get(1))));
                }
                if (args.size() == 3) {
                    return new SimpleScalar(BlorpUtils.abbreviatePixels((String) args.get(0), new Integer((String) args.get(1)), new Integer((String) args.get(2))));
                }

                throw new TemplateModelException("Wrong arguments");
            }
        });

        methods.put("formatFileSize", new TemplateMethodModel() {
            public TemplateModel exec(List args) throws TemplateModelException {
                if (args.size() == 1) {
                    return new SimpleScalar(BlorpUtils.formatFileSize(new Long((String) args.get(0))));
                }

                throw new TemplateModelException("Wrong arguments");
            }
        });


    }

    public TemplateMethodModel get(String m) {
        return methods.get(m);
    }
}
