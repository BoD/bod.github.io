/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.blorp3.thumbnails;

import java.io.File;
import java.io.FileNotFoundException;
import java.awt.Dimension;

public interface ThumbnailService {
    boolean isImage(File file);

    boolean isVideo(File file);

    void createPictureThumbnails(File file) throws ThumbnailException;

    void createVideoThumbnail(File file) throws ThumbnailException;

    Dimension getImageDimension(File file) throws ThumbnailException, FileNotFoundException;

    static enum Format {
        JPEG,
        PNG
    }
}
