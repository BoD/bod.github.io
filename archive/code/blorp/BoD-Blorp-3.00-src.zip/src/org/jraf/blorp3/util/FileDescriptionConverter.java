/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.blorp3.util;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class FileDescriptionConverter {
    public static final String SHARED_PREFIX = "Z:\\s\\blorp_shared\\";
    public static final String BLORP_PREFIX = "Z:\\s\\blorp_shared\\.blorp\\titles\\";
    public static final String XML_FILE_NAME = "blorp.files.description.xml";

    public static final String[] PATHS = new String[]{
        "Z:\\s\\blorp_shared\\pictures\\2004-10-17 - Soir�e chez Nico",
        "Z:\\s\\blorp_shared\\pictures\\2007-11-22 - Thanksgiving in LA",
        "Z:\\s\\blorp_shared\\pictures\\2007-11-22 - Thanksgiving in LA\\lightproblem",
        "Z:\\s\\blorp_shared\\pictures\\2008-04-26 - BoD's 30th birthday party",
        "Z:\\s\\blorp_shared\\pictures\\2005-02-23 - Il neige � Choisy",
        "Z:\\s\\blorp_shared\\pictures\\2001-03-02 - Le GT du 2 mars 2001",
        "Z:\\s\\blorp_shared\\pictures\\2007-12-08 - Soir�e chez Silvia",
        "Z:\\s\\blorp_shared\\pictures\\2006-04-15 - Trip to Notthingham",
        "Z:\\s\\blorp_shared\\pictures\\2005-05-14 - A 'trip'",
        "Z:\\s\\blorp_shared\\pictures\\2006-10-06 - Republica Dominicana\\1 - Santo Domingo",
        "Z:\\s\\blorp_shared\\pictures\\2006-10-06 - Republica Dominicana\\Private",
        "Z:\\s\\blorp_shared\\pictures\\2006-10-06 - Republica Dominicana\\Private\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\2006-10-06 - Republica Dominicana\\2 - Basket",
        "Z:\\s\\blorp_shared\\pictures\\2006-10-06 - Republica Dominicana\\0 - Club Med",
        "Z:\\s\\blorp_shared\\pictures\\2006-10-06 - Republica Dominicana\\3 - Photos exp�rimentales",
        "Z:\\s\\blorp_shared\\pictures\\2006-10-06 - Republica Dominicana",
        "Z:\\s\\blorp_shared\\pictures\\2006-10-06 - Republica Dominicana\\4 - Videos",
        "Z:\\s\\blorp_shared\\pictures\\2007-08-09 - Aida in Paris",
        "Z:\\s\\blorp_shared\\pictures\\2007-08-09 - Aida in Paris\\experimental",
        "Z:\\s\\blorp_shared\\pictures\\2007-08-09 - Aida in Paris\\videos",
        "Z:\\s\\blorp_shared\\pictures\\2007-08-09 - Aida in Paris\\graffiti",
        "Z:\\s\\blorp_shared\\pictures\\2002-01-19 - Un ptit resto",
        "Z:\\s\\blorp_shared\\pictures\\2006-06-27 - France versus Espagne",
        "Z:\\s\\blorp_shared\\pictures\\2006-07-09 - 2006-07-16 - Pictures around Paris",
        "Z:\\s\\blorp_shared\\pictures\\2006-08-21 - Trip to US",
        "Z:\\s\\blorp_shared\\pictures\\2008-05-07 - Papa's visit to Paris\\10 - Le musee de l'Informatique",
        "Z:\\s\\blorp_shared\\pictures\\2008-05-07 - Papa's visit to Paris\\07 - Bike Trip",
        "Z:\\s\\blorp_shared\\pictures\\2008-05-07 - Papa's visit to Paris\\06 - Resto with the Lubeks",
        "Z:\\s\\blorp_shared\\pictures\\2008-05-07 - Papa's visit to Paris\\11 - Eiffel Tower by night",
        "Z:\\s\\blorp_shared\\pictures\\2008-05-07 - Papa's visit to Paris\\02 - Eiffel Tower",
        "Z:\\s\\blorp_shared\\pictures\\2008-05-07 - Papa's visit to Paris\\03 - Arc de Triomphe",
        "Z:\\s\\blorp_shared\\pictures\\2008-05-07 - Papa's visit to Paris\\01 - Playing the Wii",
        "Z:\\s\\blorp_shared\\pictures\\2008-05-07 - Papa's visit to Paris\\09 - La defense, la Grande Arche",
        "Z:\\s\\blorp_shared\\pictures\\2008-05-07 - Papa's visit to Paris",
        "Z:\\s\\blorp_shared\\pictures\\2008-05-07 - Papa's visit to Paris\\08 - Bois de Boulogne, Hippodrome de Longchamps",
        "Z:\\s\\blorp_shared\\pictures\\2008-05-07 - Papa's visit to Paris\\04 - Bois de Vincennes",
        "Z:\\s\\blorp_shared\\pictures\\2008-05-07 - Papa's visit to Paris\\05 - Cimetiere de Montparnasse, Sacre Coeur, Montmartre, Pigalle",
        "Z:\\s\\blorp_shared\\pictures\\2005-03-20 - Ballade � moto puis pic-nic au parc de Choisy",
        "Z:\\s\\blorp_shared\\pictures\\2003-08-02 - La mpp2k+3",
        "Z:\\s\\blorp_shared\\pictures\\2005-12-24 - Trip to LA\\panorama",
        "Z:\\s\\blorp_shared\\pictures\\2005-12-24 - Trip to LA\\foo",
        "Z:\\s\\blorp_shared\\pictures\\2005-12-24 - Trip to LA",
        "Z:\\s\\blorp_shared\\pictures\\2005-06-06 - Voyage � Montr�al",
        "Z:\\s\\blorp_shared\\pictures\\2004-09-04 - Divers Carmen",
        "Z:\\s\\blorp_shared\\pictures\\2006-04-09 - Le p�ripherique de Paris en velo",
        "Z:\\s\\blorp_shared\\pictures\\2004-12-01 - Nouvel an 2004-2005",
        "Z:\\s\\blorp_shared\\pictures\\2006-12-31 - New Years Eve party 70s style",
        "Z:\\s\\blorp_shared\\pictures\\2002-08-10 - Les vacances en Aveyron, du c�t� de Najac",
        "Z:\\s\\blorp_shared\\pictures\\2002-08-10 - Les vacances en Aveyron, du c�t� de Najac\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\2002-12-15 - Une soir�e chez Papy (Nico bourr�)",
        "Z:\\s\\blorp_shared\\pictures\\2002-12-15 - Une soir�e chez Papy (Nico bourr�)\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\2004-10-31 - Italie",
        "Z:\\s\\blorp_shared\\pictures\\2005-02-12 - Nouvel an Chinois 2005",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2002-08-14 - Divers famille",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2001-12-24 - No�l 2001\\sounds",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2001-12-24 - No�l 2001",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2002-12-24 - No�l 2002",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2006-11-25 - Thanksgiving in France",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2003-06-07 - Divers famille",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2001-12-23 - Mes toutes premi�res photos num�riques !",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2007-01-27 - Trip to Notthingham",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2002-01-27 - Anniv Mlax 2002",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2002-04-20 - Visite en Angleterre chez Aissy",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2003-09-28 - L'anniv de Lucas",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2003-09-28 - L'anniv de Lucas\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2002-08-30 - Divers famille",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2004-04-11 - Chez Anclax et Phlax",
        "Z:\\s\\blorp_shared\\pictures\\0 - Famille\\2003-07-03 - La moto de Phil",
        "Z:\\s\\blorp_shared\\pictures\\2004-10-28 - Viaggio in Italia",
        "Z:\\s\\blorp_shared\\pictures\\2005-01-15 - Trip to LA",
        "Z:\\s\\blorp_shared\\pictures\\2006-03-15 - New bike",
        "Z:\\s\\blorp_shared\\pictures\\2004-08-21 - Mariage de Dec et Gwen",
        "Z:\\s\\blorp_shared\\pictures\\2008-02-09 - Around Paris et Bois de Vincennes",
        "Z:\\s\\blorp_shared\\pictures\\2006-06-12 - Le canal de l'Ourcq",
        "Z:\\s\\blorp_shared\\pictures\\2003-08-23 - Weekend sur la p�niche de Yo",
        "Z:\\s\\blorp_shared\\pictures\\2003-08-23 - Weekend sur la p�niche de Yo\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\2005-11-19 - Trip to LA",
        "Z:\\s\\blorp_shared\\pictures\\2007-07-22 - Trappes",
        "Z:\\s\\blorp_shared\\pictures\\2007-03-24 - Trip to Amsterdam",
        "Z:\\s\\blorp_shared\\pictures\\2004-10-02 - Mariage Virginnie et Jocelyn",
        "Z:\\s\\blorp_shared\\pictures\\2006-03-04 - Viaggio in Venezia",
        "Z:\\s\\blorp_shared\\pictures\\2002-09-28 - Une soir�e chez Drixe",
        "Z:\\s\\blorp_shared\\pictures\\2002-04-27 - La cr�maill�re chez Dectose & Gwen !",
        "Z:\\s\\blorp_shared\\pictures\\2002-03-23 - Un petit weekend au ski",
        "Z:\\s\\blorp_shared\\pictures\\2002-03-23 - Un petit weekend au ski\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\2005-06-03 - Viatge a Barcelona",
        "Z:\\s\\blorp_shared\\pictures\\2003-08-09 - L'anniv de Tentriss",
        "Z:\\s\\blorp_shared\\pictures\\2006-06-17 - Paris - la Defense - Cimetiere Militaire Americain",
        "Z:\\s\\blorp_shared\\pictures\\2006-08-14 - Disneyland Resort Paris",
        "Z:\\s\\blorp_shared\\pictures\\2004-09-06 - La Reunion",
        "Z:\\s\\blorp_shared\\pictures\\2001-07-20 - Les vacances au Qu�bec en �t� 2001",
        "Z:\\s\\blorp_shared\\pictures\\2008-02-29 - Toulouse\\Animated GIF - Around Carmen",
        "Z:\\s\\blorp_shared\\pictures\\2008-02-29 - Toulouse",
        "Z:\\s\\blorp_shared\\pictures\\2008-02-29 - Toulouse\\Panorama - Vue des toits de Toulouse",
        "Z:\\s\\blorp_shared\\pictures\\2008-02-29 - Toulouse\\Panorama - Place du Capitole",
        "Z:\\s\\blorp_shared\\pictures\\2007-05-02 - Espa�a - Cantabria",
        "Z:\\s\\blorp_shared\\pictures\\2003-01-17 - La Clusaz 2003\\Videos - soir",
        "Z:\\s\\blorp_shared\\pictures\\2003-01-17 - La Clusaz 2003\\Photos\\Jour 4 5 6",
        "Z:\\s\\blorp_shared\\pictures\\2003-01-17 - La Clusaz 2003\\Photos\\Jour 7 8",
        "Z:\\s\\blorp_shared\\pictures\\2003-01-17 - La Clusaz 2003\\Photos\\Jour 1 2 3",
        "Z:\\s\\blorp_shared\\pictures\\2003-01-17 - La Clusaz 2003\\Photos",
        "Z:\\s\\blorp_shared\\pictures\\2003-01-17 - La Clusaz 2003",
        "Z:\\s\\blorp_shared\\pictures\\2003-01-17 - La Clusaz 2003\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\2007-04-07 - Brussels - Vimy",
        "Z:\\s\\blorp_shared\\pictures\\2005-11-05 - Les 30 ans de Dectose",
        "Z:\\s\\blorp_shared\\pictures\\2000-07-01 - Les vacances d'Annie en France",
        "Z:\\s\\blorp_shared\\pictures\\2005-04-30 - Ballade � la for�t de Fontainebleau",
        "Z:\\s\\blorp_shared\\pictures\\2005-08-14 - Travaux cuisine",
        "Z:\\s\\blorp_shared\\pictures\\2007-04-11 - Andrew dodo-ing",
        "Z:\\s\\blorp_shared\\pictures\\2004-10-18 - Unfreeze",
        "Z:\\s\\blorp_shared\\pictures\\2007-07-14 - 14 July Fireworks",
        "Z:\\s\\blorp_shared\\pictures\\2005-07-16 - Trip to Rotterdam (Jim's Houseboat)",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\2002-02-08 - Soir�e",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\2002-02-08 - Soir�e\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\2002-01-28 - Une petite soir�e chez Papy",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\2001-10-26 - Soir�e",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\2001-10-26 - Soir�e\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\2002-12-15 - La remise des dipl�mes Epita",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\2002-12-15 - La remise des dipl�mes Epita\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\logos esol",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\2001-06-27 - Les esol au dom's bar",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\2001-06-27 - Les esol au dom's bar\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\2001-12-28 - Vacances aux USA 2001\\sounds",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\2001-12-28 - Vacances aux USA 2001",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\2001-12-28 - Vacances aux USA 2001\\videos",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\2001-01-16 - Une petite soir�e chez Papy",
        "Z:\\s\\blorp_shared\\pictures\\0 - esol\\2001-01-16 - Une petite soir�e chez Papy\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\2005-06-18 - Pic nic sur les quais de Seine",
        "Z:\\s\\blorp_shared\\pictures\\2003-10-07 - Reis aan Amsterdam",
        "Z:\\s\\blorp_shared\\pictures\\2003-10-07 - Reis aan Amsterdam\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\0 - Misc",
        "Z:\\s\\blorp_shared\\pictures\\0 - Misc\\Flowers",
        "Z:\\s\\blorp_shared\\pictures\\2002-08-22 - Vacances � Tignes",
        "Z:\\s\\blorp_shared\\pictures\\2002-08-22 - Vacances � Tignes\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\2003-03-29 - Une soir�e chez BoD",
        "Z:\\s\\blorp_shared\\pictures\\2003-08-27 - Les vacances de Carmen en France",
        "Z:\\s\\blorp_shared\\pictures\\2005-12-18 - Lego\\Very Strange",
        "Z:\\s\\blorp_shared\\pictures\\2005-12-18 - Lego",
        "Z:\\s\\blorp_shared\\pictures\\2004-04-30 - Viaje a Madrid",
        "Z:\\s\\blorp_shared\\pictures\\2007-09-07 - Vacances en Sicile\\Auto-portraits crazy",
        "Z:\\s\\blorp_shared\\pictures\\2007-09-07 - Vacances en Sicile\\Mont Etna",
        "Z:\\s\\blorp_shared\\pictures\\2007-09-07 - Vacances en Sicile\\Photos � caract�re artistique",
        "Z:\\s\\blorp_shared\\pictures\\2007-09-07 - Vacances en Sicile",
        "Z:\\s\\blorp_shared\\pictures\\2007-09-07 - Vacances en Sicile\\GIF anim�es",
        "Z:\\s\\blorp_shared\\pictures\\2007-09-07 - Vacances en Sicile\\Videos",
        "Z:\\s\\blorp_shared\\pictures\\2007-09-07 - Vacances en Sicile\\Panoramas (QTVR)",
        "Z:\\s\\blorp_shared\\pictures\\2006-07-06 - France versus Portugal",
        "Z:\\s\\blorp_shared\\pictures\\2004-10-10 - Montreal",
        "Z:\\s\\blorp_shared\\pictures\\2005-10-29 - London",
        "Z:\\s\\blorp_shared\\pictures\\2006-09-22 - RATP",
        "Z:\\s\\blorp_shared\\pictures\\2004-05-22 - Un ptit picnic au parc de Bercy",
        "Z:\\s\\blorp_shared\\pictures\\2007-03-24 - Amsterdam",
        "Z:\\s\\blorp_shared\\pictures\\2001-07-27 - La mpp2k+1",
        "Z:\\s\\blorp_shared\\pictures\\2005-05-28 - Star Wars",
        "Z:\\s\\blorp_shared",
        "Z:\\s\\blorp_shared\\plan\\2004-06-09-0000",
        "Z:\\s\\blorp_shared\\plan\\2006-02-12-0000",
        "Z:\\s\\blorp_shared\\plan\\2004-05-10-0000",
        "Z:\\s\\blorp_shared\\plan\\2006-07-10-0000",
        "Z:\\s\\blorp_shared\\plan\\2004-08-26-0000",
        "Z:\\s\\blorp_shared\\plan",
        "Z:\\s\\blorp_shared\\plan\\2003-11-15-0000",
    };

    public static void go(String path) throws ParserConfigurationException, IOException, SAXException {
        File fileDescriptionsFile = new File(path, XML_FILE_NAME);
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        Document doc = documentBuilderFactory.newDocumentBuilder().parse(fileDescriptionsFile);
        NodeList fileNodes = doc.getDocumentElement().getElementsByTagName("file");
        int filesLength = fileNodes.getLength();
        for (int i = 0; i < filesLength; i++) {
            Element fileElement = (Element) fileNodes.item(i);
            String name = fileElement.getAttribute("name");
            NodeList titleNodes = fileElement.getElementsByTagName("title");
            Element titleElement = (Element) titleNodes.item(0);
            String title = titleElement.getTextContent();

            String description = null;

            NodeList descriptionNodes = fileElement.getElementsByTagName("description");
            if (descriptionNodes.getLength() > 0) {
                Element descriptionElement = (Element) descriptionNodes.item(0);
                description = descriptionElement.getTextContent();
            }

            String fileName = BLORP_PREFIX + "\\" + fileDescriptionsFile.getParentFile().getAbsolutePath().substring(SHARED_PREFIX.length()) + "\\"+ name + ".txt";

            File result = new File(fileName);
            System.out.println(result);
            result.getParentFile().mkdirs();
            if (description == null) {
                FileUtils.writeLines(result, Arrays.asList(title));
            } else {
                FileUtils.writeLines(result, Arrays.asList(title, description));
            }
        }
    }

    public static void main(String[] args) throws ParserConfigurationException, IOException, SAXException {
        for (String path : PATHS) {
            System.out.println("=============");
            System.out.println(path);
            go(path);
        }
    }
}
