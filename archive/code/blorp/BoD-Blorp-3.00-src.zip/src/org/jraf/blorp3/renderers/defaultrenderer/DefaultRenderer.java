/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.blorp3.renderers.defaultrenderer;

import java.io.File;
import java.util.Map;

import org.apache.commons.configuration.Configuration;

import org.jraf.blorp3.BlorpContext;
import org.jraf.blorp3.RenderException;
import org.jraf.blorp3.renderers.common.Meta;
import org.jraf.blorp3.renderers.common.Renderer;

public class DefaultRenderer implements Renderer {

    public void init(BlorpContext blorpContext, Configuration conf) {
    }

    public boolean isHandled(File file) {
        return true;
    }

    public void prepareRendering(File file, Map<String, Object> root, Meta meta) throws RenderException {
    }

    public String getTemplatePath() {
        return "defaultrenderer/default.ftl";
    }
}