/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: BlorpFile.java 208 2008-05-18 20:39:32Z bod $
*/
package org.jraf.blorp3.renderers.common;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import org.jraf.blorp3.BlorpContext;
import org.jraf.blorp3.BlorpUtils;

public class BlorpFile {
    private String name;
    private String title;
    private String[] subTitle;
    private Date dateModified;
    private long size;
    private String previous;
    private String next;
    private String parent;
    private List<PathElement> pathElements;
    private String fullPathUrlEncoded;
    private String fullPath;
    private boolean isDirectory;

    public BlorpFile(BlorpContext blorpContext, File file) throws IOException {
        isDirectory = file.isDirectory();
        name = file.getName();
        dateModified = new Date(file.lastModified());
        size = file.length();
        pathElements = new ArrayList<PathElement>();
        if (!file.equals(blorpContext.getConf().getSharedRootFile())) {
            String path = file.getCanonicalPath().substring(blorpContext.getConf().getSharedRootFile().getCanonicalPath().length() + 1);
            path = path.replace('\\', '/'); // handles Windows
            int lastSeparator = path.lastIndexOf('/');
            if (lastSeparator == -1) {
                if (path.length() != 0) {
                    parent = "";
                }
            } else {
                parent = BlorpUtils.nicePath(path.substring(0, path.lastIndexOf('/')), true);
            }
            String[] subPaths = StringUtils.split(path, '/');
            String currentElementPath = "";
            for (String subPath : subPaths) {
                if (!"".equals(currentElementPath)) {
                    currentElementPath += '/';
                }
                currentElementPath += subPath;
                File currentElementFile = new File(blorpContext.getConf().getSharedRootFile().getCanonicalPath(), currentElementPath);
                String elementTitle = (String) BlorpUtils.loadTitleAndSubTitle(blorpContext, currentElementFile)[0];
                if (elementTitle == null) {
                    elementTitle = subPath;
                }
                pathElements.add(new PathElement(subPath, currentElementPath, elementTitle, currentElementFile.isDirectory()));
            }
            fullPath = currentElementPath;
            fullPathUrlEncoded = BlorpUtils.urlEncodePath(currentElementPath, blorpContext.getConf().getUrlEncodingCharset());
        }
        Object[] titleSubTitle = BlorpUtils.loadTitleAndSubTitle(blorpContext, file);
        title = (String) titleSubTitle[0];
        subTitle = (String[]) titleSubTitle[1];
    }

    public String getName() {
        return name;
    }

    public String getTitle() {
        return title;
    }

    public String getTitleOrName() {
        if (!StringUtils.isBlank(title)) {
            return title;
        } else {
            return name;
        }
    }

    public String[] getSubTitle() {
        return subTitle;
    }

    public String getPrevious() {
        return previous;
    }

    public String getNext() {
        return next;
    }

    public String getParent() {
        return parent;
    }

    public List<PathElement> getPathElements() {
        return pathElements;
    }

    public String getFullPathUrlEncoded() {
        return fullPathUrlEncoded;
    }

    public boolean isDirectory() {
        return isDirectory;
    }

    public Date getDateModified() {
        return dateModified;
    }

    public long getSize() {
        return size;
    }

    public String getFullPath() {
        return fullPath;
    }
}
