/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.blorp3.renderers.common;

import java.io.File;
import java.util.Map;

import org.apache.commons.configuration.Configuration;

import org.jraf.blorp3.BlorpContext;
import org.jraf.blorp3.RenderException;

public interface Renderer {
    void init(BlorpContext blorpContext, Configuration conf);
    boolean isHandled(File file);
    void prepareRendering(File file, Map<String, Object> root, Meta meta) throws RenderException;
    String getTemplatePath();
}
