/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: BlorpContext.java 215 2008-05-23 23:54:22Z bod $
*/

package org.jraf.blorp3;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.google.inject.Binder;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;
import com.google.inject.Scopes;
import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.Template;
import freemarker.template.TemplateException;

import org.jraf.blorp3.renderers.common.Renderer;
import org.jraf.blorp3.renderers.defaultrenderer.DefaultRenderer;
import org.jraf.blorp3.renderers.directory.DirectoryRenderer;
import org.jraf.blorp3.renderers.directory.DirectoryRendererImpl;
import org.jraf.blorp3.thumbnails.ThumbnailService;
import org.jraf.blorp3.thumbnails.ThumbnailServiceImpl;
import org.jraf.blorp3.thumbnails.ffmpeg.FfmpegService;
import org.jraf.blorp3.thumbnails.ffmpeg.FfmpegServiceImpl;
import org.jraf.blorp3.thumbnails.imagemagick.ImageMagickService;
import org.jraf.blorp3.thumbnails.imagemagick.ImageMagickServiceImpl;

public class BlorpContext extends GenericServlet implements Module {
    private Conf conf;
    private Configuration freemarkerConfig;
    private Injector injector;
    private Set<Renderer> renderers;
    private Renderer defaultRenderer;
    private static BlorpContext singleton;

    public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
        throw new UnsupportedOperationException("BlorpContext.service() not supported");
    }

    public void init() throws ServletException {
        try {
            conf = new Conf();
        } catch (ConfException e) {
            throw new ServletException("Could not load blorp.properties file", e);
        }

        try {
            initFreemarker();
        } catch (Exception e) {
            throw new ServletException("Could not initialize Freemarker", e);
        }
        injector = Guice.createInjector(this);
        try {
            initRenderers();
        } catch (ClassNotFoundException e) {
            throw new ServletException("Could not initialize renderers", e);
        } catch (IllegalAccessException e) {
            throw new ServletException("Could not initialize renderers", e);
        } catch (InstantiationException e) {
            throw new ServletException("Could not initialize renderers", e);
        }

        singleton = this;
    }

    private void initFreemarker() throws IOException, TemplateException {
        freemarkerConfig = new Configuration();
        freemarkerConfig.setClassForTemplateLoading(getClass(), "/templates");
        freemarkerConfig.setObjectWrapper(new DefaultObjectWrapper());
        freemarkerConfig.setSetting("url_escaping_charset", conf.getUrlEncodingCharset());
    }

    private void initRenderers() throws ClassNotFoundException, IllegalAccessException, InstantiationException, ServletException {
        defaultRenderer = new DefaultRenderer();
        defaultRenderer.init(this, null);
        renderers = new HashSet<Renderer>();
        for (String rendererClassName : conf.getRenderers()) {
            Object rendererObject = Class.forName(rendererClassName).newInstance();
            if (!(rendererObject instanceof Renderer)) {
                throw new ServletException("Renderer '"+rendererClassName+"' is not an implementation of "+Renderer.class.getName());
            }
            Renderer renderer = (Renderer)rendererObject;
            renderer.init(this, conf.getRendererConf(rendererClassName));
            renderers.add(renderer);
        }
    }


    public Template getTemplate(String templateName) throws IOException {
        return freemarkerConfig.getTemplate(templateName);
    }

    public void configure(Binder binder) {
        binder.bind(BlorpContext.class).toInstance(this);
        binder.bind(Conf.class).toInstance(conf);
        binder.bind(FfmpegService.class).to(FfmpegServiceImpl.class).in(Scopes.SINGLETON);
        binder.bind(ImageMagickService.class).to(ImageMagickServiceImpl.class).in(Scopes.SINGLETON);
        binder.bind(ThumbnailService.class).to(ThumbnailServiceImpl.class).in(Scopes.SINGLETON);
        binder.bind(DirectoryRenderer.class).to(DirectoryRendererImpl.class).in(Scopes.SINGLETON);
    }

    public static BlorpContext getBlorpContext() {
        return singleton;
    }

    public Conf getConf() {
        return injector.getInstance(Conf.class);
    }

    public ThumbnailService getThumbnailService() {
        return injector.getInstance(ThumbnailService.class);
    }

    public DirectoryRenderer getDirectoryRenderer() {
        return injector.getInstance(DirectoryRenderer.class);
    }

    public FfmpegService getFfmpegService() {
        return injector.getInstance(FfmpegService.class);
    }

    public Set<Renderer> getRenderers() {
        return renderers;
    }

    public Renderer getDefaultRenderer() {
        return defaultRenderer;
    }
}