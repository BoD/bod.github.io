/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.blorp3.thumbnails.imagemagick;

import java.io.File;

import com.google.inject.Inject;

import org.jraf.blorp3.BlorpUtils;
import org.jraf.blorp3.Conf;

public class ImageMagickServiceImpl implements ImageMagickService {
    public static final Object SYNC = new Object();

    private File pathToImageMagickExecutable;

    @Inject
    public ImageMagickServiceImpl(Conf conf) {
        pathToImageMagickExecutable = conf.getPathToImageMagickExecutable();
    }

    public void resizeImage(File in, File out, int width, int height) {
        synchronized (SYNC) {
            BlorpUtils.exec(pathToImageMagickExecutable.getAbsolutePath(), "-geometry", width + "x" + height, "-quality", "85", in.getAbsolutePath()+"[0]", out.getAbsolutePath());
        }
    }
}
