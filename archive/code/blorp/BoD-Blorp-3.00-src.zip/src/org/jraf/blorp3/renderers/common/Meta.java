/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: Meta.java 211 2008-05-22 16:37:38Z bod $
*/
package org.jraf.blorp3.renderers.common;

import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import org.jraf.blorp3.BlorpContext;

public class Meta {
    private String blorpRootUrl;
    private String sharedRootUrl;
    private String generatedRootUrl;
    private String userAgent;
    private String skin;
    private Map<String, String> parameters;

    public Meta(BlorpContext blorpContext, HttpServletRequest request) {
        String requestURI = request.getRequestURL().toString();
        blorpRootUrl = requestURI.substring(0, requestURI.indexOf(request.getServletPath()));

        sharedRootUrl = blorpContext.getConf().getSharedRootUrl();
        generatedRootUrl = blorpContext.getConf().getGeneratedRootUrl();

        userAgent = request.getHeader("User-Agent");
        if (userAgent == null) {
            userAgent = "other";
        } else if (userAgent.toLowerCase().indexOf("msie") != -1) {
            userAgent = "ie";
        } else if (userAgent.toLowerCase().indexOf("safari") != -1) {
            userAgent = "safari";
        } else if (userAgent.toLowerCase().indexOf("gecko") != -1) {
            userAgent = "mozilla";
        } else {
            userAgent = "other";
        }

        skin = "blue"; // todo

        parameters = (Map<String, String>) request.getSession().getAttribute("parameters");
        if (parameters == null) {
            parameters = new HashMap<String, String>();
            request.getSession().setAttribute("parameters", parameters);
        }

        // fill parameters with request parameters
        for (Object o : request.getParameterMap().keySet()) {
            String key = (String) o;
            String value = request.getParameter(key);
            parameters.put(key, value);
        }
    }

    public String getBlorpRootUrl() {
        return blorpRootUrl;
    }

    public String getSharedRootUrl() {
        return sharedRootUrl;
    }

    public String getGeneratedRootUrl() {
        return generatedRootUrl;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public String getSkin() {
        return skin;
    }

    public Map<String, String> getParameters() {
        return parameters;
    }

    public void setDefaultParameter(String key, String value) {
        if (!parameters.containsKey(key)) {
            parameters.put(key, value);
        }
    }
}