/*
This source is part of the
	 _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
							 /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: BlorpServlet.java 215 2008-05-23 23:54:22Z bod $
*/
package org.jraf.blorp3;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import freemarker.template.TemplateException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;

import org.jraf.blorp3.renderers.common.BlorpFile;
import org.jraf.blorp3.renderers.common.BlorpFileItem;
import org.jraf.blorp3.renderers.common.Comment;
import org.jraf.blorp3.renderers.common.Meta;
import org.jraf.blorp3.renderers.common.Methods;
import org.jraf.blorp3.renderers.common.Renderer;
import org.jraf.blorp3.renderers.directory.BlorpFileItemComparator;

public class BlorpServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse res) throws ServletException, IOException {
        BlorpContext blorpContext = BlorpContext.getBlorpContext();
        String path = request.getPathInfo();
        if (path == null) {
            path = "";
        } else {
            path = path.substring(1);
        }
        File file = BlorpUtils.findFileFromNicePath(blorpContext.getConf().getSharedRootFile(), path);
        res.setContentType("text/html; charset=UTF-8");
        if (file.isDirectory()) {
            if (!request.getRequestURI().endsWith("/")) {
                res.sendRedirect(request.getRequestURI() + "/");
            } else {
                try {
                    processDir(blorpContext, file, request, res);
                } catch (RenderException e) {
                    throw new ServletException(e);
                }
            }
        } else {
            try {
                processFile(blorpContext, file, request, res);
            } catch (RenderException e) {
                throw new ServletException(e);
            }
        }
    }

    private void processDir(BlorpContext blorpContext, File dir, HttpServletRequest request, HttpServletResponse res) throws RenderException {
        blorpContext.getDirectoryRenderer().render(dir, request, res);
    }

    private void processFile(final BlorpContext blorpContext, File file, HttpServletRequest request, HttpServletResponse res) throws RenderException {
        // find the previous and next files
        File[] files = file.getParentFile().listFiles(new FileFilter() {
            public boolean accept(File pathname) {
                return !".blorp".equals(pathname.getName())
                    && !pathname.getName().startsWith(".")
                    && !blorpContext.getConf().getHiddenFiles().contains(pathname.getName().toLowerCase())
                    && !pathname.isDirectory();
            }
        });
        List<BlorpFileItem> fileItems = new ArrayList<BlorpFileItem>();
        for (File fileItem : files) {
            try {
                fileItems.add(new BlorpFileItem(blorpContext, fileItem));
            } catch (IOException e) {
                throw new RenderException(e);
            }
        }

        Meta meta = new Meta(blorpContext, request);
        meta.setDefaultParameter("directory_view_sorting", "na");

        BlorpFileItemComparator comparator = new BlorpFileItemComparator(meta.getParameters().get("directory_view_sorting"));
        Collections.sort(fileItems, comparator);
        BlorpFileItem previous = null;
        BlorpFileItem next = null;
        int i = 0;
        for (BlorpFileItem blorpFileItem : fileItems) {
            if (blorpFileItem.getFile().equals(file)) {
                if (i > 0) {
                    previous = fileItems.get(i - 1);
                }
                if (i < fileItems.size() - 1) {
                    next = fileItems.get(i + 1);
                }
                break;
            }
            i++;
        }

        Map<String, Object> root = new HashMap<String, Object>();
        root.put("methods", new Methods());
        root.put("previous", previous);
        root.put("next", next);
        root.put("comments", getComments(blorpContext, file));
        root.put("meta", meta);
        BlorpFile blorpFile;
        try {
            blorpFile = new BlorpFile(blorpContext, file);
        } catch (IOException e) {
            throw new RenderException(e);
        }
        root.put("file", blorpFile);

        Renderer renderer = blorpContext.getDefaultRenderer();
        for (Renderer r : blorpContext.getRenderers()) {
            if (r.isHandled(file)) {
                renderer = r;
                break;
            }
        }
        renderer.prepareRendering(file, root, meta);
        try {
            blorpContext.getTemplate(renderer.getTemplatePath()).process(root, res.getWriter());
        } catch (TemplateException e) {
            throw new RenderException(e);
        } catch (IOException e) {
            throw new RenderException(e);
        }
    }

    private List<Comment> getComments(BlorpContext blorpContext, File file) throws RenderException {
        List<Comment> res = new ArrayList<Comment>();
        File commentFile;
        try {
            commentFile = BlorpUtils.getEquivalentBlorpFile(BlorpContext.getBlorpContext(), file, "comments", ".txt");
        } catch (IOException e) {
            throw new RenderException(e);
        }
        if (commentFile.exists()) {
            try {
                for (LineIterator i = FileUtils.lineIterator(commentFile, "utf-8"); i.hasNext();) {
                    res.add(new Comment(i.nextLine()));
                }
            } catch (IOException e) {
                throw new RenderException(e);
            }
        }
        return res;
    }
}
