/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: PathElement.java 204 2008-05-16 14:38:37Z bod $
*/
package org.jraf.blorp3.renderers.common;

import org.jraf.blorp3.BlorpUtils;

public class PathElement {
    private String name;
    private String path;
    private String nicePath;
    private String title;
    private boolean isDirectory;

    public PathElement(String name, String path, String title, boolean isDirectory) {
        this.name = name;
        this.path = path;
        this.title = title;
        this.isDirectory = isDirectory;
        nicePath = BlorpUtils.nicePath(path, true);
    }

    public String getName() {
        return name;
    }

    public String getPath() {
        return path;
    }

    public String getTitle() {
        return title;
    }

    public String getNicePath() {
        return nicePath;
    }

    public boolean isDirectory() {
        return isDirectory;
    }
}
