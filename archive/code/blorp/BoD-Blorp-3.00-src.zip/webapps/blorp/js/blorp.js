function showHideId(id) {
	if (document.getElementById(id).style.display == "none") {
		document.getElementById(id).style.display = "";
	} else {
		document.getElementById(id).style.display = "none";
	}
}

function showHideClass(tagType, className, textId, textShow, imgShow, textHide, imgHide) {
    var elements = document.getElementsByTagName(tagType);
    for (var i = 0; i < elements.length; i++) {
        if (elements[i].className == className) {
            if (elements[i].style.display == "none") {
                elements[i].style.display = "";
                document.getElementById(textId).innerHTML = "<img src='" + imgHide + "' class='file-img' alt='" + textHide + "'/>" + textHide;
            } else {
                elements[i].style.display = "none";
                document.getElementById(textId).innerHTML = "<img src='" + imgShow + "' class='file-img' alt='" + textShow + "'/>" + textShow;
            }
        }
    }
    positionFooter();
}

function fitToScreenPicture(id, width, height) {
    var img = document.getElementById(id);
    if ((document.body.clientWidth - 10) / (document.body.clientHeight - img.offsetTop - 10) < width / height) {
        img.width = document.body.clientWidth - 10;
    } else {
        img.height = document.body.clientHeight - img.offsetTop - 10;
    }
}

function inputFocus(element, text, className) {
    if (element.value == text) {
        element.className = className;
        element.value = '';
    }
}

function inputBlur(element, text, className) {
    if (element.value == null || element.value.length == 0) {
        element.className = className;
        element.value = text;
    }
}

function positionFooter() {
    var footer = document.getElementById("footer");
    var body =  document.getElementsByTagName("body")[0];
    footer.style.top = 0;
    footer.className = "footer";
    /* scrollbar: position it at the end of the page */
    if (body.clientHeight < body.scrollHeight) {
        footer.style.top = body.scrollHeight;
    } else {
        footer.style.top = body.clientHeight - 1;
    }
}