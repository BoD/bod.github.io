package com.c3dric.bod.mrrandom;


import java.io.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;

import com.c3dric.bod.util.*;



public class MrRandom extends JFrame implements ComponentListener,ActionListener,DocumentListener
{
	protected JLabel number;
	protected JPanel controls;
	protected JLabel maxLbl;
	protected JTextField maxFld;
	protected JButton doBtn;
	protected JButton aboutBtn;
	protected JButton quitBtn;
	protected JToolBar tb;

	protected Version version;
	protected int randomSpace;
	protected Random random;
	protected String font;
	
	protected boolean isDisabled;
	
		
	public MrRandom()
	{
		/*
		int[] copyYears = {2000};
		version = new Version("BoD","BoD inc.","Mr Random",copyYears,1,2,0,false,"","MrRandom@bod.c3dric.com","http://bod.c3dric.com/software","BoD","Kawa 3.22",null,true);
		try
		{
			version.dump();
		}
		catch (Exception e)
		{
		}
		*/
		try
		{
			version = new Version();
		}
		catch (Exception e)
		{
		}
		
		number = new JLabel("Mr Random",SwingConstants.CENTER);
		getContentPane().add(number,"Center");
		
		controls = new JPanel(new BorderLayout());
		getContentPane().add(controls,"South");
		
		tb = new JToolBar();
		controls.add(tb);
		
		maxLbl = new JLabel("Random space : ");
		tb.add(maxLbl);
		
		maxFld = new JTextField(10);
		maxFld.getDocument().addDocumentListener(this);
		tb.add(maxFld);
		
		doBtn = new JButton("Randomize",new ImageIcon("tick.gif"));
		doBtn.setActionCommand("randomize");
		doBtn.addActionListener(this);
		tb.add(doBtn);

		tb.addSeparator();
		
		aboutBtn = new JButton("About...",new ImageIcon("about.gif"));
		aboutBtn.setActionCommand("about");
		aboutBtn.addActionListener(this);
		tb.add(aboutBtn);

		quitBtn = new JButton("Quit",new ImageIcon("quit.gif"));
		quitBtn.setActionCommand("quit");
		quitBtn.addActionListener(this);
		tb.add(quitBtn);

		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent evt)
			{
		  		quit();
			}
		});
		addComponentListener(this);
		
		Properties props = new Properties();
		try
		{
			props.load(new FileInputStream(version.productSimple()+".ini"));
		}
		catch (Exception e)
		{
			props.setProperty("randomSpace","256");
			props.setProperty("font","Serif");
		}
		maxFld.setText(props.getProperty("randomSpace"));
		font = props.getProperty("font");
		changedUpdate(null);
		
		random = new Random();

		setIconImage((new ImageIcon("logo.gif")).getImage());
		setTitle(version.title());
		JFrameIni.loadJFrameIni(version,this);
		show();
		componentResized(null);
	}
	
	
	public void componentHidden(ComponentEvent e)
	{
	}


	public void componentMoved(ComponentEvent e)
	{
	}


	public void componentResized(ComponentEvent e)
	{
		number.setFont(new Font(font,Font.PLAIN,getHeight()));
		int height = getHeight();
		while (getGraphics().getFontMetrics(number.getFont()).stringWidth(number.getText()) > getWidth()-20)
		{
			height = (int)(0.75*(double)height);
			number.setFont(new Font(font,Font.PLAIN,height));
		}
	}


	public void componentShown(ComponentEvent e)
	{
	}
	

	public void paint(Graphics g)
	{
		super.paint(g);
		if (isDisabled)
		{
			for (int i = 0;i < getHeight()/2;i++)
				g.drawLine(0,i*2,(int)getWidth(),i*2);
		}
	}


	public void actionPerformed(ActionEvent e)
	{
		if (e.getActionCommand().equals("about"))
		{
			isDisabled = true;
			repaint();
			version.aboutBox(this);
			isDisabled = false;
			repaint();
		}
		else if (e.getActionCommand().equals("quit"))
			quit();
		else if (e.getActionCommand().equals("randomize"))
		{
			number.setText(""+random.nextInt(randomSpace));
			componentResized(null);
		}
	}


	public void changedUpdate(DocumentEvent e)
	{
		try
		{
			randomSpace = Integer.parseInt(maxFld.getText());
			if (randomSpace > 0)
				doBtn.setEnabled(true);
			else
				doBtn.setEnabled(false);
		}
		catch (NumberFormatException ex)
		{
			doBtn.setEnabled(false);
		}
 	}

 
 	public void insertUpdate(DocumentEvent e)
 	{
		changedUpdate(e);
 	}
 	
 	
 	public void removeUpdate(DocumentEvent e)
 	{
 		changedUpdate(e);
 	}

           
	public void quit()
	{
		JFrameIni.saveJFrameIni(version,this);
		Properties props = new Properties();
		try
		{
			props.load(new FileInputStream(version.productSimple()+".ini"));
		}
		catch (Exception e)
		{
		}
		props.setProperty("randomSpace",maxFld.getText());
		try
		{
			FileOutputStream fos = new FileOutputStream(version.productSimple()+".ini");
			props.store(fos,version.productSemi()+" ini file");
			fos.close();
		}
		catch (Exception e)
		{
			System.out.println("An error has occured while trying to save ini file.");
		}

		System.exit(0);
	}
	

	public static void main(String[] av)
	{
		new MrRandom();
	}
}