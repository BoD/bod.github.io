package com.c3dric.bod.time4;



/**
 * This class quits nicely time when the VM is exited.
 */
public class ShutdownHook extends Thread
{
	protected Time time;
	
	
	
	public ShutdownHook(Time t)
	{
		time = t;
	}
	
	
	/**
	 * This is what the shutdown hook does : it quits nicely.
	 */
	public void run()
	{
		time.quit();
	}
}
