package com.c3dric.bod.time4;

import java.io.*;
import java.util.*;


/**
 * This is a Person, used in the db.
 */
public class Person implements Comparable
{
	protected Vector nicks;
	protected Vector users; // primary key
	protected Vector ips; // 2 first bytes,primary key
	protected Vector emails; // null if unknown
	protected Vector homePages; // null if unknown
	protected Vector uins; // null if unknown
	protected String gender; // "female", "male", "unknown"
	protected Date birth; // null if unknown
	protected String lastNickUserHost; // nick!user@host, updated on lookup
	protected String lastWhoisMessage; // updated on lookup
	protected String lastQuitMessage; // updated on quit or part
	protected String lastPrivmsg; // updated on every privmsg
	protected Date firstSeen; // updated on privmsg and lookup
	protected Date lastSeen; // updated on privmsg and lookup
	protected String score; // for games like tagline
	protected String welcomeMessage; // displayed on join
	protected String message; // displayer on join if not allready read
	protected String messageFrom;
	protected Date messageDate;
	protected boolean messageNew; // true if there is an unread message, false otherwise
	protected boolean admin; // true if this person is an administrator
	protected String misc; // not used


	/**
	 * @return the users field.
	 */
	public Vector getUsers()
	{
		return users;
	}


	/**
	 * @return the ips field.
	 */
	public Vector getIps()
	{
		return ips;
	}

	
	/**
	 * and so on. . .
	 */
	public Vector getNicks()
	{
		return nicks;
	}

	
	public Date getLastSeen()
	{
		return lastSeen;
	}

	
	public String getGender()
	{
		return gender;
	}

	
	public String getLastQuitMessage()
	{
		return lastQuitMessage;
	}

	
	public String getLastPrivmsg()
	{
		return lastPrivmsg;
	}

	
	public Vector getEmails()
	{
		return emails;
	}

	
	public Vector getHomePages()
	{
		return homePages;
	}

	
	public Vector getUins()
	{
		return uins;
	}

	
	public String getScore()
	{
		return score;
	}

	
	public String getWelcomeMessage()
	{
		return welcomeMessage;
	}


	public String getMessage()
	{
		return message;
	}

	
	public String getMessageFrom()
	{
		return messageFrom;
	}

	
	public Date getMessageDate()
	{
		return messageDate;
	}

	
	public boolean isMessageNew()
	{
		return messageNew;
	}

	
	public boolean isAdmin()
	{
		return admin;
	}

	
	public void setLastSeen(Date d)
	{
		lastSeen = d;
	}
	

	public void setLastPrivmsg(String s)
	{
		lastPrivmsg = s;
	}

	
	public void setLastWhoisMessage(String s)
	{
		lastWhoisMessage = s;
	}

	
	public void setLastQuitMessage(String s)
	{
		lastQuitMessage = s;
	}

	
	public void setEmails(Vector v)
	{
		emails = v;
	}

	
	public void setHomePages(Vector v)
	{
		homePages = v;
	}

	
	public void setUins(Vector v)
	{
		uins = v;
	}

	
	public void setScore(String s)
	{
		score = s;
	}

		
	public void setLastNickUserHost(String s)
	{
		lastNickUserHost = s;
	}

	
	public void setWelcomeMessage(String s)
	{
		welcomeMessage = s;
	}


	public void setMessage(String s)
	{
		message = s;
	}

	
	public void setMessageFrom(String s)
	{
		messageFrom = s;
	}

	
	public void setMessageDate(Date d)
	{
		messageDate = d;
	}

	
	public void setMessageNew(boolean b)
	{
		messageNew = b;
	}

	
	/**
	 * Replaces bad characters by "_" in a file name.
	 *
	 * @param f the original file name.
	 * @return the well formed file name.
	 */
	protected static String correctFileName(String f)
	{
		String res = "";
		for (int i = 0;i < f.length();i++)
			if ((f.charAt(i) == '|') || (f.charAt(i) == '\\'))
				res += '_';
			else
				res += f.charAt(i);
		return res;
	}

	
	/**7
	 * Takes a vector of <CODE>String</CODE> and returns a comma separated string.
	 *
	 * @param v the vector to transform.
	 * @return the well formed <CODE>String</CODE>, or <CODE>""</CODE> if v was <CODE>null</CODE>.
	 */
	protected static String vectorToString(Vector v)
	{
		if (v == null)
			return "";
		Iterator i = v.iterator();
		String res = ""+v.elementAt(0);
		for (i.next();i.hasNext();)
			res += ","+i.next();
		return res;
	}


	/**
	 * Takes a comma separated <CODE>String</CODE> and returns a vector of strings.
	 *
	 * @param s the <CODE>String</CODE> to tr	ansform.
	 * @return the well formed <CODE>Vector</CODE>, or <CODE>null</CODE> if s was "" or <CODE>null</CODE>.
	 */
	public static Vector stringToVector(String s)
	{
		if (s == null || s.equals(""))
			return null;
		Vector res = new Vector();
		StringTokenizer st = new StringTokenizer(s,",");
		while (st.hasMoreTokens())
			res.add(st.nextToken());
		return res;
	}


	/**
	 * Dumps this <CODE>Person</CODE> into a file in the db directory.
	 */
	public synchronized void dump() throws IOException
	{
		File fileDump = new File("db/"+correctFileName(""+nicks.elementAt(0)+"__"+users.elementAt(0)+"__"+ips.elementAt(0)+".tpr"));
		fileDump.delete();
		FileOutputStream fos;
		fileDump.createNewFile();
		fos = new FileOutputStream(fileDump);
		toProps().store(fos,"Time 4 person file");
		fos.close();
	}
	
	
	/**
	 * Returns this <CODE>Person</CODE> as a <CODE>Properties</CODE>.
	 */
	public Properties toProps()
	{
		Properties props = new Properties();
		props.setProperty("nicks",vectorToString(nicks));
		props.setProperty("users",vectorToString(users));
		props.setProperty("ips",vectorToString(ips));
		props.setProperty("emails",vectorToString(emails));
		props.setProperty("homePages",vectorToString(homePages));
		props.setProperty("uins",vectorToString(uins));
		props.setProperty("gender",gender == null ? "unknown" : gender);
		props.setProperty("birth",birth == null ? "-1" : ""+birth.getTime()); // -1 if unknown
		props.setProperty("lastNickUserHost",lastNickUserHost == null ? "" : lastNickUserHost);
		props.setProperty("lastWhoisMessage",lastWhoisMessage == null ? "" : lastWhoisMessage);
		props.setProperty("lastQuitMessage",lastQuitMessage == null ? "" : lastQuitMessage);
		props.setProperty("lastPrivmsg",lastPrivmsg == null ? "" : lastPrivmsg);
		props.setProperty("firstSeen",""+firstSeen.getTime()); // can't be unknown
		props.setProperty("lastSeen",""+lastSeen.getTime()); // can't be unknown
		props.setProperty("welcomeMessage",welcomeMessage == null ? "" : welcomeMessage);
		props.setProperty("score",score == null ? "" : score);
		props.setProperty("message",message == null ? "" : message);
		props.setProperty("messageFrom",messageFrom == null ? "" : messageFrom);
		props.setProperty("messageDate",messageDate == null ? "-1" : ""+messageDate.getTime()); // -1 if unknown
		props.setProperty("messageNew",""+messageNew);
		props.setProperty("admin",""+admin);
		props.setProperty("misc",misc == null ? "" : misc);
		return props;
	}
	
	
	/**
	 * Makes a new <CODE>Person</CODE> from a <CODE>Properties</CODE> object.
	 *
	 * @param p a <CODE>Properties</CODE> object containing all the needed infos.
	 */
	public Person(Properties p)
	{
		nicks = stringToVector(p.getProperty("nicks"));
		users = stringToVector(p.getProperty("users"));
		ips = stringToVector(p.getProperty("ips"));
		emails = stringToVector(p.getProperty("emails"));
		homePages = stringToVector(p.getProperty("homePages"));
		uins = stringToVector(p.getProperty("uins"));
		gender = p.getProperty("gender");
		if (Long.parseLong(p.getProperty("birth")) == -1)
			birth = null;
		else
			birth = new Date(Long.parseLong(p.getProperty("birth")));
		lastNickUserHost = p.getProperty("lastNickUserHost");
		lastWhoisMessage = p.getProperty("lastWhoisMessage");
		lastQuitMessage = p.getProperty("lastQuitMessage");
		lastPrivmsg = p.getProperty("lastPrivmsg");
		firstSeen = new Date(Long.parseLong(p.getProperty("firstSeen")));
		lastSeen = new Date(Long.parseLong(p.getProperty("lastSeen")));
		welcomeMessage = p.getProperty("welcomeMessage");
		score = p.getProperty("score");
		message = p.getProperty("message");
		messageFrom = p.getProperty("messageFrom");
		if (p.getProperty("messageDate") == null || Long.parseLong(p.getProperty("messageDate")) == -1)
			messageDate = null;
		else
			messageDate = new Date(Long.parseLong(p.getProperty("messageDate")));
		if (p.getProperty("messageNew") != null && p.getProperty("messageNew").equalsIgnoreCase("true"))
			messageNew = true;
		else
			messageNew = false;
		if (p.getProperty("admin") != null && p.getProperty("admin").equalsIgnoreCase("true"))
			admin = true;
		else
			admin = false;
		misc = p.getProperty("misc");
	}
	
	
	/**
	 * Makes a new <CODE>Person</CODE> from its nick, user, host, ip.
	 *
	 * @param nick the nick of the person to construct.
	 * @param user the user of the person to construct.
	 * @param host the host of the person to construct.
	 * @param ip the ip of the person to construct.
	 */
	public Person(String nick,String user,String host,String ip)
	{
		nicks = stringToVector(nick);
		users = stringToVector(user);
		lastNickUserHost = nick+"!"+user+"@"+host;
		ips = stringToVector(ip);
		gender = "unknown";
		firstSeen = new Date();
		lastSeen = new Date();
		score = "0";
	}
	
	
	public int compareTo(Object o)
	{
		return lastSeen.compareTo(((Person)o).getLastSeen());
	}
}