import com.c3dric.bod.time4.*;


/**
 * This is the tagline module.
 */
public class ModTagline extends AbstractMod
{
	protected String tagLine = null;
	protected int tentatives = 0;
	
		
	/**
	 * Gives a tagline.
	 */
	protected void tagline(String chan,String n,String r,String[] s,String[] t)
	{
		if (tagLine == null)
			tagLine = Utils.randomList(props.getProperty("tagLines"));
		time.timeSay(chan,n,"� "+Utils.s(tagLine,"�")[1]+" �");
	}
	
	
	/**
	 * Tests upon "approximative" matching.
	 *
	 * @param real the valid answer.
	 * @param player the answer you want to test.
	 * @result <CODE>true</CODE> if <CODE>player</CODE> is approximatively equal to <CODE>real</CODE>, <CODE>false</CODE> else.
	 */
	protected static boolean isValidAnswer(String real,String player)
	{
		boolean res = true;
		real = real.toLowerCase();
		player = player.toLowerCase();
		for (int i = 0;i < player.length();i++)
			if (Character.isLetterOrDigit(player.charAt(i)))
				res = res && (real.indexOf(player.charAt(i)) != -1);
		res = res && (player.length() >= real.length()/2) && (player.length() <= real.length()+5);
		return res;
	}
	
	
	/**
	 * Accepts a response for tagline.
	 */
	protected void reponse(String chan,String n,String r,String[] s,String[] t)
	{
		if (tagLine == null)
			time.timeSay(chan,n,"Heu tu dois d'abord faire !time tagline");
		else
		if (s.length < 2)
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseReponse"))));
		else
		if (isValidAnswer(Utils.s(tagLine,"�")[0],t[1]))
		{
			String res = Utils.randomList("Youhou ! Gagn�#Bravoooooo c'est bien �a !#Felicitations :) t'as trouv� !#waa le kissman ! C'est bien �a !")+"  "+Utils.s(tagLine,"�")[0];
			tagLine = null;
			tentatives = 0;
			try
			{
				Person p = time.getChannelList().getChannel(chan).getUser(n).getPerson();
				p.setScore(""+(Integer.parseInt(p.getScore())+1));
				p.dump();
				res += ". Ton score est maintenant de "+p.getScore()+".";
				time.timeSay(chan,n,res);
			}
			catch (Throwable x)
			{
				res += ". (D� � un bug, je n'ai pas r�ussi � changer ton score... Pas de chance...)";
				time.timeSay(chan,n,res);
			}
		}
		else
		{
			time.timeSay(chan,n,"nop ...");
			tentatives++;
			if (tentatives == 13)
			{
				time.timeSay(chan,n,"Bon comme je vois que vous avez un peu de mal, je vous donne la r�ponse : c'�tait \""+Utils.s(tagLine,"�")[0]+"\". Al lala.");
				tagLine = null;
				tentatives = 0;
			}
		}
	}

	
	public boolean accept(String chan,String n,String r,String[] s,String[] t) throws ModException
	{
		if (s.length == 0)
			return false;
		else
		if (s[0].equalsIgnoreCase("tagline"))
		{
			tagline(chan,n,r,s,t);
			return true;
		}
		else
		if (s[0].equalsIgnoreCase("reponse") || s[0].equalsIgnoreCase("rep") || s[0].equalsIgnoreCase("r�ponse") || s[0].equalsIgnoreCase("response"))
		{
			reponse(chan,n,r,s,t);
			return true;
		}
		else
			return false;
	}
}