package com.c3dric.bod.time4;


/**
 * General exception used when an error occurs in a module.
 */
public class ModException extends Exception
{
	public ModException(String s)
	{
		super(s);
	}
}