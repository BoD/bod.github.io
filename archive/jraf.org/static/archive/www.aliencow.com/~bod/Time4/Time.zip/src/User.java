package com.c3dric.bod.time4;


/**
 * A channel is made of users. Each <CODE>User</CODE> should contain a <CODE>Person</CODE> as soon as possible e.g after a whois response.
 * Every user should contain a Person, but 2 users can share the same Person.
 */
public class User
{
	protected String name;
	protected boolean op;
	protected boolean voice;
	protected Person person;


	
	public void setName(String name)
	{
		this.name = name;
	}	


	public String getName()
	{
		return name;
	}

	
	public void setOp(boolean op)
	{
		this.op = op;
	}	


	public void setVoice(boolean voice)
	{
		this.voice = voice;
	}	


	public void setPerson(Person person)
	{
		this.person = person;
	}	


	public Person getPerson()
	{
		return person;
	}	

	
	public User(String name,boolean op,boolean voice)
	{
		this.name = name;
		this.op = op;
		this.voice = voice;	
	}
	
	
	/**
	 * Returns <CODE>true</CODE> if u has the same name as this user, <CODE>false</CODE> otherwise.
	 *
	 * @param u the user you want to compare.
	 * @return <CODE>true</CODE> if u has the same name as this user, <CODE>false</CODE> otherwise.
	 */
	public boolean equals(Object o)
	{
		return ((User)o).getName().equalsIgnoreCase(name);
	}
}