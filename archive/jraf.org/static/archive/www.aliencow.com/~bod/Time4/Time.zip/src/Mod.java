package com.c3dric.bod.time4;


/**
 * A time module. Every module must implement this interface
 */
public interface Mod
{
	/**
	 * This is fired when loading this module.
	 */
	public void init(Time time) throws ModException;
	
	
	/**
	 * Executes the associated action and returns <CODE>true</CODE> if this module should handle this event, returns <CODE>false</CODE> otherwise.
	 *
	 * @return <CODE>true</CODE> if this module handles this event, <CODE>false</CODE> otherwise.
	 */
	public boolean accept(String chan,String n,String r,String[] s,String[] t) throws ModException;
}