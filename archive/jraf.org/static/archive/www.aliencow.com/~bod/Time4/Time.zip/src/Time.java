package com.c3dric.bod.time4;

import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;

import com.c3dric.bod.util.*;


/**
 * The main class : it connects, logins, and do its job.
 */
public class Time
{
	/**
	 * The <CODE>Socket</CODE>, connected with the irc server.
	 */
	protected Socket socket;

	/**
	 * Irc out stream.
	 */
	protected PrintWriter ircOut;

	/**
	 * Irc in stream.
	 */
	protected BufferedReader ircIn;

	/**
	 * Irc out stream while in debug mode.
	 */
	protected PrintWriter debugOut;

	/**
	 * Irc in stream while in debug mode.
	 */
	protected BufferedReader debugIn;

	/**
	 * Debug mode is meant to run Time offline.
	 */
	protected boolean debugMode;

	/**
	 * No console mode means text-based (no swing ui).
	 */
	protected boolean noConsoleMode;

	/**
	 * Current channel list.
	 */
	protected ChannelList channelList;

	/**
	 * Current nick.
	 */
	protected String nick;

	/**
	 * Properties found in <CODE>time.ini</CODE> and used (at least) in the connect and login processes.
	 */
	protected String loginNick,alternateNick,user,channels,callName,server,port,currentVersionURL,downloadCurrentVersionURL,hoster,httpServerPort;

	/**
	 * A displayer.
	 */
	protected Display display;

	/**
	 * The database associated to this Time.
	 */
	protected Db db;

	/**
	 * The modules.
	 */
	protected Mod[] mods;

	/**
	 * Info version.
	 */
	protected Version version;

	/**
	 * Connection date.
	 */
	protected Date connectionDate;

	/**
	 * True when exiting
	 */
	protected boolean isQuitting;



	public String getCurrentNick()
	{
		return nick;
	}


	public String getCallName()
	{
		return callName;
	}


	public String getHoster()
	{
		return hoster;
	}


	public Version getVersion()
	{
		return version;
	}


	public ChannelList getChannelList()
	{
		return channelList;
	}


	public Db getDb()
	{
		return db;
	}


	public Display getDisplay()
	{
		return display;
	}


	public Date getConnectionDate()
	{
		return connectionDate;
	}


	public boolean isDebugMode()
	{
		return debugMode;
	}


	public int getHttpServerPort()
	{
		return Integer.parseInt(httpServerPort);
	}


	/**
	 * Sends a line thru irc out stream.
	 *
	 * @param s The line to send.
	 */
	public void send(String s)
	{
		/*if (!debugMode)
			display.logMessage("send : "+s);
		else*/
			display.message("send : "+s);
		if (!debugMode)
			ircOut.println(s);
	}


	/**
	 * Receives the next line from irc in stream.
	 *
	 * @return The next line from irc in stream.
	 */
	protected String receive()
	{
		String res = "";
		try
		{
			if (debugMode)
				res = debugIn.readLine();
			else
				res = ircIn.readLine();
			if (res == null)
				display.message("disconnected");
			else
			//	if (debugMode)
					display.message("receive : "+res);
			/*	else
					display.logMessage("receive : "+res);*/
		}
		catch (IOException e)
		{
			display.warning("problem with socket while receiving from irc in stream (probably disconnected)",e);
			return null;
		}
		return res;
	}


	/**
	 * When in debug mode, simulate server output.
	 *
	 * @param s The line to simulate.
	 */
	public void simulateServerData(String s)
	{
		display.message("simulate: \""+s+"\"");
		debugOut.println(s);
	}


	/**
	 * Connects to the server.
	 *
	 * @return <CODE>true</CODE> if no problemo, <CODE>false</CODE> otherwise.
	 */
	protected boolean connect()
	{
		String serv = Utils.randomList(server,",");
		display.message("connecting to server "+serv+":"+port+"..");
		try
		{
			socket = new Socket(serv,Integer.parseInt(port));
			display.message("connected to server "+serv+":"+port);
			ircIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			ircOut = new PrintWriter(socket.getOutputStream(),true);
			return true;
		}
		catch (Exception e)
		{
			display.warning("could not connect to server "+serv+":"+port,e);
			return false;
		}
	}


	/**
	 * Logins the server and joins the channels. This method tries to find a nick that is accepted.
	 *
	 * @return <CODE>true</CODE> if no problemo, <CODE>false</CODE> otherwise.
	 */
	protected boolean login()
	{
		display.message("registering as "+loginNick+"!"+user);
		send("USER "+user+" time time :"+version.productFull());
		send("NICK "+(nick = loginNick));
		String r = receive();
		if (r == null)
			return false;
		String[] s = Utils.s(r);
		while (s[0].equals("NOTICE"))
		{
			r = receive();
			if (r == null)
				return false;
			s = Utils.s(r);
		}
		if (!s[0].equals("PING")) // wrong nick (probably 433)
		{
			display.message("nick "+nick+" was not accepted");
			send("NICK "+(nick = alternateNick));
			display.message("trying "+nick);
			r = receive();
			if (r == null)
				return false;
			s = Utils.s(r);
			while (!s[0].equals("PING"))
			{
				if (!s[0].equals("NOTICE")) // ignoring NOTICE AUTH in the login process of some servers (should be 'if nick rejected' instead of 'if not nick accepted (ping)')
				{
					display.message("nick "+nick+" was not accepted");
					if (loginNick.length() > 7)
						send("NICK "+(nick = loginNick.substring(0,7)+(new Double(Math.random()*100)).intValue()));
					else
						send("NICK "+(nick = loginNick+(new Double(Math.random()*100)).intValue()));
					display.message("trying "+nick);
				}
				r = receive();
				if (r == null)
					return false;
				s = Utils.s(r);
			}
			send("PONG "+s[1]);
		}
		else
			send("PONG "+s[1]);
		display.message("registered as "+nick+"!"+user);
		display.message("joining channel(s) "+channels);
		send("JOIN "+channels);
		r = receive();
		if (r == null)
			return false;
		s = Utils.s(r);
		while (!s[1].equals("JOIN")) // motd and other stuffs
		{
			r = receive();
			if (r == null)
				return false;
			s = Utils.s(r);
		}
		send("TOPIC "+channels);
		send("PRIVMSG "+channels+" :"+version.productFull()+" - Build "+version.build()+" - "+System.getProperty("java.vm.vendor")+" "+System.getProperty("java.vm.name")+" "+System.getProperty("java.vm.version")+" - Hosted by "+hoster+".");
		if (connectionDate == null)
			connectionDate = new Date();
		return true;
	}


	/**
	 * Logouts the server and quits.
	 *
	 * param s The quit message.
	 */
	public void quit(String s)
	{
		display.message("exiting Time..");
		isQuitting = true;
		try
		{
			if (!debugMode)
				send("QUIT :"+s);
			display.message("dumping db..");
			try
			{
				db.dump();
			}
			catch (IOException e)
			{
				display.fatal("problem while dumping db, DB NOT UPDATED",e);
			}
			display.message("bd dumped");
			display.message("bye");
		}
		finally
		{
			if (noConsoleMode)
				Runtime.getRuntime().halt(0);
			else
				System.exit(0);	
		}
	}


	/**
	 * Logouts the server and quits.
	 */
	public void quit()
	{
		quit(version.productFull());
	}
	
	
	/**
	 * Standard method for saying something to somebody on some channel.
	 *
	 * @param chan The dest channel.
	 * @param n The nick to speak to.
	 * @param s The <CODE>String</CODE> to say.
	 */
	public void timeSay(String chan,String n,String s)
	{
		send("PRIVMSG "+chan+" :"+Irc.ircK+"2"+Irc.ircB+Irc.ircU+n+Irc.ircU+Irc.ircB+Irc.ircK+" : "+s);
	}


	/**
	 * Fired when the first word of a <CODE>PRIVMSG</CODE>is a <CODE>!</CODE> followed by current nick or call name.
	 * The behavior is to look in the mod table for a command matching the first word. If no matching command is found
	 * the <CODE>ModTime.timeOracle</CODE> event is fired.
	 *
	 * @param r The line received from the server.
	 * @param s A tokenization of r.
	 * @param t Another tokenization of r (see <CODE>Utils.t(String)</CODE>).
	 */
	void eventTime(String r,String[] s,String[] t)
	{
		String chan = s[2];
		String n = Utils.s(s[0],":!@")[0];
		String[] s2 = new String[s.length-4];
		for (int i = 0;i < s.length-4;i++)
			s2[i] = s[i+4];
		String[] t2 = new String[t.length-4];
		for (int i = 0;i < t.length-4;i++)
			t2[i] = t[i+4];
		for (int i = 0;i < mods.length;i++)
			try
			{
				if (mods[i].accept(chan,n,r,s2,t2))
					return;
			}
			catch (ModException e)
			{
				display.warning("problem while invoking module "+mods[i],e);
			}
	}


	/**
	 * Fired when a <CODE>PRIVMSG</CODE> is received. Updates the db and if the first word is a <CODE>!</CODE> followed by current nick or call name,
	 * <CODE>eventTime</CODE> is fired.
	 * Also pings back if necessary.
	 *
	 * @param r The line received from the server.
	 * @param s A tokenization of r.
	 * @param t Another tokenization of r (see <CODE>Utils.t(String)</CODE>).
	 */
	void eventPrivmsg(String r,String[] s,String[] t)
	{
		//ex :jimpqfly!jimpqfly@ppp-175-118.velizy.club-internet.fr PRIVMSG #nous :Yo salut ca va ?
		//ex :Nucleus!Nucleus@ppp-243-80.velizy.club-internet.fr PRIVMSG #nous :PING 404284

		String channel = s[2];
		String[] nickUserHost = Utils.s(s[0],":!@");
		String nix = nickUserHost[0];
		if (!channel.startsWith("#")) // ignores privates (except for ctcp ping)
		{
			if (s.length > 3 && s[3].equalsIgnoreCase(":"+Irc.ircC+"PING")) // pings back
				send("NOTICE "+nix+" "+t[3]);
			return;
		}
		String user = nickUserHost[1];
		if (user.startsWith("~"))
			user = user.substring(1); // removes '~'
		String host = nickUserHost[2];
		String said = t[3].substring(1); // removes ':'

		Channel chan = channelList.getChannel(channel);
		if (!debugMode && chan != null) // if null, just ignore and wait for 353 (RPL_NAMREPLY)
		{
			User uzr = chan.getUser(nix);
			Person person = uzr.getPerson();
			if (person == null) // there is no Person associated to this user, so we put one in
			{
				try
				{
					byte[] ip = InetAddress.getByName(host).getAddress();
					person = db.getPerson(user,ip);
					if (person == null) // no matching found in db
						try
						{
							person = new Person(nix,user,host,""+Utils.unsignByte(ip[0])+"."+Utils.unsignByte(ip[1]));
							db.addPerson(person);
						}
						catch (IOException e)
						{
							display.warning("could not physically add an entry in the database",e);
						}
				}
				catch (UnknownHostException e)
				{
					display.warning("could not resolve host for "+nick+"!"+user+"@"+host,e);
				}
				uzr.setPerson(person);
			}
			if (person != null) // updating datas for db. May be null because of an IOException or an UnknownHostException.
			{
				person.setLastSeen(new Date());
				person.setLastPrivmsg(said);
			}
		}
		if (s.length > 3 && (s[3].equalsIgnoreCase(":!"+callName) || s[3].equalsIgnoreCase(":!"+nick))) // eventTime
			eventTime(r,s,t);
		else
		if (s.length > 3 && s[3].equalsIgnoreCase(":"+Irc.ircC+"PING")) // pings back
			send("NOTICE "+nix+" "+t[3]);
	}


	/**
	 * Fired when a 311 (<CODE>RPL_WHOISUSER</CODE>) is received. The behavior is to update the db.
	 *
	 * @param s A tokenization of the line received from the server.
	 * @param t Another tokenization of received line (see <CODE>Utils.t(String)</CODE>).
	 */
	void event311(String[] s,String[] t) // RPL_WHOISUSER
	{
		//ex :NewYork.NY.US.Undernet.Org 311 time4BETA jimpqfly ~jimpqfly ppp-175-118.velizy.club-internet.fr * :www.multimania.com/jimpqfly

		String nix = s[3];
		String user = s[4];
		String host = s[5];
		String message = t[7];
		if (user.startsWith("~"))
			user = user.substring(1); // removes '~'
		message = message.substring(1); // removes ':'

		User uzr = channelList.getUser(nix);
		if (uzr != null) // if null, just ignore and wait for 353 (RPL_NAMREPLY) (should never happen).
		{
			Person person = uzr.getPerson();
			if (person == null) // there is no Person associated to this user, so we put one in. There could allready be a person if the user privmsged before the 311 was received.
			{
				try
				{
					byte[] ip = InetAddress.getByName(host).getAddress();
					person = db.getPerson(user,ip);
					if (person == null) // no matching found in db
						try
						{
							person = new Person(nix,user,host,""+Utils.unsignByte(ip[0])+"."+Utils.unsignByte(ip[1]));
							db.addPerson(person);
						}
						catch (IOException e)
						{
							display.warning("could not physically add an entry in the database",e);
						}
				}
				catch (UnknownHostException e)
				{
					display.warning("could not resolve host for "+nick+"!"+user+"@"+host,e);
				}
				uzr.setPerson(person);
			}
			if (person != null) // updating datas for db. May be null because of an IOException or an UnknownHostException.
			{
				person.setLastSeen(new Date());
				if (!person.getNicks().contains(nix))
					person.getNicks().add(nix);
				person.setLastWhoisMessage(message);
				person.setLastNickUserHost(nix+"!"+user+"@"+host);
			}
		}
	}


	/**
	 * Fired when a 353 (<CODE>RPL_NAMREPLY</CODE>) is received. The behavior is to update the channel list and
	 * the user list and to whois each user.
	 *
	 * @param s A tokenization of the line received from the server.
	 * @param t Another tokenization of received line (see <CODE>Utils.t(String)</CODE>).
	 */
	void event353(String[] s,String[] t) // RPL_NAMREPLY
	{
		//ex :NewYork.NY.US.Undernet.Org 353 time4BETA = #!time4BETA :@time4BETA
		//ex :NewYork.NY.US.Undernet.Org 353 time4BETA * #nous :time4BETA BoD @W

		String channel = s[4];
		channelList.addChannel(channel);
		if (s.length > 5)
		{
			String[] users = Utils.s(t[5].substring(1)); // removes ':'
			for (int i = 0;i < users.length;i++)
				if (users[i].charAt(0) == '@')
					channelList.getChannel(channel).addUser(users[i].substring(1),true,false);
				else
					if (users[i].charAt(0) == '+')
						channelList.getChannel(channel).addUser(users[i].substring(1),false,true);
					else
						channelList.getChannel(channel).addUser(users[i],false,false);
		}
		Vector users = channelList.getChannel(channel).getUsers();
		for (Iterator j = users.iterator();j.hasNext();) // whois
		{
			User u = (User)j.next();
			if (!u.getName().equalsIgnoreCase(nick) && !u.getName().equalsIgnoreCase("w") && !u.getName().equalsIgnoreCase("x"))
				send("WHOIS "+u.getName());
		}
	}


	/**
	 * Fired when a 331 (<CODE>RPL_NOTOPIC</CODE>) is received. The behavior is to update the channel topic using the <CODE>ModTime.timeTopic()</CODE> method.
	 *
	 * @param s A tokenization of the line received from the server.
	 * @param t Another tokenization of received line (see <CODE>Utils.t(String)</CODE>).
	 */
	void event331(String[] s,String[] t) // RPL_NOTOPIC
	{
		//ex :Amsterdam.NL.Eu.UnderNet.org 331 time4BETA #time4 :No topic is set.

		String[] st = {"topic"};
		try
		{
			mods[mods.length-1].accept(s[3],"","topic",st,st);
		}
		catch (ModException e)
		{
			display.warning("problem while invoking module ModTime for event331 (RPL_NOTOPIC)",e);
		}
	}


	/**
	 * Fired when a user quits irc. The behavior is to update the user lists and to save the user in the db (physically).
	 *
	 * @param s A tokenization of the line received from the server.
	 * @param t Another tokenization of received line (see <CODE>Utils.t(String)</CODE>).
	 */
	void eventQuit(String[] s,String[] t)
	{
		//ex :DRiXe!drixe@ppp-175-202.velizy.club-internet.fr QUIT :Read error to DRiXe[ppp-175-202.velizy.club-internet.fr]: EOF from client

		String nix = Utils.s(s[0],":!@")[0];
		String message = t[2].substring(1); // removes ':'

		User uzr = channelList.getUser(nix);
		if (uzr != null) // if null, just ignore and wait for 353 (RPL_NAMREPLY) (should never happen).
		{
			Person person = uzr.getPerson();
			if (person != null) // if no person associated, ignore the event (wait for whois or privmsg).
			{
				person.setLastSeen(new Date());
				person.setLastQuitMessage(message);
				try
				{
					person.dump();
				}
				catch (IOException e)
				{
					display.warning("problem while updating database for "+(s[0].substring(1)),e);
				}
			}
			channelList.removeUser(nix);
		}
	}


	/**
	 * Fired when a user parts a channel. The behavior is to update the user lists and to save the user in the db (physically).
	 *
	 * @param s A tokenization of the line received from the server.
	 * @param t Another tokenization of received line (see <CODE>Utils.t(String)</CODE>).
	 */
	void eventPart(String[] s,String[] t)
	{
		//ex :BoD!bod@ppp-106-182.villette.club-internet.fr PART #!time4BETA

		String nix = Utils.s(s[0],":!")[0];
		String chan = s[2];
		Channel chanz = channelList.getChannel(chan);
		if (chanz != null) // if null, just ignore and wait for 353 (RPL_NAMREPLY) (should never happen).
		{
			User uzr = chanz.getUser(nix);
			Person person = uzr.getPerson();
			if (person != null) // if no person associated, ignore the event (wait for whois or privmsg).
			{
				person.setLastSeen(new Date());
				try
				{
					person.dump();
				}
				catch (IOException e)
				{
					display.warning("problem while updating database for "+(s[0].substring(1)),e);
				}
			}
			channelList.getChannel(chan).removeUser(nix);
		}
	}


	/**
	 * Fired when a user is kicked from a channel. The behavior is to update the user lists and to save the user in the db (physically).
	 *
	 * @param s A tokenization of the line received from the server.
	 * @param t Another tokenization of received line (see <CODE>Utils.t(String)</CODE>).
	 */
	void eventKick(String[] s,String[] t)
	{
		//ex :jimpqfly!~jimpqfly@ACAE3302.ipt.aol.com KICK #nous BoD :Kicked by The Maaaaaaaster :).

		String nix = s[3];
		String message = t[4].substring(1); // removes ':'

		User uzr = channelList.getUser(nix);
		if (uzr != null) // if null, just ignore and wait for 353 (RPL_NAMREPLY) (should never happen).
		{
			Person person = uzr.getPerson();
			if (person != null) // if no person associated, ignore the event (wait for whois or privmsg).
			{
				person.setLastSeen(new Date());
				person.setLastQuitMessage(message); // sets the kick message as the quit message (well why not...)
				try
				{
					person.dump();
				}
				catch (IOException e)
				{
					display.warning("problem while updating database for "+(s[0].substring(1)),e);
				}
			}
			channelList.removeUser(nix);
		}
	}


	/**
	 * Fired when a user joins a channel. The behavior is to add the user in the channel user list, and to update infos.
	 *
	 * @param s A tokenization of the line received from the server.
	 * @param t Another tokenization of received line (see <CODE>Utils.t(String)</CODE>).
	 */
	void eventJoin(String[] s,String[] t)
	{
		//ex :BoD!bod@ppp-106-182.villette.club-internet.fr JOIN :#!time4BETA

		String channel = s[2].substring(1); // removes ':'
		String[] nickUserHost = Utils.s(s[0],":!@");
		String nix = nickUserHost[0];
		String user = nickUserHost[1];
		if (user.startsWith("~"))
			user = user.substring(1); // removes '~'
		String host = nickUserHost[2];

		if (!nix.equalsIgnoreCase(nick) && !nix.equalsIgnoreCase("w") && !nix.equalsIgnoreCase("x"))
		{
			Person person = null;
			channelList.getChannel(channel).addUser(nix,false,false);
			User uzr = channelList.getChannel(channel).getUser(nix);
			try
			{
				byte[] ip = InetAddress.getByName(host).getAddress();
				person = db.getPerson(user,ip);
				if (person == null) // no matching found in db
					try
					{
						person = new Person(nix,user,host,""+Utils.unsignByte(ip[0])+"."+Utils.unsignByte(ip[1]));
						db.addPerson(person);
					}
					catch (IOException e)
					{
						display.warning("could not physically add an entry in the database",e);
					}
				else
				{
					if (new Date().getTime()-person.getLastSeen().getTime() < 4*60*60*1000) // says "re" if last seen is < 4 hours
						timeSay(channel,nix,"re !");
					else // if a welcome message is set, say it
						if (person.getWelcomeMessage() != null && !person.getWelcomeMessage().equals(""))
							timeSay(channel,nix,Utils.randomList(person.getWelcomeMessage(),"$"));
					if (person.isMessageNew())
						timeSay(channel,nix,"Tu as un message de la part de "+person.getMessageFrom()+". Fais !time message pour le lire.");
					send("PRIVMSG "+channel+" :"+Irc.ircC+"SOUND "+person.getNicks().elementAt(0)+".wav"+Irc.ircC); // plays <nick>.wav on the channel
				}
			}
			catch (UnknownHostException e)
			{
				display.warning("could not resolve host for "+nix+"!"+user+"@"+host,e);
			}
			uzr.setPerson(person);
			if (person != null) // updating datas for db. May be null because of an IOException or an UnknownHostException.
			{
				person.setLastSeen(new Date());
				if (!person.getNicks().contains(nix))
					person.getNicks().add(nix);
				person.setLastNickUserHost(nix+"!"+user+"@"+host);
			}

			send("WHOIS "+nix); // perform lookup (whois)
		}
	}


	/**
	 * Fired when a user change nicks. The behavior is to update infos.
	 *
	 * @param s A tokenization of the line received from the server.
	 * @param t Another tokenization of received line (see <CODE>Utils.t(String)</CODE>).
	 */
	void eventNick(String[] s,String[] t)
	{
		//ex :BoD!bod@ppp-107-61.villette.club-internet.fr NICK :BoD_test
		//ex :BoD_test!bod@ppp-107-61.villette.club-internet.fr NICK :BoD

		String nix = Utils.s(s[0],":!")[0];
		String newNick = t[2].substring(1); // removes ':'

		User uzr = channelList.getUser(nix);
		if (uzr != null) // if null, just ignore and wait for 353 (RPL_NAMREPLY)
		{
			Person person = uzr.getPerson();
			if (person != null) // if there is no Person associated to this user, just wait for a privmsg or a 311.
				person.setLastSeen(new Date());
			uzr.setName(newNick);
		}
	}


	/**
	 * Main loop, reads next line from sever and distributes to the right method.
	 */
	void mainLoop()
	{
		String[] s,t;
		String r;

		while(true)
		{
			r = receive();
			while (r == null && !isQuitting)
			{
				for (int w = 4;!(connect() && login());w++)
				{
					display.message("trying to reconnect..");
					try
					{
						display.message("waiting "+w+" seconds before reconnecting..");
						Thread.currentThread().sleep(1000*w); // wait w seconds before trying to reconnect.
					}
					catch (InterruptedException e)
					{
					}
				}
				r = receive();
			}
			s = Utils.s(r);
			t = Utils.t(r);
			if (s[0].equalsIgnoreCase("PING"))
				send("PONG "+s[1]);
			else
			if (s[1].equalsIgnoreCase("PRIVMSG"))
				eventPrivmsg(r,s,t);
			else
			if (s[1].equalsIgnoreCase("311")) // RPL_WHOISUSER
				event311(s,t);
			else
			if (s[1].equalsIgnoreCase("353")) // RPL_NAMREPLY
				event353(s,t);
			else
			if (s[1].equalsIgnoreCase("331")) // RPL_NOTOPIC
				event331(s,t);
			else
			if (s[1].equalsIgnoreCase("QUIT"))
				eventQuit(s,t);
			else
			if (s[1].equalsIgnoreCase("PART"))
				eventPart(s,t);
			else
			if (s[1].equalsIgnoreCase("JOIN"))
				eventJoin(s,t);
			else
			if (s[1].equalsIgnoreCase("NICK"))
				eventNick(s,t);
			else
			if (s[1].equalsIgnoreCase("KICK"))
				eventKick(s,t);
		}
	}


	/**
	 * Loads <CODE>Time.ini</CODE> file and initialize Version (info version).
	 */
	protected void init()
	{
		try
		{
			Properties p = new Properties();
			p.load(new FileInputStream("time.ini"));
			if ((loginNick = p.getProperty("nick")) == null)
				loginNick = "time";
			if ((alternateNick = p.getProperty("alternateNick")) == null)
				alternateNick = "time[bot]";
			if ((user = p.getProperty("user")) == null)
				user = "time";
			if ((channels = p.getProperty("channels")) == null)
				channels = "#Time4";
			if ((callName = p.getProperty("callName")) == null)
				callName = "time";
			if ((server = p.getProperty("server")) == null)
				display.fatal("property \"server\" missing in file Time.ini");
			if ((port = p.getProperty("port")) == null)
				port = "6667";
			if ((currentVersionURL = p.getProperty("currentVersionURL")) == null)
				currentVersionURL = "http://bod.c3dric.com/Time4/Time.currentVersion.txt";
			if ((downloadCurrentVersionURL = p.getProperty("downloadCurrentVersionURL")) == null)
				currentVersionURL = "http://bod.c3dric.com/Time4/Time.zip";
			if ((hoster = p.getProperty("host")) == null)
				hoster = "(unknown)";
			if ((httpServerPort = p.getProperty("httpServerPort")) == null)
				hoster = "8889";
		}
		catch (Exception e)
		{
			display.fatal("could not load time.ini file",e);
		}
		 /*
		version = new Version("BoD","BoD inc.","Time",new int[] {1997,1998,1999,2000},4,0,470,true,"","time@BoDZone.com","http://time.BoDZone.com","BoD","Kawa 3.51a",null,false);
		try
		{
			version.dump();
		}
		catch (Exception e)
		{
			display.debug(e.toString());
		}
		 */
		try
		{
			version = new Version();
		}
		catch (Exception e)
		{
		}

	}


	/**
	 * Load modules into the mod table, and initializes them.
	 */
	protected void initModules()
	{
		String[] modList;
		display.message("loading and initializing modules..");
		try
		{
			modList = new File("mod").list();
			mods = new Mod[modList.length];

			int j = 0;
			for (int i = 0; i < modList.length;i++)
				if (!modList[i].equalsIgnoreCase("ModTime"))
				{
					display.message(modList[i]);
					mods[j] = (Mod)Class.forName(modList[i]).newInstance();
					mods[j].init(this);
					j++;
				}
			display.message("ModTime"); // last index of the mod table is always ModTime which is the default module (needed for default event)
			mods[j] = (Mod)Class.forName("ModTime").newInstance();
			mods[j].init(this);
			display.message("modules loaded and initialized");
		}
		catch (Exception e)
		{
			display.fatal("problem while loading modules",e);
		}
	}


	/**
	 * The constructor.
	 */
	public Time(String[] s)
	{
		if (Utils.arrayContains(s,"-noConsole") || Utils.arrayContains(s,"-noconsole"))
		{
			noConsoleMode = true;
			display = new Display(this,true);
		}
		else
		{
			noConsoleMode = false;
			display = new Display(this,false);
		}
		init();
		debugMode = Utils.arrayContains(s,"-debug");
		display.message("\""+version.about()+"\"");
		display.message("JVM "+System.getProperty("java.vm.vendor")+" "+System.getProperty("java.vm.name")+" "+System.getProperty("java.vm.version"));
		display.message("");
		display.message("checking current version..");
		try
		{
			String cv;
			long cb;
			if (debugMode)
			{
				cv = version.getCurrentVersion("file:Time.currentVersion.txt");
				cb = version.getCurrentBuild("file:Time.currentVersion.txt");
			}
			else
			{
				cv = version.getCurrentVersion(currentVersionURL);
				cb = version.getCurrentBuild(currentVersionURL);
			}
			if (cv.equals(version.version()))
				display.message("this version is the current version");
			else
			{
				display.message("this version is not the current version ! Current version is v"+cv);
				if (version.build().getTime() > cb)
					display.message("skipping download of the current version since this version is earlier");
				else
				{
					display.message("please wait while downloading and installing version v"+cv+". You'll have to restart Time after that operation");
					display.message("downloading and installing current version..");
					try
					{
						version.downloadCurrentVersion(downloadCurrentVersionURL);
						display.message("new version downloaded succesfully. Please restart Time now");
						display.fatal("system halted (this is not an error, you just have to restart Time)");
					}
					catch (Exception f)
					{
						display.fatal("problem while downloading current version. You'll certainly have to reinstall Time, sorry for the inconveniance !",f);
					}
				}
			}
		}
		catch (Exception e)
		{
			display.warning("could not check current version",e);
		}

		if (debugMode)
			display.message("running in debug mode");


		display.message("loading db..");
		try
		{
			db = new Db();
		}
		catch (Exception e)
		{
			display.fatal("could not load db",e);
		}
		display.message("db loaded");

		if (noConsoleMode)
		{
			display.message("adding shutdown hook..");
			Runtime.getRuntime().addShutdownHook(new ShutdownHook(this));
			display.message("shutdown hook added");
		}
		
		channelList = new ChannelList();

		initModules();

		display.message("running http server on port "+httpServerPort+"..");
		new HttpServer(this).start();

		if (debugMode)
		{
			nick = callName;
			channelList.addChannel("#nous");
			try
			{
				PipedOutputStream dOS = new PipedOutputStream();
				debugOut = new PrintWriter(dOS,true);
				debugIn = new BufferedReader(new InputStreamReader(new PipedInputStream(dOS)));
			}
			catch (IOException e)
			{
				display.fatal("io problem while initializing piped streams for debug mode",e);
			}
		}
		else
			for (int w = 4;!(connect() && login());w++)
			{
				display.message("trying to reconnect..");
				try
				{
					display.message("waiting "+w+" seconds before reconnecting..");
					Thread.currentThread().sleep(1000*w); // wait w seconds before trying to reconnect.
				}
				catch (InterruptedException e)
				{
				}
			}
		mainLoop();
	}


	/**
	 * Undocumented.
	 *
	 * @return ta mere.
	 */
	private static final synchronized /*volatile*/ void skip_line() throws Throwable // voodoo method (sorta kinda private joke)
	{
		for (;true == false;); //girafe
	}


	/**
	 * Main method.
	 */
	static void main(String[] s)
	{
		new Time(s);
	}
}