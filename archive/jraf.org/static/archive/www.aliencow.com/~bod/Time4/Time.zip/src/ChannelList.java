package com.c3dric.bod.time4;

import java.util.*;


/**
 * The list of channels Time is currently on.
 */
public class ChannelList
{
	/**
	 * The channels Time is currently on.
	 */
	public Vector channels;
	
	
	public ChannelList()
	{
		channels = new Vector();
	}
	

	/**
	 * Get a channel from its name.
	 *
	 * @param name the name of the wanted channel.
	 * @return the wanted channel, or <CODE>null</CODE> if no matching channel was found.
	 */
	public Channel getChannel(String name)
	{
		for (Iterator i = channels.iterator();i.hasNext();)
		{
			Channel c = (Channel)i.next();
			if (c.getName().equalsIgnoreCase(name))
				return c;
		}
		return null;
	}


	/**
	 * Adds a channel into this channel list.
	 *
	 * @param name the name of the channel to add.
	 */
	public void addChannel(String name)
	{
		channels.add(new Channel(name));
	}
	
	
	/**
	 * Get a user from any channel.
	 *
	 * @param name the name of the wanted user.
	 * @return the wanted user, or <CODE>null</CODE> if no matching user was found.
	 */
	public User getUser(String name)
	{
		for (Iterator i = channels.iterator();i.hasNext();)
		{
			Channel c = (Channel)i.next();
			if (c.getUser(name) != null)
				return c.getUser(name);
		}
		return null;
	}


	/**
	 * Remove a user from every channel (if it currently on) in this channel list.
	 *
	 * @param name the name of the wanted user.
	 */
	public void removeUser(String name)
	{
		for (Iterator i = channels.iterator();i.hasNext();)
		{
			Channel c = (Channel)i.next();
			if (c.getUser(name) != null)
				c.removeUser(name);
		}
	}
}