package com.c3dric.bod.time4;


import java.io.*;
import java.awt.*;
import java.util.*;
import java.text.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.text.*;



/**
 * This is the display for time, but also the console where user enters commands.
 */
public class Display extends JFrame implements KeyListener
{
	/**
	 * The out text area.
	 */
	protected JTextPane out;

	/**
	 * The scroll pane.
	 */
	protected JScrollPane scrollPane;
	
	/**
	 * The in text field.
	 */
	protected JTextField in;
	
	/**
	 * The time the Display belongs to.
	 */
	protected Time time;
	
	/**
	 * If <CODE>true</CODE>, this display is text mode instead of Swing.
	 */
	protected boolean noConsole;
	
	/**
	 * The log file.
	 */
	protected PrintWriter logOut;
	
	/**
	 * Formats the date only to display (log file gets default Date.toString() formating)
	 */
	protected SimpleDateFormat format;


	
	/**
	 * Displays a normal text line with a specified color.
	 *
	 * @param s the line to send.
	 * @param c the color to use.
	 */
	protected synchronized void out(String s,Color c)
	{
		try
		{
			logOut = new PrintWriter(new FileOutputStream("log.txt",true),true);
			logOut.println("["+new Date()+"] "+s);
			logOut.flush();
			logOut.close();
		}
		catch (IOException e)
		{
			warning("problem while writing to log file",e);
		}
		if (!noConsole)
		{
			SimpleAttributeSet style = new SimpleAttributeSet();
			style.addAttribute(StyleConstants.Foreground,c);
			try
			{
				out.getDocument().insertString(out.getDocument().getLength(),"\n"+"["+format.format(new Date())+"] "+s,style);
				out.setCaretPosition(out.getDocument().getLength());
			}
			catch (BadLocationException e)
			{
				System.err.println("["+new Date()+"] Fatal error: problem with the Display ("+e+").");
			}
		}
		else
			System.out.println("["+format.format(new Date())+"] "+s);
	}


	/**
	 * Displays a normal text line (black).
	 *
	 * @param s the line to send.
	 */
	protected void out(String s)
	{
		out(s,new Color(0,0,0));
	}
	
	
	/**
	 * Logs a normal text line.
	 *
	 * @param s the line to send.
	 */
	protected void logOut(String s)
	{
		try
		{
			logOut = new PrintWriter(new FileOutputStream("log.txt",true),true);
			logOut.println("["+new Date()+"] "+s);
			logOut.flush();
			logOut.close();
		}
		catch (IOException e)
		{
			warning("problem while writing to log file",e);
		}
	}

	
	/**
	 * Displays a message line.
	 *
	 * @param s the line to send.
	 */
	public void message(String s)
	{
		if (s.equals(""))
			out("");
		else
			out(s.substring(0,1).toUpperCase()+s.substring(1)+".");
	}
	
	
	/**
	 * Displays a message line, only to the logfile.
	 *
	 * @param s the line to send.
	 */
	public void logMessage(String s)
	{
		if (s.equals(""))
			logOut("");
		else
			logOut(s.substring(0,1).toUpperCase()+s.substring(1)+".");
	}

	
	/**
	 * Displays a warning line.
	 *
	 * @param s the line to send.
	 */
	public void warning(String s)
	{
		out("Warning: "+s+".",new Color(0,0,255));
	}


	/**
	 * Displays a warning line.
	 *
	 * @param s the line to send.
	 * @param t the associated exception.
	 */
	public void warning(String s,Throwable t)
	{
		warning(s+" ("+t+")");
	}
	
	
	/**
	 * Displays a fatal error line.
	 *
	 * @param s the line to send.
	 */
	public void fatal(String s)
	{
		out("Fatal error: "+s+".",new Color(255,0,0));
		System.err.println("Fatal error: "+s+".");
		try
		{
			Thread.currentThread().join();
		}
		catch (InterruptedException e)
		{
		}
	}


	/**
	 * Displays a fatal error line.
	 *
	 * @param s the line to send.
	 * @param t the associated exception.
	 */
	public void fatal(String s,Throwable t)
	{
		fatal(s+" ("+t+")");
	}


	/**
	 * Displays a debug line.
	 *
	 * @param s the line to send.
	 */
	public void debug(String s)
	{
		out("Debug: \""+s+"\".",new Color(128,0,128));
		System.out.println("Debug: \""+s+"\".");
	}

	
	/**
	 * User presses enter : text is sent to server, or server-simulated if in debug mode.
	 */
	protected void doIt()
	{
		if (time.isDebugMode())
			if (in.getText().startsWith("/"))
				time.simulateServerData(in.getText().substring(1));
			else
				time.simulateServerData(":BoD!bod@c3dric.com PRIVMSG #nous :"+in.getText());
		else
			time.send(in.getText());
	}
	
	
	public void keyPressed(KeyEvent e)
	{
		switch (e.getKeyCode())
		{
			case KeyEvent.VK_UP:
			break;

			case KeyEvent.VK_DOWN:
			break;

			case KeyEvent.VK_ENTER:
				doIt();
			break;
		}
	}

	
	public void keyTyped(KeyEvent e)
	{
	}
	
	
	public void keyReleased(KeyEvent e)
	{
	}
	
	
	/**
	 * The constructor.
	 *
	 * @param t the Time object associated with this Console.
	 * @param noConsole if <CODE>true</CODE>, this display will only be text mode based, otherwise it will be Swinged.
	 */
	public Display(Time t,boolean noConsole)
	{
		time = t;
		this.noConsole = noConsole;
		format = new SimpleDateFormat("HH:mm:ss");
		File logFile = new File("log.txt");
		try
		{
			if (!logFile.exists())
				logFile.createNewFile();
			logOut = new PrintWriter(new FileOutputStream("log.txt",true),true);
			logOut.println("************");
		}
		catch (IOException e)
		{
			warning("problem while attemting to initialize log file",e);
		}
		logOut.flush();
		logOut.close();

		if (!noConsole)
		{
			out = new JTextPane();
			out.setEditable(false);
			scrollPane = new JScrollPane(out);
			getContentPane().add(scrollPane,"Center");
			
			in = new JTextField();
			in.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
			in.addKeyListener(this);
			getContentPane().add(in,"South");
		
			addWindowListener(new WindowAdapter()
			{
				public synchronized void windowClosing(WindowEvent evt)
				{
		  			time.quit();
				}
			});
	
			setSize(640,480);
			setLocation(640,480);
			//setTitle(t.getVersion().productFull()); // <- version is null at this point
			setTitle("Time 4");
			show();
			Utils.setDisplay(this);
		}
	}
}