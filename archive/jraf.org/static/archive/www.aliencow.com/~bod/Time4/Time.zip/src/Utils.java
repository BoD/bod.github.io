package com.c3dric.bod.time4;


import java.io.*;
import java.util.*;




/**
 * This class brings misc utilities useful for the time engine, and for the mods.
 */
public abstract class Utils
{
	/**
	 * Useful for <CODE>random(int)</CODE>.
	 */
	protected static int lastRandom = 0;
	protected static Random random = new Random();
	
	protected static Display display;

	
	/**
	 * Sets current display (for error reporting).
	 *
	 * @param d the <CODE>Display</CODE> to use.
	 */
	public static void setDisplay(Display d)
	{
		display = d;
	}

	
	public static Display getDisplay()
	{
		return display;
	}

	
	/**
	 * Tokenizes the string into more little strings, with a parameter for the delimitator.
	 *
	 * @param r the string to tokenize.
	 * @param t the string tha delimits the tokens (each character in the string is a delimitator).
	 * @return the array of string after tokenization.
	 */
	public static String[] s(String r,String t)
	{
		// needs high improvement !
		StringTokenizer st = new StringTokenizer(r,t);
		String[] res = new String[st.countTokens()];
		for (int i = 0;i < res.length;i++)
			res[i] = st.nextToken();
		return res;
	}


	/**
	 * Tokenizes the string into more little strings.
	 *
	 * @param r the string to tokenize.
	 * @return the array of strings after tokenization.
	 */
	public static String[] s(String r)
	{
		return s(r," \n\t");
	}


	/**
	 * Same as <CODE>s(String)</CODE> but keeps the trailing string after the first delimitator.
	 *
	 * @param r the string to tokenize.
	 * @return the array of strings after tokenization.
	 */
	public static String[] t(String r)
	{
		String[] s = s(r);
		String[] res = new String[s.length];
		for (int i = 0;i < res.length;i++)
		{
			res[i] = s[i];
			for (int j = i+1;j < res.length;j++)
				res[i] = res[i]+" "+s[j];
		}
		return res;
	}


	/**
	 * My random. Won't return the same result two consecutive times (except if z is zero or 1).
	 *
	 * @param z the int to choose a random number from.
	 * @return a random number between 0 and z-1.
	 */
	public static int random(int z)
	{
		if (z == 0 || z == 1)
			return (0);
		int	res = random.nextInt(z);
		while (res == lastRandom)
			res = random.nextInt(z);
		lastRandom = res;
		return res;
	}


	/**
	 * Takes a separated list, and returns a randomly chosen token form it.
	 *
	 * @param r the separated list.
	 * @param s the separator.
	 * @return a randomly chosen token.
	 */
	public static String randomList(String r,String s)
	{
		String[] res = s(r,s);
		return res[random(res.length)];
	}


	/**
	 * Takes a <CODE>#</CODE> separated list, and returns a randomly chosen token form it.
	 *
	 * @param r the <CODE>#</CODE> separated list.
	 * @return a randomly chosen token.
	 */
	public static String randomList(String r)
	{
		return randomList(r,"#");
	}


	/**
	 * Adds a zero behind the int if it is inferior than 10.
	 *
	 * @param i the int we want %2d.
	 * @return the well formed int.
	 */
	public static String leadingZero(int i)
	{
		if (i < 10)
			return ("0"+i);
		else
			return (""+i);
	}
	
	
	/**
	 * Replaces all the occurences of <CODE>t</CODE> by <CODE>n</CODE> in r.
	 *
	 * @param r the string in which we want to replace some occurences.
	 * @param t the string we want to replace.
	 * @param n the string we want replaced instead of t.
	 * @result the well formed string with every thing replaced.
	 */
	public static String replaceAll(String r,String t,String n)
	{
		StringBuffer b = new StringBuffer(r);
		int i;
	
		while ((i = r.indexOf(t)) != -1)
		{
			b.replace(i,i+t.length(),n);
			r = new String(b);
		}
		return r;
	}
	

	/**
	 * This will replace certain special token by their value.
	 *
	 * @param t the Time object, needed for replacing 
	 * @param r the string we want to parse.
	 * @result the well formed string with every special variables replaced.
	 */
	public static String parse(Time t,String r)
	{
		final String callName = "$callName";
		final String productName = "$productName";
		final String productVersion = "$productVersion";
		final String rand30 = "$rand30";
		final String rand12 = "$rand12";
		final String rand100 = "$rand100";
		final String ircK = "$ircK";
		final String ircB = "$ircB";
		final String ircU = "$ircU";

		r = replaceAll(r,callName,t.getCallName());
		r = replaceAll(r,productName,t.getVersion().productFull());
		r = replaceAll(r,productVersion,t.getVersion().version());
		r = replaceAll(r,rand30,leadingZero(random(30)+1));
		r = replaceAll(r,rand12,leadingZero(random(12)+1));
		r = replaceAll(r,rand100,leadingZero(random(100)));
		r = replaceAll(r,ircK,Irc.ircK);
		r = replaceAll(r,ircB,Irc.ircB);
		r = replaceAll(r,ircU,Irc.ircU);
		return r;
	}


	/**
	 * Replaces <CODE>$u1</CODE> and <CODE>$u2</CODE> by parameters u1 and u2.
	 *
	 * @param u1 first user.
	 * @param u2 second user.
	 * @result the well formed string with <CODE>$u1</CODE> and <CODE>$u2</CODE> replaced.
	 */
	public static String parse(Time t,String r,String u1,String u2)
	{
		r = parse(t,r);
		r = replaceAll(r,"$u1",u1);
		return replaceAll(r,"$u2",u2);
	}
	
	
	/**
	 * Removes every trailing characters that are not letters or digits.
	 *
	 * @param r the string you want to trim.
	 * @result the trimed string.
	 */
	public static String trim(String r)
	{
		StringBuffer s = new StringBuffer(r.trim());
		for (int i = s.length()-1;i >= 0 && !Character.isLetterOrDigit(s.charAt(i));i--)
			s.setCharAt(i,' ');
		return s.toString().trim();
	}
	
	
	/**
	 * Returns a random line in a file.
	 *
	 * @param file the path to the file you want to get a line in.
	 * @result the random line.
	 */
	public static String randomLine(String file)
	{
		try
		{
			BufferedReader r = new BufferedReader(new FileReader(file));
			int nbLines = 0;
			while (r.readLine() != null)
				nbLines++;
			r = new BufferedReader(new FileReader(file));
			String res = "";
			nbLines = random(nbLines);
			for (int i = 0;i < nbLines;i++)
				res = r.readLine();
			r.close();
			return res;
		}
		catch (Exception e)
		{
			display.warning("problem while reading "+file+" for Tokenizer.randomLine",e);
			return "";
		}
	}
	
	
	/**
	 * Puts a space every 3 digits.
	 *
	 * @param s the string you want to format.
	 * @result the well formed string.
	 */
	public static String thousandSpaces(String s)
	{
		String res = "";
		for (int i = 0;i < s.length();i++)
		{
			if (i%3 == 0 && i != 0)
				res = " "+res;
			res = s.charAt(s.length()-1-i)+res;
		}
		return res;
	}
	

	/**
	 * Returns an int that corresponds to the byte in parameter, without its sign.
	 *
	 * @param b the byte you want to know the unsigned equivalent.
	 * @result the int equivalent in an unsigned base.
	 */
	public static int unsignByte(byte b)
	{
		if (b < 0)
			return 256+b;
		else
			return b;
	}
	
	
	/**
	 * Tests if an array contains a specific object (using <CODE>equals()</CODE> method).
	 *
	 * @param a the array.
	 * @param o the object you want to test.
	 * @return <CODE>true</CODE> if a contains o, <CODE>false</CODE> otherwise.
	 */
	public static boolean arrayContains(Object[] a,Object o)
	{
		for (int i = 0;i < a.length;i++)
			if (a[i].equals(o))
				return true;
		return false;
	}
}