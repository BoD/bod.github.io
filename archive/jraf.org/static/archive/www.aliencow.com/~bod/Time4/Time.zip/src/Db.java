package com.c3dric.bod.time4;


import java.io.*;
import java.util.*;
import java.util.zip.*;



/**
 * This is the Person database.
 */
public class Db
{
	/**
	 * The persons.
	 */
	protected Vector persons;
	 
	
	
	/**
	 * @return persons.
	 */
	public Vector getPersons()
	{
		return persons;
	}

	
	/**
	 * Gets the <CODE>Person</CODE> with the given user and ip.
	 *
	 * @param user the user for the person to look up.
	 * @param ip the ip for the person to look up.
	 * @return the found <CODE>Person</CODE>, or <CODE>null</CODE> if no match was found.
	 */
	public Person getPerson(String user,byte[] ip)
	{
		for (Iterator i = persons.iterator();i.hasNext();) // first searches for x.y ips
		{
			Person p = (Person)i.next();
			if (p.getUsers().contains(user) && p.getIps().contains(""+Utils.unsignByte(ip[0])+"."+Utils.unsignByte(ip[1])))
				return p;
		}
		// no match here
		for (Iterator i = persons.iterator();i.hasNext();) // then searches for x ips (for class A persons)
		{
			Person p = (Person)i.next();
			if (p.getUsers().contains(user) && p.getIps().contains(""+Utils.unsignByte(ip[0])))
				return p;
		}
		return null;
	}
	
	
	/**
	 * Gets the <CODE>Person</CODE> with the given nick. If there are several matches, returns the one with the latest lastSeen.
	 *
	 * @param nick the nick for the person to look up.
	 * @return the found <CODE>Person</CODE>, or <CODE>null</CODE> if no match was found.
	 */
	public Person getPerson(String nick)
	{
		Person res = null;
		for (Iterator i = persons.iterator();i.hasNext();)
		{
			Person p = (Person)i.next();
			for (Iterator j = p.getNicks().iterator();j.hasNext();)
			{
				String n = (String)j.next();
				if (n.equalsIgnoreCase(nick))
				{
					if (res == null)
						res = p;
					else
						if (res.getLastSeen().before(p.getLastSeen()))
							res = p;
					break; // stops comparing nicks...
				}
			}
		}
		return res;
	}

	
	/**
	 * Adds a <CODE>Person</CODE> int this database (in memory and physically in the db directory).
	 *
	 * @param p the <CODE>Person</CODE> to add.
	 */
	public void addPerson(Person p) throws IOException
	{
		persons.add(p);
		p.dump();
	}
	
	
	/**
	 * Loads the db into this <CODE>Db</CODE> object.
	 */
	protected void reload() throws FileNotFoundException,IOException
	{
		persons = new Vector();
		File db = new File("db");
		File[] list = db.listFiles();
		Properties props;
		for (int i = 0;i < list.length;i++)
			if (list[i].toString().endsWith(".tpr")) // ignore db.zip
			{
				FileInputStream fis = new FileInputStream(list[i]);
				props = new Properties();
				props.load(fis);
				fis.close();
				persons.add(new Person(props));
			}
	}
	
	
	/**
	 * Dumps the whole db to individual files and also to a zip file.
	 */
	public void dump() throws IOException
	{
		for (Iterator i = persons.iterator();i.hasNext();)
			((Person)i.next()).dump();
		File zipFile = new File("db/db.zip");
		if (!zipFile.exists())
			zipFile.createNewFile();
		ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile));
		zos.setLevel(9);
		zos.setMethod(ZipOutputStream.DEFLATED);
		File db = new File("db");
		File[] list = db.listFiles();
		for (int i = 0;i < list.length;i++)
			if (list[i].toString().endsWith(".tpr")) // ignore db.zip
			{
				FileInputStream fis = new FileInputStream(list[i]);
				ZipEntry ze = new ZipEntry(list[i].getName());
				zos.putNextEntry(ze);
				int r = fis.read();
				while (r != -1)
				{
					zos.write(r);
					r = fis.read();
				}
				zos.setComment("Time 4 db file created on "+new Date());
			}
		zos.close();
	}

	
	/**
	 * Loads the db.
	 */
	public Db() throws FileNotFoundException,IOException
	{
		reload();
	}
}