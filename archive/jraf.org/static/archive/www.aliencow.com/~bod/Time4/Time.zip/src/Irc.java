package com.c3dric.bod.time4;


/**
 * This class countains usefull constants for irc.
 */
public abstract class Irc
{
	/**
	 * Mirc color.
	 */
	public static final String ircK = "";

	/**
	 * Bold.
	 */
	public static final String ircB = "";
	
	/**
	 * Underline.
	 */
	public static final String ircU = "";
	
	/**
	 * Italic.
	 */
	public static final String ircI = "";

	/**
	 * CTCP.
	 */
	public static final String ircC = "";
}