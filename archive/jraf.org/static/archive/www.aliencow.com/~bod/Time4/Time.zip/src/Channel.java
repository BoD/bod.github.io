package com.c3dric.bod.time4;

import java.util.*;


/**
 * The representation for an irc channel.
 */
public class Channel
{
	protected String name;
	
	/**
	 * The users currently on the channel.
	 */
	protected Vector users;
	
	
	public Channel(String name)
	{
		this.name = name;
		users = new Vector();
	}
	
	
	public String getName()
	{
		return name;
	}
	

	public Vector getUsers()
	{
		return users;
	}
	
	
	/**
	 * Returns a user from this channel user list.
	 *
	 * @param name the name of the user.
	 * @return the user associated with name, or <CODE>null</CODE> if no matching user was found.
	 */
	public User getUser(String name)
	{
		for (Iterator i = users.iterator();i.hasNext();)
		{
			User u = (User)i.next();
			if (u.getName().equalsIgnoreCase(name))
				return u;
		}
		return null;
	}


	/**
	 * Adds a user into this channel user list.
	 *
	 * @param name the name of the user.
	 * @param o <CODE>true</CODE> if the user is op, <CODE>false</CODE> otherwise.
	 * @param v <CODE>true</CODE> if the user is voiced, <CODE>false</CODE> otherwise.
	 */
	public void addUser(String name,boolean o,boolean v)
	{
		User user = new User(name,o,v);
		users.add(user);
	}
			

	/**
	 * Removes a user from this channel user list.
	 *
	 * @param name the name of the user.
	 */
	public void removeUser(String name)
	{
		users.remove(getUser(name));
	}


	/**
	 * Returns <CODE>true</CODE> if this channel user list contains the user, <CODE>false</CODE> otherwise.
	 *
	 * @param user the name of the user you want to check.
	 * @return <CODE>true</CODE> if this channel user list contains the user, <CODE>false</CODE> otherwise.
	 */
	public boolean isOn(String name)
	{
		return getUser(name) != null;
	}
	
	
	/**
	 * Returns a randomly chosen user from this channel user list, excepting W, X, and time's current nick.
	 *
	 * @param t needed for current nick.
	 * @return a randomly chosen user name from this channel user list.
	 */
	public String randomUser(Time t)
	{
		Vector users = new Vector(this.users);
		users.remove(new User("w",false,false));
		users.remove(new User("x",false,false));
		users.remove(new User(t.getCurrentNick(),false,false));
		return ((User)users.elementAt(Utils.random(users.size()))).getName();
	}
	

	/**
	 * Returns a randomly chosen user from this channel user list, except W, X, time's current nicke and the name given in paramater.
	 *
	 * @param t needed for current nick.
	 * @param except the name you don't want to be chosen.
	 * @return a randomly chosen user name from this channel user list, excepting the name given.
	 */
	public String randomUser(Time t,String except)
	{
		Vector users = new Vector(this.users);
		users.remove(new User("w",true,false));
		users.remove(new User("x",true,false));
		users.remove(new User(t.getCurrentNick(),false,false));
		users.remove(new User(except,true,false));
		if (users.size() == 0)
			return null;
		else
			return ((User)users.elementAt(Utils.random(users.size()))).getName();
	}
}