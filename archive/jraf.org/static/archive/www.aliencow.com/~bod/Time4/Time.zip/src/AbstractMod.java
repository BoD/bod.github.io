package com.c3dric.bod.time4;

import java.io.*;
import java.util.*;


/**
 * Abstract module. If you want to make a module, to extend this class is a good idea.
 */
public abstract class AbstractMod implements Mod
{
	protected Properties props;
	protected Time time;

	
	public void init(Time time) throws ModException
	{
		this.time = time;
		props = new Properties();
		String[] s = Utils.s(getClass().getName(),".");
		String modName = s[s.length-1];
		try
		{
			props.load(new FileInputStream(new File("mod/"+modName+"/"+modName+".ini")));
		}
		catch (FileNotFoundException e)
		{
			throw new ModException("could not find "+modName+".ini file ("+e+")");
		}
		catch (IOException e)
		{
			throw new ModException("could not read "+modName+".ini file ("+e+")");
		}
	}
	
	
	/**
	 * You have to override this method.
	 */
	public boolean accept(String chan,String n,String r,String[] s,String[] t) throws ModException
	{
		return false;
	}
}