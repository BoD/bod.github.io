import com.c3dric.bod.time4.*;


/**
 * This is an example of a module. It accepts question beginning with "test".
 */
public class ModExample extends AbstractMod
{
	public boolean accept(String chan,String n,String r,String[] s,String[] t) throws ModException
	{
		if (s.length > 0 && s[0].equalsIgnoreCase("girafe"))
		{
			time.timeSay(chan,n,r);
			return true;
		}
		else
			return false;
	}
}