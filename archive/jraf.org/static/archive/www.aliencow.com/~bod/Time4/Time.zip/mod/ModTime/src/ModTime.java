import com.c3dric.bod.time4.*;

import java.io.*;
import java.text.*;
import java.util.*;


/**
 * The default main module.
 */
public class ModTime extends AbstractMod
{
	/**
	 * Gives time and number of seconds before or after y2k.
	 */
	protected void timeTime(String chan,String n,String r,String[] s,String[] t)
	{
		GregorianCalendar now = new GregorianCalendar();
		GregorianCalendar y2k = new GregorianCalendar(2001,0,1,0,0,0);
		int ttsb = (int)((y2k.getTime().getTime()-now.getTime().getTime())/1000);
		if (ttsb > 0)
			ttsb++;
		if ((s.length == 1) || (s[1].equalsIgnoreCase("fr") || s[1].equalsIgnoreCase("france")))
		{
			now = new GregorianCalendar(TimeZone.getTimeZone("Europe/Paris"));
			if (ttsb > 0)
				time.timeSay(chan,n,"il est "+now.get(Calendar.HOUR_OF_DAY)+":"+Utils.leadingZero(now.get(Calendar.MINUTE))+":"+Utils.leadingZero(now.get(Calendar.SECOND))+" (en France) et il reste "+Utils.thousandSpaces(""+ttsb)+" secondes avant l'an 2001 !");
			else
				time.timeSay(chan,n,"il est "+now.get(Calendar.HOUR_OF_DAY)+":"+Utils.leadingZero(now.get(Calendar.MINUTE))+":"+Utils.leadingZero(now.get(Calendar.SECOND))+" (en France) et l'an 2001 est pass� de "+Utils.thousandSpaces(""+(-ttsb))+" secondes !");
		}	
		else
		if (s[1].equalsIgnoreCase("qc") || s[1].equalsIgnoreCase("quebec") || s[1].equalsIgnoreCase("qu�bec"))
		{
			now = new GregorianCalendar(TimeZone.getTimeZone("America/Montreal"));
			if (ttsb > 0)
				time.timeSay(chan,n,"il est "+now.get(Calendar.HOUR_OF_DAY)+":"+Utils.leadingZero(now.get(Calendar.MINUTE))+":"+Utils.leadingZero(now.get(Calendar.SECOND))+" (au Qu�bec) et il reste "+Utils.thousandSpaces(""+ttsb)+" secondes avant l'an 2001 !");
			else
				time.timeSay(chan,n,"il est "+now.get(Calendar.HOUR_OF_DAY)+":"+Utils.leadingZero(now.get(Calendar.MINUTE))+":"+Utils.leadingZero(now.get(Calendar.SECOND))+" (au Qu�bec) et l'an 2001 est pass� de "+Utils.thousandSpaces(""+(-ttsb))+" secondes !");
		}
		else
		{
			String[] ids = TimeZone.getAvailableIDs();
			TimeZone tz = null;
			boolean found = false;
			for (int o = 0;o < ids.length;o++)
				if (ids[o].toLowerCase().indexOf(s[1].toLowerCase()) != -1)
				{
					found = true;
					tz = TimeZone.getTimeZone(ids[o]);
					break;
				}
			if (found)
			{
				now = new GregorianCalendar(tz);
				if (ttsb > 0)
					time.timeSay(chan,n,"il est "+now.get(Calendar.HOUR_OF_DAY)+":"+Utils.leadingZero(now.get(Calendar.MINUTE))+":"+Utils.leadingZero(now.get(Calendar.SECOND))+" (dans la zone \""+tz.getID()+"\") et il reste "+Utils.thousandSpaces(""+ttsb)+" secondes avant l'an 2001 !");
				else
					time.timeSay(chan,n,"il est "+now.get(Calendar.HOUR_OF_DAY)+":"+Utils.leadingZero(now.get(Calendar.MINUTE))+":"+Utils.leadingZero(now.get(Calendar.SECOND))+" (dans la zone \""+tz.getID()+"\") et l'an 2001 est pass� de "+Utils.thousandSpaces(""+(-ttsb))+" secondes !");
			}
			else
				time.timeSay(chan,n,"d�sol� je ne connais pas de pays ou de ville du nom de "+s[1]);
		}
	}


	/**
	 * An extended version of !time time.
	 */
	protected void timeXTime(String chan,String n,String r,String[] s,String[] t)
	{
		GregorianCalendar now = new GregorianCalendar();
		GregorianCalendar y2k = new GregorianCalendar(2001,0,1,0,0,0);
		int h = now.get(Calendar.HOUR_OF_DAY);
		int min = now.get(Calendar.MINUTE);
		int sec = now.get(Calendar.SECOND);
		int ttsb = (int)((y2k.getTime().getTime()-now.getTime().getTime())/1000);
		if (ttsb > 0)
			ttsb++;
		time.timeSay(chan,n,"Date="+now.get(Calendar.DATE)+"/"+(now.get(Calendar.MONTH)+1)+"/"+now.get(Calendar.YEAR)+", Time="+h+":"+min+":"+sec+", Unix Time UTC="+System.currentTimeMillis()/1000+"L, Swatch Beat=@"+(int)Math.floor((h*3600+(min*60)+sec)*1000/86400)+", ST2001(TTSB)="+ttsb);
	}

	
	/**
	 * Gives last seen for n.
	 */ 
	protected void timeSeen(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length == 1)
		{
			Vector db = new Vector(time.getDb().getPersons());
			Collections.sort(db);
			Person p1,p2,p3,p4;
			p1 = (Person)db.elementAt(db.size()-1);
			p2 = (Person)db.elementAt(db.size()-2);
			p3 = (Person)db.elementAt(db.size()-3);
			p4 = (Person)db.elementAt(db.size()-4);
			time.timeSay(chan,n,"les 4 derni�res personnes que j'ai vu sont "+p1.getNicks().elementAt(0)+", "+p2.getNicks().elementAt(0)+", "+p3.getNicks().elementAt(0)+" et "+p4.getNicks().elementAt(0)+".");
		}
		else
		if (s[1].equalsIgnoreCase(time.getCurrentNick()) || s[1].equalsIgnoreCase(time.getCallName()) || s[1].equalsIgnoreCase("!"+time.getCurrentNick()) || s[1].equalsIgnoreCase("!"+time.getCallName()))
			time.timeSay(chan,n,"la derni�re fois que je me suis vu moi-m�me c'�tait demain... enfin je suis pas s�r.");
		else
		if (s[1].length() > 9 || s.length > 2)
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseAbuse"))));
		else
		if (!time.isDebugMode() && time.getChannelList().getChannel(chan).isOn(s[1]))
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseInsultes1")))+"! "+s[1]+" est ici sur le channel...");
		else
		{
			Person p = time.getDb().getPerson(s[1]);
			if (p == null)
				time.timeSay(chan,n,"d�sol�, mais je n'ai jamais vu de "+s[1]+".");
			else
			{
				GregorianCalendar seen = new GregorianCalendar();
				GregorianCalendar now = new GregorianCalendar();
				seen.setTime(p.getLastSeen());
				int diff = (int)((new Date().getTime()-p.getLastSeen().getTime())/3600000);
				SimpleDateFormat f = new SimpleDateFormat("H:mm");
				SimpleDateFormat f2 = new SimpleDateFormat("dd/MM/yyyy, � H:mm");
				String[] days = Utils.s("dimanche lundi mardi mercredi jeudi vendredi samedi");
				if (diff == 0)
					time.timeSay(chan,n,"je l'ai vu"+(p.getGender().equals("female")?"e":"")+" il y'a moins d'une heure");
				else
				if (diff == 1)
					time.timeSay(chan,n,"la derni�re fois que j'ai vu "+s[1]+", c'�tait il y a tout juste 1 heure");
				else
				if (diff <= 12)
					time.timeSay(chan,n,"la derni�re fois que j'ai vu "+s[1]+", c'�tait il y a "+diff+" heures");
				else
				if (now.get(Calendar.DAY_OF_YEAR) == seen.get(Calendar.DAY_OF_YEAR))
					time.timeSay(chan,n,"la derni�re fois que j'ai vu "+s[1]+", c'�tait aujourd'hui, � "+f.format(p.getLastSeen()));
				else
				if (now.get(Calendar.DAY_OF_YEAR) == seen.get(Calendar.DAY_OF_YEAR)+1)
					time.timeSay(chan,n,"la derni�re fois que j'ai vu "+s[1]+", c'�tait hier, � "+f.format(p.getLastSeen()));
				else
				if (now.get(Calendar.DAY_OF_YEAR) == seen.get(Calendar.DAY_OF_YEAR)+2)
					time.timeSay(chan,n,"la derni�re fois que j'ai vu "+s[1]+", c'�tait avant-hier, � "+f.format(p.getLastSeen()));
				else
				if (diff <= 24*7)
					time.timeSay(chan,n,"la derni�re fois que j'ai vu "+s[1]+", c'�tait "+days[seen.get(GregorianCalendar.DAY_OF_WEEK)-1]+" dernier, � "+f.format(p.getLastSeen()));
				else
					time.timeSay(chan,n,"la derni�re fois que j'ai vu "+s[1]+", c'�tait le "+f2.format(p.getLastSeen()));
			}
		}
	}

	
	/**
	 * An extented version of seen (gives also quitmsg and privmsg).
	 */ 
	protected void timeXSeen(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length == 1)
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseSeen"))));
		else
		if (s[1].equalsIgnoreCase(time.getCurrentNick()) || s[1].equalsIgnoreCase(time.getCallName()) || s[1].equalsIgnoreCase("!"+time.getCurrentNick()) || s[1].equalsIgnoreCase("!"+time.getCallName()))
			time.timeSay(chan,n,"la derni�re fois que je me suis vu moi-m�me c'�tait demain, et mon dernier message �tait \""+Utils.parse(time,Utils.randomList(props.getProperty("responseInsultes1")))+"\"...");
		else
		if (s[1].length() > 9 || s.length > 2)
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseAbuse"))));
		else
		if (!time.isDebugMode() && time.getChannelList().getChannel(chan).isOn(s[1]))
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseInsultes1")))+"! "+s[1]+" est ici sur le channel...");
		else
		{
			Person p = time.getDb().getPerson(s[1]);
			if (p == null)
				time.timeSay(chan,n,"d�sol�, mais je n'ai jamais vu de "+s[1]+".");
			else
			{
				GregorianCalendar seen = new GregorianCalendar();
				GregorianCalendar now = new GregorianCalendar();
				seen.setTime(p.getLastSeen());
				int diff = (int)((new Date().getTime()-p.getLastSeen().getTime())/3600000);
				SimpleDateFormat f = new SimpleDateFormat("H:mm");
				SimpleDateFormat f2 = new SimpleDateFormat("dd/MM/yyyy, � H:mm");
				String[] days = Utils.s("dimanche lundi mardi mercredi jeudi vendredi samedi");
				String msg = "";
				if (!p.getLastQuitMessage().equals(""))
					msg += " Son message de quit �tait \""+p.getLastQuitMessage()+"\".";
				if (!p.getLastPrivmsg().equals(""))
					msg += " Sa derni�re phrase �tait \""+p.getLastPrivmsg()+"\".";
					
				if (diff == 0)
					time.timeSay(chan,n,"je l'ai vu"+(p.getGender().equals("female")?"e":"")+" il y'a moins d'une heure."+msg);
				else
				if (diff == 1)
					time.timeSay(chan,n,"la derni�re fois que j'ai vu "+s[1]+", c'�tait il y a tout juste 1 heure."+msg);
				else
				if (diff <= 12)
					time.timeSay(chan,n,"la derni�re fois que j'ai vu "+s[1]+", c'�tait il y a "+diff+" heures."+msg);
				else
				if (now.get(Calendar.DAY_OF_YEAR) == seen.get(Calendar.DAY_OF_YEAR))
					time.timeSay(chan,n,"la derni�re fois que j'ai vu "+s[1]+", c'�tait aujourd'hui, � "+f.format(p.getLastSeen())+"."+msg);
				else
				if (now.get(Calendar.DAY_OF_YEAR) == seen.get(Calendar.DAY_OF_YEAR)+1)
					time.timeSay(chan,n,"la derni�re fois que j'ai vu "+s[1]+", c'�tait hier, � "+f.format(p.getLastSeen())+"."+msg);
				else
				if (now.get(Calendar.DAY_OF_YEAR) == seen.get(Calendar.DAY_OF_YEAR)+2)
					time.timeSay(chan,n,"la derni�re fois que j'ai vu "+s[1]+", c'�tait avant-hier, � "+f.format(p.getLastSeen())+"."+msg);
				else
				if (diff <= 24*7)
					time.timeSay(chan,n,"la derni�re fois que j'ai vu "+s[1]+", c'�tait "+days[seen.get(GregorianCalendar.DAY_OF_WEEK)-1]+" dernier, � "+f.format(p.getLastSeen())+"."+msg);
				else
					time.timeSay(chan,n,"la derni�re fois que j'ai vu "+s[1]+", c'�tait le "+f2.format(p.getLastSeen())+"."+msg);
			}
		}
	}

	
	/**
	 * Gives last quit message for n.
	 */
	protected void timeQuitmsg(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length == 1)
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseQuitmsg"))));
		else
		if (s[1].equalsIgnoreCase(time.getCurrentNick()) || s[1].equalsIgnoreCase(time.getCallName()) || s[1].equalsIgnoreCase("!"+time.getCurrentNick()) || s[1].equalsIgnoreCase("!"+time.getCallName()))
			time.timeSay(chan,n,"mon dernier message de quit c'�tait \""+Utils.parse(time,Utils.randomList(props.getProperty("responseInsultes1")))+"\".");
		else
		if (s[1].length() > 9 || s.length > 2)
			time.timeSay(chan,n,Utils.randomList(Utils.parse(time,props.getProperty("responseAbuse"))));
		else
		{
			Person p = time.getDb().getPerson(s[1]);
			if (p == null)
				time.timeSay(chan,n,"d�sol�, mais je ne connais pas de "+s[1]);
			else
			if (p.getLastQuitMessage().equals(""))
				time.timeSay(chan,n,"d�sol�, j'ai pas de quit message pour "+s[1]+"... Peut-�tre qu'"+(p.getGender().equals("female")?"elle":"il")+" a jamais quitt� quand j'�tais l�. Ou alors, "+(p.getGender().equals("female")?"elle":"il")+" a quitt� avec un message vide. Ou bien encore, je suis completement buggu� et je dis portnawak (hypoth�se la plus probable). . .");
			else
				time.timeSay(chan,n,"le dernier quit message que j'ai vu de "+s[1]+" c'�tait : \""+p.getLastQuitMessage()+"\".");
		}
	}

	
	/**
	 * Gives last privmsg for n.
	 */
	protected void timePrivmsg(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length == 1)
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responsePrivmsg"))));
		else
		if (s[1].equalsIgnoreCase(time.getCurrentNick()) || s[1].equalsIgnoreCase(time.getCallName()) || s[1].equalsIgnoreCase("!"+time.getCurrentNick()) || s[1].equalsIgnoreCase("!"+time.getCallName()))
			time.timeSay(chan,n,"la derni�re phrase que j'ai dit sur le channel est \"la derni�re phrase que j'ai dit sur le channel est (...)\".");
		else
		if (s[1].length() > 9 || s.length > 2)
			time.timeSay(chan,n,Utils.randomList(Utils.parse(time,props.getProperty("responseAbuse"))));
		else
		{
			Person p = time.getDb().getPerson(s[1]);
			if (p == null)
				time.timeSay(chan,n,"d�sol�, mais je ne connais pas de "+s[1]);
			else
			if (p.getLastPrivmsg().equals(""))
				time.timeSay(chan,n,"d�sol�, j'ai pas de dernier message pour "+s[1]+"... Peut-�tre qu'"+(p.getGender().equals("female")?"elle":"il")+" a jamais parl� quand j'�tais l� ?");
			else
				time.timeSay(chan,n,"la derni�re phrase que "+s[1]+" a dit sur le channel est : \""+p.getLastPrivmsg()+"\".");
		}
	}

	
	/**
	 * Gives emails for n.
	 */
	protected void timeMail(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length == 1)
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseMail"))));
		else
		if (s[1].equalsIgnoreCase(time.getCurrentNick()) || s[1].equalsIgnoreCase(time.getCallName()) || s[1].equalsIgnoreCase("!"+time.getCurrentNick()) || s[1].equalsIgnoreCase("!"+time.getCallName()))
			time.timeSay(chan,n,"mon email c'est mailto:"+time.getVersion().email());
		else
		if (s[1].length() > 9 || s.length > 2)
			time.timeSay(chan,n,Utils.randomList(Utils.parse(time,props.getProperty("responseAbuse"))));
		else
		{
			Person p = time.getDb().getPerson(s[1]);
			if (p == null)
				time.timeSay(chan,n,"d�sol�, mais je ne connais pas de "+s[1]);
			else
			if (p.getEmails() == null)
				time.timeSay(chan,n,"d�sol�, j'ai pas l'email de "+s[1]+"...");
			else
			{
				String res;
				if (n.equalsIgnoreCase(s[1]))
					res = "tu connais pas ton propre email ?! c'est ";
				else
					res = "l'email de "+s[1]+" c'est ";
				if (p.getEmails().size() == 1)
					res += "mailto:"+p.getEmails().elementAt(0);
				else if (p.getEmails().size() == 2)
					res += "mailto:"+p.getEmails().elementAt(0)+" ou "+"mailto:"+p.getEmails().elementAt(1);
				else
				{
					int max = p.getEmails().size();
					int j = 0;
					for (Iterator i = p.getEmails().iterator();j < max-1;j++)
						res += "mailto:"+i.next()+" ou ";
					res += "encore mailto:"+p.getEmails().elementAt(max-1);
				}
				time.timeSay(chan,n,res);
			}
		}
	}

	
	/**
	 * Gives homepages for n.
	 */
	protected void timeHomePage(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length == 1)
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseHomePage"))));
		else
		if (s[1].equalsIgnoreCase(time.getCurrentNick()) || s[1].equalsIgnoreCase(time.getCallName()) || s[1].equalsIgnoreCase("!"+time.getCurrentNick()) || s[1].equalsIgnoreCase("!"+time.getCallName()))
			time.timeSay(chan,n,"ma home page c'est "+time.getVersion().url());
		else
		if (s[1].length() > 9 || s.length > 2)
			time.timeSay(chan,n,Utils.randomList(Utils.parse(time,props.getProperty("responseAbuse"))));
		else
		{
			Person p = time.getDb().getPerson(s[1]);
			if (p == null)
				time.timeSay(chan,n,"d�sol�, mais je ne connais pas de "+s[1]);
			else
			if (p.getHomePages() == null)
				time.timeSay(chan,n,"d�sol�, j'ai pas la home page de "+s[1]+"...");
			else
			{
				String res;
				if (n.equalsIgnoreCase(s[1]))
					res = "tu connais pas ta propre home page ?! c'est ";
				else
					res = "la home page de "+s[1]+" c'est ";
				if (p.getHomePages().size() == 1)
					res += "http://"+p.getHomePages().elementAt(0);
				else if (p.getHomePages().size() == 2)
					res += "http://"+p.getHomePages().elementAt(0)+" ou "+"http://"+p.getHomePages().elementAt(1);
				else
				{
					int max = p.getHomePages().size();
					int j = 0;
					for (Iterator i = p.getHomePages().iterator();j < max-1;j++)
						res += "http://"+i.next()+" ou ";
					res += "encore http://"+p.getHomePages().elementAt(max-1);
				}
				time.timeSay(chan,n,res);
			}
		}
	}

	
	/**
	 * Gives icq uins for n.
	 */
	protected void timeUins(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length == 1)
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseUin"))));
		else
		if (s[1].equalsIgnoreCase(time.getCurrentNick()) || s[1].equalsIgnoreCase(time.getCallName()) || s[1].equalsIgnoreCase("!"+time.getCurrentNick()) || s[1].equalsIgnoreCase("!"+time.getCallName()))
			time.timeSay(chan,n,"tu sais, les bots n'ont pas d'ICQ... Par contre tu peut contacter mon auteur (BoD) au 3610027");
		else
		if (s[1].length() > 9 || s.length > 2)
			time.timeSay(chan,n,Utils.randomList(Utils.parse(time,props.getProperty("responseAbuse"))));
		else
		{
			Person p = time.getDb().getPerson(s[1]);
			if (p == null)
				time.timeSay(chan,n,"d�sol�, mais je ne connais pas de "+s[1]);
			else
			if (p.getUins() == null)
				time.timeSay(chan,n,"d�sol�, j'ai pas le num�ro d'icq de "+s[1]+"...");
			else
			{
				String res;
				if (n.equalsIgnoreCase(s[1]))
					res = "tu connais ton propre num�ro d'icq ?! c'est ";
				else
					res = "le num�ro d'icq de "+s[1]+" c'est ";
				if (p.getUins().size() == 1)
					res += p.getUins().elementAt(0);
				else if (p.getUins().size() == 2)
					res += p.getUins().elementAt(0)+" ou "+p.getUins().elementAt(1);
				else
				{
					int max = p.getUins().size();
					int j = 0;
					for (Iterator i = p.getUins().iterator();j < max-1;j++)
						res += i.next()+" ou ";
					res += "encore "+p.getUins().elementAt(max-1);
				}
				time.timeSay(chan,n,res);
			}
		}
	}


	/**
	 * Gives the chan newsgroup as defined in the props.
	 */
	protected void timeNewsgroup(String chan,String n,String r,String[] s,String[] t)
	{
		time.timeSay(chan,n,props.getProperty("responseNewsgroup"));
	}
	
	
	/**
	 * Gives a proverb.
	 */
	protected void timeDicton(String chan,String n,String r,String[] s,String[] t)
	{
		String[] months = {"Janvier","Fevrier","Mars","Avril","Mai","Juin","Juillet","Aout","Septembre","Octobre","Novembre","Decembre"};
		GregorianCalendar now = new GregorianCalendar();
		String dicton = props.getProperty("dicton"+months[now.get(Calendar.MONTH)]+now.get(Calendar.DAY_OF_MONTH));
		if (dicton == null)
		{
			dicton = Utils.parse(time,Utils.randomList(props.getProperty("dicton"+months[now.get(Calendar.MONTH)])));
			time.timeSay(chan,n,"dicton de saison : \""+dicton+"\"");
		}
		else
		{
			dicton = Utils.parse(time,Utils.randomList(dicton));
			time.timeSay(chan,n,"le dicton du jour : \""+dicton+"\"");
		}
	}
	
	
	/**
	 * Gives a rumor.
	 */
	protected void timeRumeur(String chan,String n,String r,String[] s,String[] t)
	{
		String u1 = "",u2= "";
		String begin,body,end;

		if (s.length > 2)
		{
			u1 = s[1];
			u2 = s[2];
		}
		else
		if (s.length == 2)
		{
			u1 = s[1];
			if (!time.isDebugMode())
				u2 = time.getChannelList().getChannel(chan).randomUser(time);
			else
				u2 = "u2";
		}
		else
		if (s.length == 1)
		{
			u1 = time.getChannelList().getChannel(chan).randomUser(time);
			u2 = time.getChannelList().getChannel(chan).randomUser(time,u1);
			if (u2 == null)
				u2 = "BoD";
		}
		if (u1.equalsIgnoreCase(time.getCurrentNick()) || u1.equalsIgnoreCase(time.getCallName()) || u1.equalsIgnoreCase("!"+time.getCurrentNick()) || u1.equalsIgnoreCase("!"+time.getCallName()) || u2.equalsIgnoreCase(time.getCurrentNick()) || u2.equalsIgnoreCase(time.getCallName()) || u2.equalsIgnoreCase("!"+time.getCurrentNick()) || u2.equalsIgnoreCase("!"+time.getCallName()))
		{
			time.timeSay(chan,n,Utils.randomList(Utils.parse(time,props.getProperty("responseAbuse"))));
			return;
		}
		begin = Utils.randomList(props.getProperty("rumeurBegin"));
		body = Utils.randomList(props.getProperty("rumeurBody"));
		end = Utils.randomList(props.getProperty("rumeurEnd"));
		if (body.endsWith(" _"))
		{
			body = body.substring(0,body.length()-2);
			time.timeSay(chan,n,Utils.parse(time,body,u1,u2));
		}
		else
			time.timeSay(chan,n,begin+" "+Utils.parse(time,body,u1,u2)+" "+end);
	}
	
	
	/**
	 * Says a quote.
	 */
	protected void timeCitation(String chan,String n,String r,String[] s,String[] t)
	{
		String line = Utils.randomLine("mod/modTime/citations.txt");
		if (line.equals(""))
			time.timeSay(chan,n,"oops, desol�, probleme... (ceci �tant quand-m�me tr�s (TRES) probablement d� � un bug)");
		else
		{
			String name = Utils.s(line)[0];
			String citation = Utils.t(line)[2];
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("citations")),citation,name));
			if (Utils.random(7) == 0)
				time.timeSay(chan,n,"Toi aussi ajoute une citation en faisant \"!time addcitation <nick> citation\"");
		}
	}
	
	
	/**
	 * Adds a quote.
	 */
	protected void timeAddCitation(String chan,String n,String r,String[] s,String[] t) throws ModException
	{
		if (s.length >= 3 && s[1].startsWith("<") && s[1].endsWith(">"))
			try
			{
				PrintWriter citaFile = new PrintWriter(new BufferedWriter(new FileWriter("mod/ModTime/citations.txt",true)));
				citaFile.println(s[1].substring(1,s[1].length()-1)+" "+n+" "+t[2]);
				citaFile.close();
				time.timeSay(chan,n,"Ok, citation ajout�e :)");
			}
			catch (Exception e)
			{
				time.timeSay(chan,n,"oops, probl�me... Je n'ai pas r�ussi � le faire... d�sol�...");
				throw new ModException("problem while writing to file modPath"+"/ModTime.citations.txt");
			}
		else
			time.timeSay(chan,n,Utils.parse(time,"tu dois faire : $ircB!time addcitation $ircK4<$ircKnick$ircK4>$ircK citation"));
	}

	
	/**
	 * Gives current running version and misc infos.
	 */
	protected void timeVersion(String chan,String n,String r,String[] s,String[] t)
	{
		time.timeSay(chan,n,time.getVersion().productFull()+" - Build "+time.getVersion().build()+" - "+System.getProperty("java.vm.vendor")+" "+System.getProperty("java.vm.name")+" "+System.getProperty("java.vm.version")+" - Hosted by "+time.getHoster()+".");
		time.timeSay(chan,n,"This session connected on "+time.getConnectionDate());
	}

	
	/**
	 * Changes mails property for n.
	 */
	protected void timeChangeMails(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length != 2)
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseChangeMails"))));
		else
			try
			{
				Person p = time.getChannelList().getChannel(chan).getUser(n).getPerson();
				p.setEmails(Person.stringToVector(s[1]));
				p.dump();
				time.timeSay(chan,n,"Ok c'est fait ! Tu peut verifier que �a a march� en faisant !time mail "+n);
			}
			catch (Throwable x)
			{
				time.timeSay(chan,n,"D�sol� je n'ai pas r�ussi. R�essaye plus tard et si �a ne marche toujours pas, dis-le � BoD...");
			}
	}

	
	/**
	 * Changes homepages property for n.
	 */
	protected void timeChangeHomePages(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length != 2)
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseChangeHomePages"))));
		else
			try
			{
				Person p = time.getChannelList().getChannel(chan).getUser(n).getPerson();
				Vector urls = Person.stringToVector(s[1]);
				for (int i = 0;i < urls.size();i++)
				{
					String z = urls.elementAt(i).toString();
					if (z.toLowerCase().startsWith("http://"))
						urls.set(i,z.substring(7));
				}
				p.setHomePages(urls);
				p.dump();
				time.timeSay(chan,n,"Ok c'est fait ! Tu peut verifier que �a a march� en faisant !time web "+n);
			}
			catch (Throwable x)
			{
				time.timeSay(chan,n,"D�sol� je n'ai pas r�ussi. R�essaye plus tard et si �a ne marche toujours pas, dis-le � BoD...");
			}
	}

	
	/**
	 * Changes uins property for n.
	 */
	protected void timeChangeUins(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length != 2)
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseChangeUins"))));
		else
			try
			{
				Person p = time.getChannelList().getChannel(chan).getUser(n).getPerson();
				p.setUins(Person.stringToVector(s[1]));
				p.dump();
				time.timeSay(chan,n,"Ok c'est fait ! Tu peut verifier que �a a march� en faisant !time icq "+n);
			}
			catch (Throwable x)
			{
				time.timeSay(chan,n,"D�sol� je n'ai pas r�ussi. R�essaye plus tard et si �a ne marche toujours pas, dis-le � BoD...");
			}
	}

		
	/**
	 * Gives help.
	 */
	protected void timeHelp(String chan,String n,String r,String[] s,String[] t)
	{
		time.timeSay(chan,n,"L'aide officielle de !time est sur le "+time.getVersion().url());
	}
	
	
	/**
	 * Gives score for n.
	 */
	protected void timeScore(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length == 1)
			try
			{
				Person p = time.getChannelList().getChannel(chan).getUser(n).getPerson();
				time.timeSay(chan,n,"Ton score est actuellement de "+p.getScore()+".");
			}
			catch (Throwable x)
			{
				time.timeSay(chan,n,"D�sol� je n'arrive pas � regarder ton score. Ceci est *peut-�tre* un bug :)");
			}
		else
		if ((s[1].length() > 9) || (s.length > 2))
			time.timeSay(chan,n,Utils.randomList(Utils.parse(time,props.getProperty("responseAbuse"))));
		else
		if (s[1].equalsIgnoreCase(time.getCurrentNick()) || s[1].equalsIgnoreCase(time.getCallName()) || s[1].equalsIgnoreCase("!"+time.getCurrentNick()) || s[1].equalsIgnoreCase("!"+time.getCallName()))
			time.timeSay(chan,n,"mon score est actuellement de 65536 milliards puissance infini.");
		else
		{
			Person p = time.getDb().getPerson(s[1]);
			if (p == null)
				time.timeSay(chan,n,"d�sol�, mais je ne connais pas de "+s[1]);
			else
				time.timeSay(chan,n,"le score de "+s[1]+" est actuellement de "+p.getScore()+".");
		}
	}

	
	/**
	 * Sets the topic of the channel. If no paramater is given, this will set a quote in the quote file.
	 */
	protected void timeTopic(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length == 1)
		{
			/* ////// citation
			String line = Utils.randomLine("mod/modTime/citations.txt");
			if (!line.equals(""))
			{
				String name = Utils.s(line)[0];
				String citation = Utils.t(line)[2];
				time.send("TOPIC "+chan+" :\""+citation+"\" - "+name);
			}
			*/
			///// dicton
			String[] months = {"Janvier","Fevrier","Mars","Avril","Mai","Juin","Juillet","Aout","Septembre","Octobre","Novembre","Decembre"};
			GregorianCalendar now = new GregorianCalendar();
			String dicton = props.getProperty("dicton"+months[now.get(Calendar.MONTH)]+now.get(Calendar.DAY_OF_MONTH));
			if (dicton == null)
				dicton = Utils.parse(time,Utils.randomList(props.getProperty("dicton"+months[now.get(Calendar.MONTH)])));
			else
				dicton = Utils.parse(time,Utils.randomList(dicton));
			time.send("TOPIC "+chan+" :\""+dicton);
		}
		else
			time.send("TOPIC "+chan+" :"+t[1]);
	}


	/**
	 * Gives welcome message for n.
	 */
	protected void timeWelcomeMessage(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length == 1)
			try
			{
				Person p = time.getChannelList().getChannel(chan).getUser(n).getPerson();
				if (p.getWelcomeMessage() == null || p.getWelcomeMessage().equals(""))
					time.timeSay(chan,n,"Tu n'as pas de message de bienvenue. Tu peut en mettre un en faisant "+Irc.ircB+"!time setwelcome"+Irc.ircB+" suivi de ton message.");
				else
					time.timeSay(chan,n,"Ton message de bienvenue est actuellement \""+p.getWelcomeMessage()+"\".");
			}
			catch (Throwable x)
			{
				time.timeSay(chan,n,"D�sol� je n'arrive pas � regarder ton message de bienvenue. Ceci est *peut-�tre* un bug :)");
			}
		else
		if ((s[1].length() > 9) || (s.length > 2))
			time.timeSay(chan,n,Utils.randomList(Utils.parse(time,props.getProperty("responseAbuse"))));
		else
		if (s[1].equalsIgnoreCase(time.getCurrentNick()) || s[1].equalsIgnoreCase(time.getCallName()) || s[1].equalsIgnoreCase("!"+time.getCurrentNick()) || s[1].equalsIgnoreCase("!"+time.getCallName()))
			time.timeSay(chan,n,"Comme si je parlais tout seul !");
		else
		{
			Person p = time.getDb().getPerson(s[1]);
			if (p == null)
				time.timeSay(chan,n,"d�sol�, mais je ne connais pas de "+s[1]);
			else
			if (p.getWelcomeMessage() == null || p.getWelcomeMessage().equals(""))
				time.timeSay(chan,n,s[1]+" n'a pas de message de bienvenue...");
			else
				time.timeSay(chan,n,"le message de bienvenue de "+s[1]+" est actuellement \""+p.getWelcomeMessage()+"\".");
		}
	}


	/**
	 * Gives welcome message for n.
	 */
	protected void timeChangeWelcomeMessage(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length < 2)
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseChangeWelcomeMessage"))));
		else
			try
			{
				Person p = time.getChannelList().getChannel(chan).getUser(n).getPerson();
				p.setWelcomeMessage(t[1]);
				p.dump();
				time.timeSay(chan,n,"Ok c'est fait ! Tu peut verifier que �a a march� en faisant !time welcomeMsg");
			}
			catch (Throwable x)
			{
				time.timeSay(chan,n,"D�sol� je n'ai pas r�ussi. R�essaye plus tard et si �a ne marche toujours pas, dis-le � BoD...");
			}
	}
	
	
	/**
	 * Gives or set message.
	 */
	protected void timeMessage(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length == 2) // syntax
			time.timeSay(chan,n,"Tu dois faire "+Irc.ircB+"!time message"+Irc.ircB+" pour lire ton message, ou bien "+Irc.ircB+"!time message nick message"+Irc.ircB+" pour mettre un message. Fais !time help si tu as un probleme.");
		else
		if (s.length == 1) // gives message
		{
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy � H:mm");
			Person p = time.getChannelList().getChannel(chan).getUser(n).getPerson();
			if (p.getMessage() == null || p.getMessage().equals(""))
				time.timeSay(chan,n,"Tu n'as pas de message...");
			else
			if (p.isMessageNew())
				time.timeSay(chan,n,"Message de "+p.getMessageFrom()+" du "+sdf.format(p.getMessageDate())+", pour "+n+" (nouveau) : \""+p.getMessage()+"\".");
			else
				time.timeSay(chan,n,"Message de "+p.getMessageFrom()+" du "+sdf.format(p.getMessageDate())+", pour "+n+" (d�ja lu) : \""+p.getMessage()+"\".");
			p.setMessageNew(false);
			try
			{
				p.dump();
			}
			catch (IOException e)
			{
				time.getDisplay().warning("problem while dumping person in ModTime.timeMessage()",e);
			}
		}
		else // set message
		{
			Person p = time.getDb().getPerson(s[1]);
			if (p == null)
				time.timeSay(chan,n,"d�sol�, mais je ne connais pas de "+s[1]);
			else
			{
				p.setMessage(t[2]);
				p.setMessageFrom(n);
				p.setMessageDate(new Date());
				p.setMessageNew(true);
				try
				{
					p.dump();
					time.timeSay(chan,n,"Ok c'est fait, "+s[1]+" verra ce message d�s que je "+(p.getGender().equals("unknown")?"le(la)":p.getGender().equals("male")?"le":"la")+" verrai.");
				}
				catch (IOException e)
				{
					time.getDisplay().warning("problem while dumping person in ModTime.timeMessage()",e);
					time.timeSay(chan,n,"Oops y'a eu un petit probleme pendant l'enregistrement de ce message.. Cela-dit, l'op�ration a probablement march� quand-m�me (mais pas s�r).");
				}
			}
		}
	}

	
	/**
	 * Admin functions.
	 */
	protected void timeAdmin(String chan,String n,String r,String[] s,String[] t)
	{
		if (s.length == 2)
		{
			Person p = time.getChannelList().getChannel(chan).getUser(n).getPerson();
			if (!p.isAdmin())
				time.timeSay(chan,n,"tu n'es pas reconnu comme op�rateur");
			else
			{
				if (s[1].equals("dump"))
					try
					{
						time.getDisplay().message("dumping db, as requested by remote admin..");
						time.getDb().dump();
						time.getDisplay().message("bd dumped");
						time.timeSay(chan,n,"ok");
					}
					catch (IOException e)
					{
						time.timeSay(chan,n,"problem: "+e);
						time.getDisplay().warning("problem while dumping db, db not updated",e);
					}
				else
				if (s[1].equals("quit"))
				{
					time.getDisplay().message("exiting Time, as requested by remote admin..");
					time.quit();
				}
			}
		}
	}

	
	/**
	 * Default event fired when no module accepts. The current behaviour is to give a ridiculous answer to the question, based on the first word.
	 */
	protected void timeOracle(String chan,String n,String r,String[] s,String[] t)
	{
		if ((s.length == 1) && (s[0].equalsIgnoreCase("oui") || s[0].equalsIgnoreCase("non") || s[0].equalsIgnoreCase("si") || s[0].equalsIgnoreCase("certes") || s[0].equalsIgnoreCase("bof") || s[0].equalsIgnoreCase("boff") || s[0].equalsIgnoreCase("ok") || s[0].equalsIgnoreCase("bon") || s[0].equalsIgnoreCase("ah")))
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseCertes"))));
		else			
		if (s[0].equalsIgnoreCase("oui") || s[0].equalsIgnoreCase("non") || s[0].equalsIgnoreCase("mais") || s[0].equalsIgnoreCase("ah") || s[0].equalsIgnoreCase("ha") || s[0].equalsIgnoreCase("c'est") || s[0].equalsIgnoreCase("enfin"))
		{
			String[] s2 = new String[s.length-1];
			for (int i = 0;i < s.length-1;i++)
				s2[i] = s[i+1];
			String[] t2 = new String[t.length-1];
			for (int i = 0;i < t.length-1;i++)
				t2[i] = t[i+1];
			timeOracle(chan,n,r,s2,t2);
		}
		else
		if (s[0].equalsIgnoreCase("bonjour") || s[0].equalsIgnoreCase("salut") || s[0].equalsIgnoreCase("hello") || s[0].equalsIgnoreCase("yo") || s[0].equalsIgnoreCase("lo"))
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseBonjour"))));
		else
		if (s[0].equalsIgnoreCase("aurevoir") || s[0].equalsIgnoreCase("bye") || s[0].equalsIgnoreCase("cassos"))
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseAurevoir"))));
		else
		if (s[0].equalsIgnoreCase("qui") || s[0].equalsIgnoreCase("ki"))
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseQui"))));
		else
		if (s[0].equalsIgnoreCase("pourquoi") || s[0].equalsIgnoreCase("pkoi"))
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responsePourquoi"))));
		else
		if (s[0].equalsIgnoreCase("quand"))
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseQuand"))));
		else
		if (s[0].equalsIgnoreCase("ou") || s[0].equalsIgnoreCase("o�"))
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseOu"))));
		else
		if (s[0].equalsIgnoreCase("comment") || s[0].equalsIgnoreCase("komen"))
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseComment"))));
		else
		if (s[0].equalsIgnoreCase("combien"))
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseCombien"))));
		else
		if (s[0].equalsIgnoreCase("quel") || s[0].equalsIgnoreCase("quoi") || s[0].equalsIgnoreCase("qu'est-ce") || s[0].equalsIgnoreCase("qu'est ce") || s[0].equalsIgnoreCase("qu estce") || s[0].equalsIgnoreCase("que"))
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseQue"))));
		else
		if (s[0].equalsIgnoreCase("merci"))
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseMerci"))));
		else
		if (s[0].equalsIgnoreCase("re"))
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList("re#rere#rererererererererererererererererererererererer. Re.")));
		else
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseYesNo"))));
	}


	public boolean accept(String chan,String n,String r,String[] s,String[] t) throws ModException
	{
		if (s.length == 0)
			time.timeSay(chan,n,Utils.parse(time,Utils.randomList(props.getProperty("responseQuoi"))));
		else
			if (s[0].equalsIgnoreCase("time") || s[0].equalsIgnoreCase("!time"))
			{
				timeTime(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("xtime"))
			{
				timeXTime(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("seen"))
			{
				timeSeen(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("xseen"))
			{
				timeXSeen(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("quitmsg") || s[0].equalsIgnoreCase("quitmessage"))
			{
				timeQuitmsg(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("privmsg") || s[0].equalsIgnoreCase("lastmessage") || s[0].equalsIgnoreCase("lastmsg"))
			{
				timePrivmsg(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("mail") || s[0].equalsIgnoreCase("email") || s[0].equalsIgnoreCase("mel"))
			{
				timeMail(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("url") || s[0].equalsIgnoreCase("web") || s[0].equalsIgnoreCase("homepage") || s[0].equalsIgnoreCase("page") || s[0].equalsIgnoreCase("site"))
			{
				timeHomePage(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("uin") || s[0].equalsIgnoreCase("icq") || s[0].equalsIgnoreCase("icquin"))
			{
				timeUins(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("news") || s[0].equalsIgnoreCase("newsgroup") || s[0].equalsIgnoreCase("ng"))
			{
				timeNewsgroup(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("dicton") || s[0].equalsIgnoreCase("proverbe") || s[0].equalsIgnoreCase("prov�rbe"))
			{
				timeDicton(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("rumeur") || s[0].equalsIgnoreCase("rumeurs"))
			{
				timeRumeur(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("citation") || s[0].equalsIgnoreCase("sitation") || s[0].equalsIgnoreCase("citations") || s[0].equalsIgnoreCase("quote"))
			{
				timeCitation(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("addcitation"))
			{
				timeAddCitation(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("version") || s[0].equalsIgnoreCase("ver"))
			{
				timeVersion(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("changeMail") || s[0].equalsIgnoreCase("changeMails") || s[0].equalsIgnoreCase("setMail") || s[0].equalsIgnoreCase("setMails"))
			{
				timeChangeMails(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("changeurl") || s[0].equalsIgnoreCase("changeweb") || s[0].equalsIgnoreCase("changehomepage") || s[0].equalsIgnoreCase("changepage") || s[0].equalsIgnoreCase("seturl") || s[0].equalsIgnoreCase("setweb") || s[0].equalsIgnoreCase("sethomepage") || s[0].equalsIgnoreCase("setpage") || s[0].equalsIgnoreCase("changeurls") || s[0].equalsIgnoreCase("changewebs") || s[0].equalsIgnoreCase("changehomepages") || s[0].equalsIgnoreCase("changepages") || s[0].equalsIgnoreCase("seturls") || s[0].equalsIgnoreCase("setwebs") || s[0].equalsIgnoreCase("sethomepages") || s[0].equalsIgnoreCase("setpages"))
			{
				timeChangeHomePages(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("changeuin") || s[0].equalsIgnoreCase("changeicq") || s[0].equalsIgnoreCase("changeicquin") || s[0].equalsIgnoreCase("setuin") || s[0].equalsIgnoreCase("seticq") || s[0].equalsIgnoreCase("setuin"))
			{
				timeChangeUins(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("help") || s[0].equalsIgnoreCase("aide"))
			{
				timeHelp(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("score"))
			{
				timeScore(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("topic"))
			{
				timeTopic(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("welcomemsg") || s[0].equalsIgnoreCase("welcomemessage"))
			{
				timeWelcomeMessage(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("changewelcomemsg") || s[0].equalsIgnoreCase("changewelcomemessage") || s[0].equalsIgnoreCase("setwelcomemsg") || s[0].equalsIgnoreCase("setwelcomemessage") || s[0].equalsIgnoreCase("changewelcome") || s[0].equalsIgnoreCase("setwelcome"))
			{
				timeChangeWelcomeMessage(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("message") || s[0].equalsIgnoreCase("msg"))
			{
				timeMessage(chan,n,r,s,t);
				return true;
			}
		else
			if (s[0].equalsIgnoreCase("admin"))
			{
				timeAdmin(chan,n,r,s,t);
				return true;
			}
		else
		{
			timeOracle(chan,n,r,s,t);
			return true;
		}
		return false; // should never happen since ModTime is the last mod of the mod table.
	}
}