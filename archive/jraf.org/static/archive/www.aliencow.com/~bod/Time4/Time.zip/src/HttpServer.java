package com.c3dric.bod.time4;

import java.io.*;
import java.net.*;


/**
 * This is a little HTTP server used to access to db.zip and log.txt
 */
public class HttpServer extends Thread
{
	/**
	 * This attached <CODE>Time</CODE>.
	 */
	protected Time time;
	

	public void run()
	{
		ServerSocket serverSocket = null;
		try
		{
			serverSocket = new ServerSocket(time.getHttpServerPort());
			time.getDisplay().message("http server initialized");
			Socket socket;
			BufferedReader in;
			PrintWriter out2;
			String req;
			String h;
			String fileName;
			while (true)
				try
				{
					socket = serverSocket.accept();
					time.getDisplay().message("http server: received a connection from "+socket.getInetAddress().getHostName());
					in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
					req = in.readLine(); // request
					h = in.readLine(); // header
					while (!h.equals(""))
						h = in.readLine();
					if (Utils.s(req)[0].equals("GET"))
					{
						fileName = Utils.s(req)[1].substring(1);
						BufferedOutputStream out = new BufferedOutputStream(socket.getOutputStream());
						out2 = new PrintWriter(out);
						
						if (fileName.equals("admin?ls")) // admin ls
						{
							time.getDisplay().message("http server: client admin ls "+fileName);
							out2.print("HTTP/1.0 200 OK\r\n");
							out2.print("Content-Type: text/html\r\n");
							out2.print("\r\n");
							out2.flush();
							out2.println("<HTML><BODY><PRE>");
							out2.println(time.getVersion());
							out2.println();
							out2.println();
							out2.println("admin ls");
							out2.println("��������");
							out2.println();
							File[] ls = new File(".").listFiles();
							for (int i = 0;i < ls.length;i++)
								if (ls[i].isDirectory())
									out2.println(ls[i].getName()+"/");
								else
									out2.println(ls[i].getName());
							out2.println("</PRE></BODY></HTML>");
							out2.flush();
						}
						else // file request
						{
							time.getDisplay().message("http server: client requesting file "+fileName);
							File file = new File(fileName);
							if (file.exists() && !file.isDirectory())
							{
								time.getDisplay().message("http server: sending file "+file+"..");
								out2.print("HTTP/1.0 200 OK\r\n");
								out2.print("Content-Length: "+file.length()+"\r\n");
								out2.print("\r\n");
								out2.flush();
								FileInputStream fis = new FileInputStream(file);
								byte[] buff = new byte[512]; // 512
								for (int r;(r = fis.read(buff)) != -1;)
								{
									out.write(buff,0,r);
									out.flush();
								}
								time.getDisplay().message("http server: file "+file+" sent");
							}
							else // 404
							{
								time.getDisplay().message("http server: file "+file+" was not found, sending 404 to client");
								out2.print("HTTP/1.0 404 Not Found\r\n");
								out2.print("Content-Length: "+("<HTML><BODY><H1>404 Not Found</H1>"+time.getVersion()+"</BODY></HTML>").length()+"\r\n");
								out2.print("\r\n");
								out2.print("<HTML><BODY><H1>404 Not Found</H1>"+time.getVersion()+"</BODY></HTML>");
								out2.flush();
							}
						}
						socket.close();
						time.getDisplay().message("http server: connection with client "+socket.getInetAddress().getHostName()+" closed");
					}
				}
				catch (Exception e)
				{
					time.getDisplay().warning("http server: problem while serving client",e);
				}
		}
		catch (Exception e)
		{
			time.getDisplay().warning("could not initialize http server",e);
		}
	}
	
	
	/**
	 * Constructor
	 */
	public HttpServer(Time t)
	{
		time = t;
	}
}