/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.noidle;

import java.awt.AWTException;
import java.awt.Image;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PopupMenu;
import java.awt.Robot;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class NoIdle {
    private static boolean active = true;

    public NoIdle() throws AWTException, InterruptedException {
        SystemTray systemTray = SystemTray.getSystemTray();
        final Image imageIconActive = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/res/icon-active.png"));
        final Image imageIconInactive = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/res/icon-inactive.png"));
        final TrayIcon trayIcon = new TrayIcon(imageIconActive, "NoIdle");
        trayIcon.setToolTip("BoD NoIdle v1.00 - Active");

        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getActionCommand().equals("toggle")) {
                    active = !active;
                    if (active) {
                        trayIcon.setImage(imageIconActive);
                        trayIcon.setToolTip("BoD NoIdle v1.00 - Active");
                    } else {
                        trayIcon.setImage(imageIconInactive);
                        trayIcon.setToolTip("BoD NoIdle v1.00 - Inactive");
                    }
                } else if (e.getActionCommand().equals("Exit")) {
                    System.exit(0);
                } else if (e.getActionCommand().equals("About...")) {
                    JOptionPane.showMessageDialog(null,
                        "BoD NoIdle v1.00\nThis program and its source are in the public domain.\nContact the author for any reason: BoD@JRAF.org.",
                        "About", 
                        JOptionPane.INFORMATION_MESSAGE);
                }

            }
        };

        trayIcon.setActionCommand("toggle");
        trayIcon.addActionListener(actionListener);

        PopupMenu popupMenu = new PopupMenu();
        popupMenu.add("About...");
        popupMenu.add("Exit");
        popupMenu.addActionListener(actionListener);

        trayIcon.setPopupMenu(popupMenu);
        systemTray.add(trayIcon);


        Robot robot = new Robot();
        while (true) {
            if (active) {
                Point location = MouseInfo.getPointerInfo().getLocation();
                robot.mouseMove(location.x + 1, location.y); // move one pixel to the right
                Thread.sleep(100); // wait 0.1 s
                robot.mouseMove(location.x, location.y); // go back
            }
            Thread.sleep(59000); // wait 59 seconds
        }
    }

    public static void main(String[] args) throws InterruptedException, AWTException {
        new NoIdle();
    }
}
