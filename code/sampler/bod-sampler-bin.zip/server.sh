#!/bin/sh
cd samples
java -cp ../bin org.jraf.sampler.Sampler