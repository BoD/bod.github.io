#!/bin/sh
java -cp bin org.jraf.sampler.Client $1