/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.sampler;

import java.net.*;
import java.io.*;

public class ClientTest {
	public void testClient() throws Throwable {
		Socket socket = new Socket("localhost", Protocol.LISTEN_PORT);
		BufferedOutputStream out = new BufferedOutputStream(socket.getOutputStream());
		byte[] send = new byte[] {
				Protocol.CMD_PLAY,
				1
		};
		out.write(send);
		out.flush();
	}

	public static void main(String[] args) throws Throwable {
		new ClientTest().testClient();
	}
}