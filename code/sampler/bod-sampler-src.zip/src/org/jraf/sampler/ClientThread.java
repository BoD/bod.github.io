/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.sampler;

import java.net.*;
import java.io.*;

public class ClientThread implements Runnable {
	private Sampler sampler;
	private Socket clientSocket;
	private BufferedReader in;
	private BufferedWriter out;

	public ClientThread(Sampler sampler, Socket clientSocket) throws IOException {
		this.sampler = sampler;
		this.clientSocket = clientSocket;
		in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
		out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
	}

	public void startProtocolLoop() {
		new Thread(this).start();
	}

	private void sendCommand(String command) throws IOException {
		out.write(command+'\n');
		out.flush();
	}

	private String readLine() throws IOException {
		return in.readLine();
	}

	public void run() {
		boolean exit = false;
		while (!exit) {
			try {
				String received = readLine();
				char cmd = received.charAt(0);
				received = received.substring(1);
				switch (cmd) {
					case Protocol.CMD_PLAY:
						cmdPlay(received);
					break;
					case Protocol.CMD_STOP:
						cmdStop();
					break;
					case Protocol.CMD_LIST_SAMPLES:
						cmdSamplerList();
						if (sampler.getGui().isNotAvailable()) {
							try {
								Thread.sleep(800);
							} catch (InterruptedException e) {/* should never happen */}
							sendNotAvaliable(true);
						}
					break;
					case Protocol.CMD_EXIT: // client exits
						sampler.getServer().getClients().remove(this);
						exit = true;
					break;
				}
			} catch (IOException e) {
				try {
					clientSocket.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				exit = true;
			}
		}
	}

	private void cmdPlay(final String cmd) {
		if (sampler.isPlaying()) {
			new Thread(new Runnable() {
				public void run() {
					sampler.stop();
					sampler.getGui().stopBlinking();
					try {
						sendEndPlay();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}).start();
		} else {
			new Thread(new Runnable() {
				public void run() {
					try {
						int sampleIndex = Integer.parseInt(cmd);
						sampler.getGui().startBlinking(sampleIndex, clientSocket.getInetAddress().getAddress()[3]);
						for (ClientThread clientThread : sampler.getServer().getClients()) {
							if (!clientThread.clientSocket.getInetAddress().equals(clientSocket.getInetAddress())) { // ignore this client
								clientThread.sendStartPlay(sampleIndex, clientSocket.getInetAddress().getAddress()[3]);
							}
						}

						sampler.play(sampleIndex);
						sampler.getGui().stopBlinking();
						for (ClientThread clientThread : sampler.getServer().getClients()) {
							clientThread.sendEndPlay();
						}

					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}).start();
		}
	}

	private void cmdStop() {
		sampler.stop();
		sampler.getGui().stopBlinking();
	}

	public void cmdSamplerList() {
		StringBuilder response = new StringBuilder(""+Protocol.CMD_LIST_SAMPLES);
		for (int i = 0; i < sampler.getSampleFileNames().length; i++) {
			if (i != 0) {
				response.append("|");
			}
			String sampleName = sampler.getSampleFileNames()[i].split("_", 3)[2];
			response.append(sampleName.split("\\.")[0]);
		}
		try {
			sendCommand(response.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void sendStartPlay(int index, int client) throws IOException {
		sendCommand(""+Protocol.CMD_PLAY+""+index+" "+client);
	}

	public void sendEndPlay() throws IOException {
		sendCommand(""+Protocol.CMD_PLAYBACK_ENDED);
	}

	public void sendExit() throws IOException {
		sendCommand(""+Protocol.CMD_EXIT);
	}

	public void sendNotAvaliable(boolean notAvailable) throws IOException {
		if (notAvailable) {
			sendCommand(""+Protocol.CMD_NOT_AVAILABLE);
		} else {
			sendCommand(""+Protocol.CMD_AVAILABLE);
		}
	}
}
