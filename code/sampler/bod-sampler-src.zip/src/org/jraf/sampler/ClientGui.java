/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.sampler;

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class ClientGui extends Gui {
	private Client client;

	public ClientGui(Client client) throws Exception {
		this.client = client;
		client.setGui(this);
		initUI();
		frame.setVisible(true);
	}

	protected void initUI() throws Exception {
		super.initUI();
		frame.setTitle(FRAME_TITLE+" - Client");
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				if (!exit) {
					client.exit();
				}
				System.exit(0);
			}
		});

	}

	protected void initSamples() throws Exception {
		final String[] sampleNames = client.getSampleNames();
		if (!isNotAvailable()) {
			SwingUtilities.invokeAndWait(new Runnable() {
				public void run() {
					for (int i = 0; i < sampleNames.length; i++) {
						final JComponent button = createButton(sampleNames[i]);
						setBehaviour(button, i);
						frame.getContentPane().add(button);
					}
				}
			});
		}
	}

	protected void setBehaviour(final JComponent button, final int index) {
		button.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (client.isPlaying()) {
					new Thread(new Runnable() {
						public void run() {
							client.stop();
							stopBlinking();
						}
					}).start();
				} else {
					new Thread(new Runnable() {
						public void run() {
							try {
								startBlinking(button, client.getInetAddress().getAddress()[3]);
								client.play(index);
//								stopBlinking();
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}).start();
				}
			}
		});
	}

	public void setNotAvailable(boolean notAvailable) {
		if (notAvailable) {
			try {
				SwingUtilities.invokeAndWait(new Runnable() {
					public void run() {
						frame.getContentPane().removeAll();
						frame.getContentPane().setLayout(new BorderLayout(5, 5));
						JLabel exitLabel = new JLabel("<html>The server cannot play right now.<br/> Please wait a bit...");
						exitLabel.setFont(FONT_BUTTON);
						frame.getContentPane().add(exitLabel, BorderLayout.CENTER);
						frame.getContentPane().validate();
						frame.getContentPane().repaint();
					}
				});
			} catch (Exception e) {/* should never happen */}
		} else {
			refresh();
		}
	}
}
