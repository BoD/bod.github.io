/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.sampler;

import java.net.*;
import java.io.*;

public class Client implements Runnable {
	private Gui gui;
	private String server;
	private Socket socket;
	private BufferedReader in;
	private BufferedWriter out;
	private boolean playing;
	private String[] sampleList;
	private InetAddress inetAddress;


	public Client(String server) throws Exception {
		this.server = server;
		openConnection();
		new Thread(this).start();
		new ClientGui(this);
	}

	private void openConnection() throws IOException {
		socket = new Socket(server, Protocol.LISTEN_PORT);
		in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
		inetAddress = socket.getLocalAddress();
	}

	private String readLine() throws IOException {
		return in.readLine();
	}

	public String[] getSampleNames() {
		if (sampleList == null) {
			try {
				sendCommand(""+Protocol.CMD_LIST_SAMPLES);
				while (sampleList == null) {
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {e.printStackTrace();} // should never happen
				}
			} catch (IOException e) {
				e.printStackTrace();
				return new String[]{"Problem !"};
			}
		}
		return sampleList;
	}

	public void stop() {
		try {
			sendCommand(""+Protocol.CMD_STOP);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void play(int index) {
		try {
			sendCommand(""+Protocol.CMD_PLAY+""+index);
			playing = true;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void exit() {
		try {
			sendCommand(""+Protocol.CMD_EXIT);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	private void sendCommand(String command) throws IOException {
		out.write(command+'\n');
		out.flush();
	}

	public void run() {
		boolean exit = false;
		while (!exit) {
			try {
				String received = readLine(); // blocking
				char cmd = received.charAt(0);
				received = received.substring(1);
				switch (cmd) {
					case Protocol.CMD_PLAY:
						cmdPlay(received);
					break;
					case Protocol.CMD_PLAYBACK_ENDED:
						playing = false;
						gui.stopBlinking();
					break;
					case Protocol.CMD_STOP:
//						cmdStop();
					break;
					case Protocol.CMD_LIST_SAMPLES:
						synchronized (this) {
							boolean firstTime = sampleList == null;
							sampleList = received.split("\\|");
							if (!firstTime) {
								try {
									gui.refresh();
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						}
					break;
					case Protocol.CMD_NOT_AVAILABLE:
						synchronized (this) {
							gui.setNotAvailable(true);
						}
					break;
					case Protocol.CMD_AVAILABLE:
						gui.setNotAvailable(false);
					break;
					case Protocol.CMD_EXIT:
						cmdExit();
						exit = true;
					break;
				}
			} catch (IOException e) {
				try {
					socket.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				exit = true;
			}
		}
	}

	private void cmdExit() {
		gui.setExitStatus();
	}

	private void cmdPlay(String received) {
		String[] split = received.split(" ");
		gui.startBlinking(Integer.parseInt(split[0]), Integer.parseInt(split[1]));
	}

	public boolean isPlaying() {
		return playing;
	}


	public InetAddress getInetAddress() {
		return inetAddress;
	}

	public static void main(String[] args) throws Exception {
		new Client(args[0]);
	}

	public void setGui(Gui gui) {
		this.gui = gui;
	}
}