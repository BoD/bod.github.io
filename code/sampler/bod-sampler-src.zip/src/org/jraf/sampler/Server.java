/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.sampler;

import java.net.*;
import java.io.*;
import java.util.*;

public class Server {
	private Sampler sampler;
	private Set<ClientThread> clients;


	public Server(Sampler sampler) {
		this.sampler = sampler;
	}

	public void startListenLoop() throws IOException {
		ServerSocket serverSocket = new ServerSocket(Protocol.LISTEN_PORT);
		clients = new HashSet<ClientThread>();
		while (true) {
			Socket clientSocket = serverSocket.accept(); // blocking
			ClientThread client = new ClientThread(sampler, clientSocket);
			clients.add(client);
			client.startProtocolLoop();
		}
	}

	public Set<ClientThread> getClients() {
		return clients;
	}
}
