/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.sampler;

import java.io.*;
import java.util.*;
import javax.sound.sampled.*;


public class Sampler {
	private Gui gui;

	private SourceDataLine sourceDataLine;
	private boolean playing = false;
	private boolean stopping = false;

	private int currentFileVolume;
	private String[] sampleFileNames;
	private String[] previousSampleFileNames;
	private int currentVolumeValue;
	private Server server;


	public Sampler() throws Exception {
		loadSamples();
		gui = new ServerGui(this);
		initMonitor();
		server = new Server(this);
		server.startListenLoop();
	}

	private void loadSamples() throws Exception {
		sampleFileNames = new File(".").list(new FilenameFilter() {
			public boolean accept(File dir, String name) {
				return name.toLowerCase().endsWith(".wav");
			}
		});
		Arrays.sort(sampleFileNames);
	}

	public void play(int index) throws Exception {
		String filePath = sampleFileNames[index];
		String[] fileNameParts = filePath.split("_", 3);
		final int volume = Integer.parseInt(fileNameParts[1]);

		playing = true;
		AudioInputStream ais = AudioSystem.getAudioInputStream(new File(filePath));
		AudioFormat af = ais.getFormat();
		DataLine.Info info = new DataLine.Info(SourceDataLine.class, af);

		if (!AudioSystem.isLineSupported(info)) {
			throw new UnsupportedAudioFileException();
		}

		int frameRate = (int) af.getFrameRate();
		int frameSize = af.getFrameSize();
		int bufSize = frameRate * frameSize / 10;

		sourceDataLine = (SourceDataLine) AudioSystem.getLine(info);
		sourceDataLine.open(af, bufSize);
		currentFileVolume = volume;
		adjustVolume();
		sourceDataLine.start();

		byte[] data = new byte[bufSize];
		int bytesRead;

		while ((bytesRead = ais.read(data, 0, data.length)) != -1 && !stopping) {
			sourceDataLine.write(data, 0, bytesRead);
		}
		if (!stopping) {
			sourceDataLine.drain();
		}
		sourceDataLine.stop();
		sourceDataLine.close();
		ais.close();
		playing = false;
		stopping = false;
	}

	public void stop() {
		stopping = true;
		playing = false;
	}

	public void setCurrentVolumeValue(int currentVolumeValue) {
		this.currentVolumeValue = currentVolumeValue;
		adjustVolume();
	}

	private void adjustVolume() {
		if (sourceDataLine != null) {
			FloatControl masterGainControl = (FloatControl)sourceDataLine.getControl(FloatControl.Type.MASTER_GAIN);
			float volume = (currentVolumeValue/100.0f) * (currentFileVolume/100.0f);
			float dB = (float)(Math.log(volume)/Math.log(10.0)*20.0);
			masterGainControl.setValue(dB);
		}
	}

	private void initMonitor() {
		new Thread(new Runnable() {
				public void run() {
					while (true) {
						String[] files = new File(".").list(new FilenameFilter() {
							public boolean accept(File dir, String name) {
								return name.toLowerCase().endsWith(".wav");
							}
						});
						Arrays.sort(files);
						if (previousSampleFileNames == null) {
							previousSampleFileNames = files;
						} else {
							boolean refresh = false;
							if (files.length != previousSampleFileNames.length) {
								refresh = true;
							} else {
								for (int i = 0; i < files.length; i++) {
									String file = files[i];
									if (!file.equals(previousSampleFileNames[i])) {
										refresh = true;
										break;
									}
								}
							}
							if (refresh) {
								sampleFileNames = files;
								gui.refresh();
								for (ClientThread client : server.getClients()) {
									client.cmdSamplerList();
								}
							}
							previousSampleFileNames = files;
						}

						try {
							Thread.sleep(5000);
						} catch (InterruptedException e) {/* should never happen */}
					}
				}
		}).start();
	}

	public String[] getSampleFileNames() {
		return sampleFileNames;
	}

	public boolean isPlaying() {
		return playing;
	}

	public static void main(String[] args) throws Exception {
		new Sampler();
	}

	public Gui getGui() {
		return gui;
	}

	public Server getServer() {
		return server;
	}
}
