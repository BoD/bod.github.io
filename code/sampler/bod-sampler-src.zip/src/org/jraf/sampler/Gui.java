/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.sampler;

import java.awt.*;
import java.awt.event.*;
import java.util.prefs.*;
import javax.swing.*;

public abstract class Gui {
	protected static final String FRAME_TITLE = "BoD Sampler v1.25�200";
	protected static final Font FONT_BUTTON = new Font("Tahoma", Font.BOLD, 9);
	protected static final Preferences PREFERENCES = Preferences.userNodeForPackage(Sampler.class);
	protected static final String PREF_WIDTH = "width";
	protected static final String PREF_HEIGHT = "height";
	protected static final String PREF_X = "x";
	protected static final String PREF_Y = "y";
	protected static final String PREF_VOLUME = "volume";
	protected static final Color SERVER_COLOR = Color.RED;
	protected static final Color[] CLIENT_COLORS = new Color[]{Color.PINK, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.MAGENTA, Color.CYAN, Color.BLUE};


	protected JFrame frame;

	private Thread blinkingThread;
	private boolean blinking = false;
	private static final Object SYNC_BLINKING = new Object();
	private JComponent blinkingButton;
	private Color blinkColor;
	protected boolean notAvailable;
	protected boolean exit;

	protected void initUI() throws Exception {
		frame = new JFrame();
		frame.setBounds(PREFERENCES.getInt(PREF_X, 320), PREFERENCES.getInt(PREF_Y, 200), PREFERENCES.getInt(PREF_WIDTH, 320), PREFERENCES.getInt(PREF_HEIGHT, 200));
		frame.getContentPane().setLayout(new FlowLayout(FlowLayout.LEFT, 5, 2));
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.setIconImage(new ImageIcon(getClass().getResource("/resources/bod-sampler.png")).getImage());
		frame.addComponentListener(new ComponentAdapter() {
			public void componentResized(ComponentEvent e) {
				PREFERENCES.putInt(PREF_WIDTH, e.getComponent().getWidth());
				PREFERENCES.putInt(PREF_HEIGHT, e.getComponent().getHeight());
			}

			public void componentMoved(ComponentEvent e) {
				PREFERENCES.putInt(PREF_X, e.getComponent().getX());
				PREFERENCES.putInt(PREF_Y, e.getComponent().getY());
			}
		});

		initSamples();
		addVolumeSlider();
		addNotAvailableButton();
	}

	public void refresh() {
		try {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					frame.getContentPane().removeAll();
					frame.getContentPane().setLayout(new FlowLayout(FlowLayout.LEFT, 5, 2));
				}
			});
		} catch (Exception e) {/* should never happen */}
		try {
			initSamples();
		} catch (Exception e) {
			e.printStackTrace();
		}

		addVolumeSlider();
		addNotAvailableButton();

		try {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					frame.getContentPane().validate();
					frame.getContentPane().repaint();
				}
			});
		} catch (Exception e) {/* should never happen */}
	}


	protected abstract void initSamples() throws Exception;

	protected JLabel createButton(final String caption) {
		final JLabel res = new JLabel(caption);
		res.setFont(FONT_BUTTON);

		res.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				res.setForeground(Color.BLUE);
				res.setText("<html><u>" + caption);
			}

			public void mouseExited(MouseEvent e) {
				res.setForeground(Color.BLACK);
				res.setText(caption);
			}
		});

		return res;
	}

	protected abstract void setBehaviour(final JComponent button, final int index);

	protected void startBlinking(JComponent button, final int client) {
		blinkingButton = button;
		if (client == -1) {
			blinkColor = SERVER_COLOR;
		} else {
			blinkColor = CLIENT_COLORS[Math.abs(client) % CLIENT_COLORS.length];
		}
		if (blinkingThread == null) {
			blinkingThread = new Thread(new Runnable() {
				public void run() {
					while (true) {
						if (!blinking) {
							try {
								synchronized (SYNC_BLINKING) {
									SYNC_BLINKING.wait();
								}
							} catch (InterruptedException e) {/* should never happen */}
						}
						blinkingButton.setForeground(blinkColor);
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {/* should never happen */}
						blinkingButton.setForeground(Color.BLACK);
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {/* should never happen */}
					}
				}
			});

			blinkingThread.start();
		}
		blinking = true;
		synchronized (SYNC_BLINKING) {
			SYNC_BLINKING.notify();
		}
	}

	public void startBlinking(int i, int client) {
		startBlinking((JComponent) frame.getContentPane().getComponent(i), client);
	}

	public void stopBlinking() {
		blinking = false;
	}

	protected void addVolumeSlider() {
	}

	public void setExitStatus() {
		exit = true;
		try {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					frame.getContentPane().removeAll();
					frame.getContentPane().setLayout(new BorderLayout(5, 5));
					JLabel exitLabel = new JLabel("<html>The server has exited.<br/>Please restart the application.");
					exitLabel.setFont(FONT_BUTTON);
					frame.getContentPane().add(exitLabel, BorderLayout.CENTER);
					frame.getContentPane().validate();
					frame.getContentPane().repaint();
				}
			});
		} catch (Exception e) {/* should never happen */}
	}

	public void setNotAvailable(boolean notAvailable) {
	}

	protected void addNotAvailableButton() {
	}

	public boolean isNotAvailable() {
		return notAvailable;
	}
}
