/*
This source is part of the
     _____  ___   ____
 __ / / _ \/ _ | / __/___  _______ _
/ // / , _/ __ |/ _/_/ _ \/ __/ _ `/
\___/_/|_/_/ |_/_/ (_)___/_/  \_, /
                             /___/
repository. It is in the public domain.
Contact BoD@JRAF.org for more information.

$Id: $
*/
package org.jraf.sampler;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.plaf.basic.*;

public class ServerGui extends Gui {
	private Sampler sampler;

	private JSlider volumeSlider;

	public ServerGui(Sampler sampler) throws Exception {
		this.sampler = sampler;
		initUI();
		frame.setVisible(true);
	}


	protected void initUI() throws Exception {
		super.initUI();
		frame.setTitle(FRAME_TITLE);
		frame.addWindowListener(new WindowAdapter() {

			public void windowClosing(WindowEvent e) {
				for (ClientThread clientThread : sampler.getServer().getClients()) {
					try {
						clientThread.sendExit();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
				System.exit(0);
			}
		});
		frame.getContentPane().addMouseWheelListener(new MouseWheelListener() {
			public void mouseWheelMoved(MouseWheelEvent e) {
				if (e.getUnitsToScroll() < 0) {
					volumeSlider.setValue(volumeSlider.getValue()+10);
				} else {
					volumeSlider.setValue(volumeSlider.getValue()-10);
				}
				PREFERENCES.putInt(PREF_VOLUME, volumeSlider.getValue());
				sampler.setCurrentVolumeValue(volumeSlider.getValue());
			}
		});

		frame.setAlwaysOnTop(true);
	}

	protected void initSamples() throws Exception {
		for (int i = 0; i < sampler.getSampleFileNames().length; i++) {
			String fileName = sampler.getSampleFileNames()[i];
			String[] fileNameParts = fileName.split("_", 3);
			final String name = fileNameParts[2].split("\\.")[0];
			final JComponent button = createButton(name);
			setBehaviour(button, i);
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					frame.getContentPane().add(button);
				}
			});
		}
	}

	protected void setBehaviour(final JComponent button, final int index) {
		button.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (sampler.isPlaying()) {
					new Thread(new Runnable() {
						public void run() {
							sampler.stop();
							stopBlinking();
						}
					}).start();
				} else {
					new Thread(new Runnable() {
						public void run() {
							try {
								startBlinking(button, -1);
								for (ClientThread clientThread : sampler.getServer().getClients()) {
									clientThread.sendStartPlay(index, -1);
								}
								sampler.play(index);
								stopBlinking();
								for (ClientThread clientThread : sampler.getServer().getClients()) {
									clientThread.sendEndPlay();
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}).start();
				}
			}
		});
	}

	protected void addVolumeSlider() {
		volumeSlider = new JSlider(SwingConstants.HORIZONTAL, 0, 100, PREFERENCES.getInt(PREF_VOLUME, 50));
		volumeSlider.setPreferredSize(new Dimension(30, 10));
		volumeSlider.setUI(new BasicSliderUI(volumeSlider) {
			protected Dimension getThumbSize() {
				return new Dimension(4, 10);
			}
		});
		volumeSlider.setFocusable(false);
		volumeSlider.setExtent(10);
		volumeSlider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				PREFERENCES.putInt(PREF_VOLUME, volumeSlider.getValue());
				sampler.setCurrentVolumeValue(volumeSlider.getValue());
			}
		});
		try {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					frame.getContentPane().add(volumeSlider);
				}
			});
		} catch (Exception e) {/* should never happen */}
		sampler.setCurrentVolumeValue(volumeSlider.getValue());
	}

	protected void addNotAvailableButton() {
		final JLabel naButton = new JLabel("N/A");
		naButton.setFont(FONT_BUTTON);
		naButton.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				naButton.setForeground(Color.BLUE);
				naButton.setText("<html><u>N/A");
			}

			public void mouseExited(MouseEvent e) {
				if (notAvailable) {
					naButton.setForeground(Color.RED);
				} else {
					naButton.setForeground(Color.BLACK);
				}
				naButton.setText("N/A");
			}

			public void mouseClicked(MouseEvent e) {
				notAvailable = !notAvailable;
				if (notAvailable) {
					naButton.setForeground(Color.RED);
				} else {
					naButton.setForeground(Color.BLACK);
				}
				for (ClientThread clientThread : sampler.getServer().getClients()) {
					try {
						clientThread.sendNotAvaliable(notAvailable);
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		try {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					frame.getContentPane().add(naButton);
				}
			});
		} catch (Exception e) {/* should never happen */}
	}
}